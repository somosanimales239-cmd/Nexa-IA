<?php
require __DIR__ . '/api/common.php';
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
nexa_db();
if (!nexa_is_setup()) { header('Location: setup.php'); exit; }
nexa_session_start();

$error = '';
$registerError = '';
$registerMode = isset($_GET['register']) || isset($_POST['register_submit']);
$publicCsrf = nexa_csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_username'], $_POST['login_password'])) {
    $login = trim((string)$_POST['login_username']);
    $password = (string)$_POST['login_password'];
    $stmt = nexa_db()->prepare('SELECT * FROM users WHERE active=1 AND (username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE) LIMIT 1');
    $stmt->execute([$login,$login]);
    $candidate = $stmt->fetch();
    if ($candidate && password_verify($password, (string)$candidate['password_hash'])) {
        nexa_login_user($candidate);
        header('Location: ./'); exit;
    }
    $error = 'Usuario/email o contraseña incorrectos.';
    $registerMode = false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_submit'])) {
    $registerMode = true;
    $name = trim((string)($_POST['register_name'] ?? ''));
    $email = strtolower(trim((string)($_POST['register_email'] ?? '')));
    $password = (string)($_POST['register_password'] ?? '');
    $token = (string)($_POST['register_csrf'] ?? '');

    if (!$token || !hash_equals($publicCsrf, $token)) {
        $registerError = 'La sesión del formulario expiró. Recarga la página e inténtalo otra vez.';
    } elseif (mb_strlen($name, 'UTF-8') < 2 || mb_strlen($name, 'UTF-8') > 100) {
        $registerError = 'Escribe un nombre válido de 2 a 100 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $registerError = 'Escribe un email válido.';
    } elseif (strlen($password) < 8) {
        $registerError = 'La contraseña debe tener al menos 8 caracteres.';
    } elseif (strlen($password) > 200) {
        $registerError = 'La contraseña es demasiado larga.';
    } else {
        $pdo = nexa_db();
        $check = $pdo->prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE LIMIT 1');
        $check->execute([$email,$email]);
        if ($check->fetch()) {
            $registerError = 'Ya existe una cuenta con ese email.';
        } else {
            $now = nexa_now();
            try {
                $stmt = $pdo->prepare('INSERT INTO users(username,email,display_name,password_hash,role,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)');
                $stmt->execute([$email,$email,$name,password_hash($password,PASSWORD_DEFAULT),'user',1,$now,$now]);
                $newUser = nexa_user_by_id((int)$pdo->lastInsertId());
                if (!$newUser) throw new RuntimeException('No se pudo abrir la cuenta recién creada.');
                nexa_login_user($newUser);
                header('Location: ./'); exit;
            } catch (PDOException $e) {
                if (stripos($e->getMessage(),'UNIQUE') !== false) {
                    $registerError = 'Ya existe una cuenta con ese email.';
                } else {
                    throw $e;
                }
            }
        }
    }
}

$user = nexa_current_user();
if (!$user):
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nexa AI Web · <?= $registerMode ? 'Crear cuenta' : 'Sign In' ?></title><link rel="icon" type="image/png" href="assets/nexa-favicon.png"><link rel="stylesheet" href="assets/app.css?v=3800"><style id="nexa-chat-white-canvas-v233">
/* Nexa AI Web v2.3.3 · white CHAT canvas preview only.
   Keep sidebar, topbar, message cards, composer and every other view unchanged. */
#view-chat,
#view-chat.active,
#view-chat .messages {
  background:#ffffff !important;
}

/* v2.5.4 · Chat PC Workspace setup */
.nexa-workspace-dialog{width:min(720px,calc(100vw - 32px));border:1px solid #27445f;border-radius:16px;background:#0c1b2a;color:#eef7ff;padding:0;box-shadow:0 28px 90px rgba(0,0,0,.5)}
.nexa-workspace-dialog::backdrop{background:rgba(1,9,16,.72);backdrop-filter:blur(3px)}
.nexa-workspace-dialog form{margin:0}.nexa-workspace-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:18px 20px;border-bottom:1px solid #223a51;background:#0a1724}
.nexa-workspace-head strong{display:block;font-size:17px}.nexa-workspace-head small{display:block;color:#96adc1;margin-top:3px}.nexa-workspace-close{width:34px;height:34px;border-radius:10px;font-size:20px}
.nexa-workspace-body{display:grid;gap:15px;padding:20px}.nexa-workspace-body label{display:grid;gap:7px;font-weight:700}.nexa-workspace-body input,.nexa-workspace-body select{width:100%;box-sizing:border-box}
.nexa-workspace-roots{display:grid;gap:6px;padding:12px;border:1px solid #243d54;border-radius:12px;background:#081522}.nexa-workspace-roots code{display:block;white-space:normal;word-break:break-all;background:#dbe8f2;color:#09121b;padding:6px 8px;border-radius:7px}
.nexa-workspace-status{min-height:22px;padding:10px 12px;border-radius:10px;background:#0a2030;border:1px solid #26445e;color:#cfe9ff}.nexa-workspace-status.ok{border-color:#2c7b49;background:#0d2b1b;color:#d9ffe5}.nexa-workspace-status.bad{border-color:#8d3640;background:#33151a;color:#ffd9dd}
.nexa-workspace-actions{display:flex;flex-wrap:wrap;gap:8px}.nexa-workspace-actions button{min-height:38px}
@media(max-width:700px){.nexa-workspace-actions button{flex:1 1 100%}}
</style></head><body class="login-body">
<?php if($registerMode): ?>
<form class="login-card auth-card" method="post" action="?register=1">
  <div class="login-logo-wrap"><img class="login-logo" src="assets/nexa-logo.png" alt="Nexa AI"></div>
  <h1>Crear cuenta</h1>
  <p>Regístrate para usar tu Nexa privado.</p>
  <?php if($registerError):?><div class="error-box"><?=htmlspecialchars($registerError)?></div><?php endif;?>
  <input type="text" name="register_name" placeholder="Nombre" autocomplete="name" maxlength="100" value="<?=htmlspecialchars((string)($_POST['register_name'] ?? ''))?>" autofocus required>
  <input type="email" name="register_email" placeholder="Email" autocomplete="email" maxlength="190" value="<?=htmlspecialchars((string)($_POST['register_email'] ?? ''))?>" required>
  <input type="password" name="register_password" placeholder="Contraseña · mínimo 8 caracteres" autocomplete="new-password" minlength="8" required>
  <input type="hidden" name="register_csrf" value="<?=htmlspecialchars($publicCsrf)?>">
  <button type="submit" name="register_submit" value="1">Crear mi cuenta</button>
  <div class="auth-switch">¿Ya tienes una cuenta? <a href="./">Iniciar sesión</a></div>
</form>
<?php else: ?>
<form class="login-card auth-card" method="post" action="./">
  <div class="login-logo-wrap"><img class="login-logo" src="assets/nexa-logo.png" alt="Nexa AI"></div>
  <h1>Nexa AI Web</h1>
  <p>Inicia sesión para abrir tu Nexa.</p>
  <?php if($error):?><div class="error-box"><?=htmlspecialchars($error)?></div><?php endif;?>
  <input type="text" name="login_username" placeholder="Usuario o email" autocomplete="username" autofocus required>
  <input type="password" name="login_password" placeholder="Contraseña" autocomplete="current-password" required>
  <button type="submit">Entrar</button>
  <div class="auth-divider"><span>o</span></div>
  <a class="register-button" href="?register=1">Crear cuenta</a>
</form>
<?php endif; ?>
</body></html><?php exit; endif;
$csrf = nexa_csrf();
$isAdmin = ($user['role'] ?? '') === 'admin';
$displayName = trim((string)($user['display_name'] ?? '')) ?: (string)$user['username'];
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="nexa-csrf" content="<?=htmlspecialchars($csrf)?>"><meta name="nexa-user-id" content="<?=(int)$user['id']?>"><meta name="nexa-user-role" content="<?=htmlspecialchars((string)$user['role'])?>"><meta name="nexa-username" content="<?=htmlspecialchars((string)$user['username'])?>"><title>Nexa AI Web</title><link rel="icon" type="image/png" href="assets/nexa-favicon.png"><link rel="stylesheet" href="assets/app.css?v=3800"><style id="nexa-chat-white-canvas-v233">
/* Nexa AI Web v2.3.3 · white CHAT canvas preview only.
   Keep sidebar, topbar, message cards, composer and every other view unchanged. */
#view-chat,
#view-chat.active,
#view-chat .messages {
  background:#ffffff !important;
}

/* v2.5.4 · Chat PC Workspace setup */
.nexa-workspace-dialog{width:min(720px,calc(100vw - 32px));border:1px solid #27445f;border-radius:16px;background:#0c1b2a;color:#eef7ff;padding:0;box-shadow:0 28px 90px rgba(0,0,0,.5)}
.nexa-workspace-dialog::backdrop{background:rgba(1,9,16,.72);backdrop-filter:blur(3px)}
.nexa-workspace-dialog form{margin:0}.nexa-workspace-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:18px 20px;border-bottom:1px solid #223a51;background:#0a1724}
.nexa-workspace-head strong{display:block;font-size:17px}.nexa-workspace-head small{display:block;color:#96adc1;margin-top:3px}.nexa-workspace-close{width:34px;height:34px;border-radius:10px;font-size:20px}
.nexa-workspace-body{display:grid;gap:15px;padding:20px}.nexa-workspace-body label{display:grid;gap:7px;font-weight:700}.nexa-workspace-body input,.nexa-workspace-body select{width:100%;box-sizing:border-box}
.nexa-workspace-roots{display:grid;gap:6px;padding:12px;border:1px solid #243d54;border-radius:12px;background:#081522}.nexa-workspace-roots code{display:block;white-space:normal;word-break:break-all;background:#dbe8f2;color:#09121b;padding:6px 8px;border-radius:7px}
.nexa-workspace-status{min-height:22px;padding:10px 12px;border-radius:10px;background:#0a2030;border:1px solid #26445e;color:#cfe9ff}.nexa-workspace-status.ok{border-color:#2c7b49;background:#0d2b1b;color:#d9ffe5}.nexa-workspace-status.bad{border-color:#8d3640;background:#33151a;color:#ffd9dd}
.nexa-workspace-actions{display:flex;flex-wrap:wrap;gap:8px}.nexa-workspace-actions button{min-height:38px}
@media(max-width:700px){.nexa-workspace-actions button{flex:1 1 100%}}
</style></head><body class="role-<?=htmlspecialchars((string)$user['role'])?>">
<div id="app" class="app-shell">
  <aside class="sidebar">
    <div class="brand"><img class="brand-logo" src="assets/nexa-logo.png" alt="Nexa AI"><div><strong>Nexa AI</strong><span><?=$isAdmin?'Admin Web':'Web Chat'?></span></div></div>
    <button id="newChatBtn" class="primary wide">+ Nueva conversación</button>
    <nav class="tabs">
      <button data-view="chat" class="tab active">💬 Chat</button>
      <?php if($isAdmin): ?>
      <button data-view="projects" class="tab">▣ Projects</button>
      <button data-view="images" class="tab">🖼️ Image Studio</button>
      <button data-view="memory" class="tab">🧠 Memoria</button>
      <button data-view="knowledge" class="tab">📚 Conocimiento</button>
      <button data-view="settings" class="tab">⚙️ Ajustes</button>
      <button data-view="users" class="tab">👥 Usuarios</button>
      <?php endif; ?>
    </nav>
    <div class="section-title chat-section-title"><span>Conversaciones</span><span id="chatCount" class="chat-count">0</span></div><div id="chatList" class="chat-list"></div>
    <div class="sidebar-bottom"><div><div id="agentBadge" class="status-dot offline">PC offline</div><div class="account-mini"><?=htmlspecialchars($displayName)?><?=$isAdmin?' · Admin':''?></div></div><a href="logout.php">Salir</a></div>
  </aside>
  <main class="main">
    <header class="topbar"><div><h2 id="viewTitle">Chat</h2><small id="systemLine">Esperando conexión con Nexa…</small></div><?php if($isAdmin): ?><div class="top-actions"><span id="projectActiveBadge" class="pill hidden">Project</span><span id="forgeBadge" class="pill">Forge ?</span><span id="ollamaBadge" class="pill">Ollama ?</span></div><?php endif; ?></header>

    <section id="view-chat" class="view active">
      <?php if($isAdmin): ?>
      <div id="chatDeveloperDock" class="chat-developer-dock">
        <div id="chatDeveloperStatus" class="chat-developer-status"><strong>Developer</strong><span>Selecciona un proyecto para trabajar desde el Chat</span></div><span id="chatDevRouteBadge" class="developer-runtime-badge off" title="Routing obligatorio del Chat al Developer">DEV ROUTE OFF</span><span class="developer-runtime-badge ready" style="margin-left:0" title="Nexa Developer Platform v3.8.0: qwen2.5-coder:7b file-by-file completion engine + Internet-first research + local runtime tools">ORCH v3.8.0</span><span id="chatDevRuntimeBadge" class="developer-runtime-badge off" title="Estado del Developer Runtime local">PC Developer ?</span><span id="chatDevCoderBadge" class="developer-runtime-badge off" title="Cerebro dedicado de Nexa Developer">Coder ?</span>
        <div class="chat-developer-controls">
          <select id="chatProjectSelect" title="Proyecto activo"><option value="">Sin proyecto activo</option></select>
          <select id="chatDeveloperMode" title="Cómo decide el Chat cuándo usar Developer"><option value="auto">Developer · Auto</option><option value="on">Developer · Siempre</option><option value="off">Developer · Off</option></select><button id="chatDeveloperTestBtn" type="button" title="Prueba directa Web → PC Runtime sin usar el modelo">⚡ Test PC Developer</button><button id="chatWorkspaceBtn" type="button" title="Configurar la carpeta local del proyecto en tu PC">📁 PC Workspace</button><button id="chatDevResumeBtn" type="button" title="Reanudar una tarea Developer pausada" disabled>↻ Resume</button><button id="chatDevTasksBtn" type="button" title="Abrir Task Center persistente">⚙ Tasks</button>
          <button id="chatDevQaBtn" type="button" title="Ejecutar QA del proyecto" disabled>✓ QA</button>
          <a id="chatDevZipBtn" class="chat-dev-link disabled" href="#" title="Descargar ZIP completo del proyecto">📦 ZIP Full</a>
          <button id="chatDevOpenBtn" type="button" title="Abrir Projects" disabled>▣ Projects</button>
        </div>
      </div>
      <div id="developerLiveBar" class="developer-live-bar hidden" role="status" aria-live="polite">
        <span class="developer-live-orb" aria-hidden="true"><i></i></span>
        <div class="developer-live-copy"><strong id="developerLiveTitle">Nexa sigue trabajando en segundo plano</strong><small id="developerLiveDetail">Preparando tarea…</small><div class="developer-live-progress"><i id="developerLiveProgress" style="width:4%"></i></div></div>
        <span id="developerLiveElapsed" class="developer-live-elapsed">0m 0s</span>
        <button id="developerLiveTasksBtn" type="button">⚙ Ver progreso</button>
      </div>
      <dialog id="chatWorkspaceDialog" class="nexa-workspace-dialog">
        <form method="dialog">
          <div class="nexa-workspace-head"><div><strong>📁 PC Workspace</strong><small>Proyecto: <span id="chatWorkspaceProjectName">—</span></small></div><button class="nexa-workspace-close" value="cancel" title="Cerrar">×</button></div>
          <div class="nexa-workspace-body">
            <label>Workspace local en PC<input id="chatWorkspaceRoot" placeholder="D:\Projects\MiProyecto" autocomplete="off" spellcheck="false"></label>
            <div><small class="muted">Debe ser una carpeta real de tu PC. Puede estar dentro de uno de los Allowed Roots actuales o puedes autorizarla desde aquí.</small></div>
            <div id="chatWorkspaceAllowedRoots" class="nexa-workspace-roots"><small>Allowed Roots: consultando…</small></div>
            <label>Motor Developer<select id="chatWorkspaceMode"><option value="hybrid">Híbrido · Web + PC</option><option value="local">PC Runtime primero</option><option value="web">Sólo Workspace Web</option></select></label>
            <div id="chatWorkspaceStatus" class="nexa-workspace-status">Configura una ruta y guárdala.</div>
            <div class="nexa-workspace-actions">
              <button id="chatWorkspaceSaveBtn" type="button" class="primary">Guardar Workspace</button>
              <button id="chatWorkspaceAuthorizeBtn" type="button">⛨ Guardar y autorizar</button>
              <button id="chatWorkspaceTestBtn" type="button">⚡ Guardar y probar</button>
              <button id="chatWorkspaceSyncBtn" type="button" title="Copia archivos de texto/código del Workspace Web al Workspace local; Nexa Runtime hace backup si ya existen">⇩ Web → PC</button>
              <button type="submit" value="cancel">Cerrar</button>
            </div>
          </div>
        </form>
      </dialog>
      <dialog id="chatDevTasksDialog" class="nexa-devtasks-dialog">
        <form method="dialog">
          <div class="nexa-workspace-head"><div><strong>⚙ Developer Task Center</strong><small>Runs persistentes del proyecto activo</small></div><button class="nexa-workspace-close" value="cancel" title="Cerrar">×</button></div>
          <div class="nexa-devtasks-body">
            <div id="chatDevCurrentRun" class="nexa-devtasks-current">No hay una tarea Developer activa.</div>
            <div class="nexa-devtasks-actions"><button id="chatDevTasksRefreshBtn" type="button">↻ Actualizar</button><button id="chatDevTasksResumeBtn" type="button" disabled>▶ Resume</button><button id="chatDevTasksCancelBtn" type="button" disabled>× Cancelar</button><button type="submit" value="cancel">Cerrar</button></div>
            <div id="chatDevTasksList" class="nexa-devtasks-list"><small class="muted">Sin runs persistentes.</small></div>
          </div>
        </form>
      </dialog>
      <?php endif; ?>
      <div id="messages" class="messages"></div>
      <div id="progressBox" class="progress-box hidden" role="status" aria-live="polite" aria-atomic="true"></div>
      <div id="attachmentTray" class="attachment-tray"></div>
      <div class="composer"><button id="attachBtn" class="icon-btn" title="Adjuntar">＋</button><input id="fileInput" type="file" multiple hidden accept="image/*,.pdf,.docx,.txt,.md,.csv,.json"><textarea id="promptInput" rows="1" placeholder="Escribe a Nexa…"></textarea><button id="stopBtn" class="danger hidden">Detener</button><button id="sendBtn" class="primary">Enviar</button></div>
    </section>

    <?php if($isAdmin): ?>

    <section id="view-projects" class="view">
      <div class="projects-root">
        <div class="projects-toolbar">
          <select id="projectSelect" aria-label="Proyecto activo"><option value="">Selecciona un proyecto…</option></select>
          <button id="projectNewBtn" class="primary">＋ Proyecto</button>
          <button id="projectImportBtn">⇧ Importar ZIP</button>
          <input id="projectZipInput" type="file" accept=".zip,application/zip" hidden>
          <button id="projectSnapshotBtn">◫ Snapshot</button>
          <button id="projectValidateBtn">✓ Validar</button>
          <a id="projectUpdateZip" class="tool-link disabled" href="#">⇩ ZIP Update</a>
          <a id="projectFullZip" class="tool-link disabled" href="#">⇩ ZIP Completo</a>
        </div>
        <div id="projectStatus" class="project-status muted">Crea o selecciona un proyecto para comenzar.</div>
        <div id="projectEmpty" class="project-empty">
          <div class="project-empty-icon">▣</div>
          <h3>Nexa Project Workspace</h3>
          <p>Carga un ZIP de tu proyecto web o crea uno vacío. Nexa Web conservará archivos, memoria, tareas, snapshots y contexto técnico del proyecto.</p>
        </div>
        <div id="projectWorkspace" class="project-workspace hidden">
          <aside class="project-files-pane">
            <div class="pane-head"><strong>Archivos</strong><button id="projectNewFileBtn" title="Nuevo archivo">＋</button></div>
            <input id="projectFileSearch" class="project-search" placeholder="Buscar archivos…">
            <div id="projectFileTree" class="project-file-tree"></div>
          </aside>
          <section class="project-editor-pane">
            <div class="editor-head">
              <div class="editor-path-wrap"><span class="editor-dot"></span><strong id="projectEditorPath">Selecciona un archivo</strong></div>
              <div class="editor-actions">
                <button id="projectContextBtn" disabled>◇ Contexto</button>
                <button id="projectDiffBtn" disabled>⇄ Diff</button>
                <button id="projectRenameFileBtn" disabled>✎ Renombrar</button>
                <button id="projectDeleteFileBtn" class="danger-mini" disabled>× Eliminar</button>
                <button id="projectSaveFileBtn" class="primary" disabled>Guardar</button>
              </div>
            </div>
            <textarea id="projectEditor" class="code-editor" spellcheck="false" placeholder="Selecciona un archivo de texto para editarlo…" disabled></textarea>
            <div class="editor-footer"><span id="projectEditorMeta">Sin archivo abierto</span><span id="projectEditorDirty"></span></div>
            <div id="projectDiffBox" class="project-diff hidden"></div>
          </section>
          <aside class="project-side-pane">
            <details open class="project-card"><summary>Proyecto</summary><div class="project-card-body">
              <label>Nombre<input id="projectNameInput"></label>
              <label>Baseline / versión<input id="projectBaselineInput" placeholder="Ej. v2.0.16"></label>
              <label>Base URL general<input id="projectBaseUrlInput" placeholder="https://tu-dominio.com"></label>
              <label>Staging URL<input id="projectStagingUrlInput" placeholder="https://staging.tu-dominio.com"></label>
              <label>Production URL<input id="projectProductionUrlInput" placeholder="https://tu-dominio.com"></label>
              <label>Modo de aprobación<select id="projectApprovalMode"><option value="manual">Manual · aprobar cada cambio</option><option value="semi">Semi Auto · aprobar primera escritura</option><option value="auto">Auto · trabajar sin detenerse</option></select></label>
              <label>GitHub repo<input id="projectGithubRepo" placeholder="https://github.com/owner/repo"></label>
              <label>GitHub branch<input id="projectGithubBranch" placeholder="main"></label>
              <label>Workspace local en PC<input id="projectLocalRoot" placeholder="D:\Projects\MiProyecto"></label>
              <label>Motor Developer<select id="projectDeveloperMode"><option value="hybrid">Híbrido · Web + PC</option><option value="local">PC Runtime primero</option><option value="web">Sólo Workspace Web</option></select></label>
              <p class="muted tiny">La ruta local debe existir dentro de <b>Allowed Roots</b> de Nexa Software v2.5.0. No se envía el contenido completo del proyecto al navegador.</p>
              <label>Descripción<textarea id="projectDescriptionInput" rows="3"></textarea></label>
              <div class="project-inline-actions"><button id="projectSaveInfoBtn">Guardar info</button><button id="projectOpenRepoBtn">↗ GitHub</button><button id="projectDeleteBtn" class="danger-mini">Eliminar proyecto</button></div>
            </div></details>
            <details open class="project-card agent-card"><summary>✦ Developer Agent</summary><div class="project-card-body">
              <p class="muted tiny">Nexa puede leer, buscar, editar y validar este workspace usando herramientas web. Se crea un snapshot automático antes de modificar.</p>
              <textarea id="projectAgentPrompt" rows="4" placeholder="Ej. Agrega recuperación de contraseña sin romper el login actual."></textarea>
              <label class="agent-auto-repair"><input id="projectAutoRepair" type="checkbox" checked> Auto-QA + hasta 2 reparaciones automáticas antes de terminar</label>
              <div class="project-agent-actions"><button id="projectAgentRunBtn" class="primary wide">✦ Ejecutar Developer Agent</button><button id="projectAgentStopBtn" class="danger hidden">Detener</button></div>
              <div id="projectAgentLog" class="project-agent-log"></div>
            </div></details>
            <details open class="project-card runtime-card"><summary>⚡ Developer Runtime · PC</summary><div class="project-card-body">
              <div class="runtime-head">
                <span id="projectRuntimeBadge" class="developer-runtime-badge off">PC Developer ?</span>
                <button id="projectRuntimeRefreshBtn" type="button">↻ Estado</button>
              </div>
              <div id="projectRuntimeSummary" class="runtime-summary muted tiny">Instala/abre Nexa Software v2.5.0 y configura un Workspace local.</div>
              <div id="projectRuntimeRoots" class="runtime-roots"></div>
              <div class="runtime-tool-grid">
                <button id="projectLocalIndexBtn" type="button">⌘ Indexar código</button>
                <button id="projectLocalSecurityBtn" type="button">⛨ Security Scan</button>
                <button id="projectLocalGitBtn" type="button">⑂ Git Status</button>
                <button id="projectLocalJobsBtn" type="button">↻ Jobs / Resume</button>
                <button id="projectRuntimeAuthorizeBtn" type="button">⛨ Autorizar Workspace</button>
              </div>
              <div class="runtime-terminal">
                <strong>Terminal segura</strong>
                <div class="runtime-inline">
                  <select id="projectTerminalCommand"><option>node</option><option>npm</option><option>php</option><option>composer</option><option>python</option><option>git</option></select>
                  <input id="projectTerminalArgs" placeholder='Args: --check assets/app.js'>
                  <button id="projectTerminalRunBtn" type="button">▶ Ejecutar</button>
                </div>
                <pre id="projectTerminalOutput" class="runtime-output">Sin ejecución.</pre>
              </div>
              <div class="runtime-browser">
                <strong>Browser Agent local</strong>
                <div class="runtime-inline">
                  <input id="projectLocalBrowserUrl" placeholder="https://staging.tu-dominio.com">
                  <button id="projectLocalBrowserBtn" type="button">◎ Abrir + Screenshot</button>
                </div>
                <div id="projectLocalBrowserResult" class="runtime-output runtime-browser-result">Sin prueba local.</div>
              </div>
              <div class="runtime-jobs-wrap"><strong>Jobs persistentes</strong><div id="projectLocalJobsList" class="project-mini-list"><span class="muted tiny">Pulsa Jobs / Resume.</span></div></div>
            </div></details>
            <details open class="project-card qa-card"><summary>✓ QA / Test Runner</summary><div class="project-card-body">
              <p class="muted tiny">Valida sintaxis cuando el hosting permite PHP/Node y ejecuta pruebas HTTP contra la Base URL. Si Node o proc_open no existen, lo muestra claramente y usa los chequeos disponibles.</p>
              <div id="projectQaCapabilities" class="qa-capabilities"></div>
              <div class="qa-run-row"><select id="projectQaTarget"><option value="base">Base URL</option><option value="staging">Staging</option><option value="production">Production</option></select><button id="projectRunQaBtn" class="primary">✓ Ejecutar QA completo</button></div>
              <div id="projectQaSummary" class="project-mini-list"><span class="muted tiny">QA aún no ejecutado.</span></div>
              <div class="qa-test-builder">
                <input id="projectTestName" placeholder="Nombre del test">
                <input id="projectTestPath" placeholder="/login.php" value="/">
                <input id="projectTestStatus" type="number" min="100" max="599" value="200" title="HTTP esperado">
                <input id="projectTestContains" placeholder="Texto esperado (opcional)">
                <button id="projectAddTestBtn">＋</button>
              </div>
              <div id="projectTestList" class="project-mini-list"></div>
            </div></details>
            <details open class="project-card browser-card"><summary>◎ Browser QA / Preview</summary><div class="project-card-body">
              <div class="browser-controls"><select id="projectBrowserTarget"><option value="base">Base</option><option value="staging">Staging</option><option value="production">Production</option></select><input id="projectBrowserPath" value="/" placeholder="/ruta"><button id="projectBrowserLoadBtn">↻</button><button id="projectBrowserProbeBtn">◎ Probe</button><button id="projectBrowserOpenBtn">↗</button></div>
              <div id="projectBrowserFrameWrap" class="browser-frame-wrap"><iframe id="projectBrowserFrame" title="Project browser preview" sandbox="allow-forms allow-scripts allow-same-origin allow-popups"></iframe></div>
              <div id="projectBrowserProbeResult" class="project-mini-list"><span class="muted tiny">Carga una URL del proyecto o ejecuta Probe para revisar HTML/HTTP.</span></div>
            </div></details>
            <details class="project-card visual-card"><summary>◉ Visual QA · Qwen</summary><div class="project-card-body">
              <p class="muted tiny">Sube una captura real. La imagen viaja por el sistema de adjuntos de Nexa para revisión visual. El reporte queda asociado al proyecto.</p>
              <input id="projectVisualFile" type="file" accept="image/png,image/jpeg,image/webp">
              <div class="project-inline-actions"><select id="projectVisualTarget"><option value="manual">Captura manual</option><option value="staging">Staging</option><option value="production">Production</option></select><button id="projectVisualRunBtn" class="primary">◉ Analizar captura</button><button id="projectVisualRepairBtn" disabled>↻ Reparar con Agent</button></div>
              <div id="projectVisualResult" class="visual-report"><span class="muted tiny">Sin análisis visual todavía.</span></div>
            </div></details>
            <details class="project-card"><summary>▦ Database Inspector</summary><div class="project-card-body">
              <div class="project-inline-actions"><button id="projectDatabaseScanBtn">▦ Inspeccionar bases</button></div>
              <div id="projectDatabaseBox" class="project-map-box"><span class="muted tiny">Lee esquema de SQLite/SQL dentro del workspace sin modificar datos.</span></div>
            </div></details>
            <details class="project-card"><summary>🔐 Secrets Manager</summary><div class="project-card-body">
              <p class="muted tiny">Los valores se cifran en el servidor y nunca se agregan al contexto del modelo.</p>
              <div class="secret-add"><input id="projectSecretName" placeholder="API_KEY"><input id="projectSecretValue" type="password" placeholder="Valor secreto"><button id="projectSecretSaveBtn">Guardar</button></div>
              <div id="projectSecretList" class="project-mini-list"></div>
            </div></details>
            <details class="project-card release-card"><summary>⬡ Release Manager</summary><div class="project-card-body">
              <div class="release-builder"><input id="projectReleaseVersion" placeholder="v2.3.0"><select id="projectReleaseTarget"><option value="base">QA Base</option><option value="staging">QA Staging</option><option value="production">QA Production</option></select><textarea id="projectReleaseNotes" rows="2" placeholder="Notas del release"></textarea><button id="projectReleaseBtn" class="primary">⬡ QA + Crear Release</button></div>
              <div id="projectReleaseList" class="project-mini-list"><span class="muted tiny">Sin releases creados.</span></div>
            </div></details>
            <details class="project-card"><summary>⌘ Project Map</summary><div class="project-card-body">
              <div class="project-inline-actions"><button id="projectMapRefreshBtn">⌘ Analizar código</button></div>
              <div id="projectMapBox" class="project-map-box"><span class="muted tiny">Analiza funciones, clases, endpoints, tablas e includes del workspace.</span></div>
            </div></details>
            <details class="project-card"><summary>⛨ Guardrails</summary><div class="project-card-body">
              <p class="muted tiny">Las rutas protegidas se bloquean en el servidor incluso si el Developer Agent intenta modificarlas. Admite patrones como <code>data/*.sqlite</code> o <code>vendor/*</code>.</p>
              <div class="guardrail-add"><input id="projectGuardPattern" placeholder="data/*.sqlite"><input id="projectGuardLabel" placeholder="Motivo"><button id="projectGuardAddBtn">＋</button></div>
              <div id="projectGuardList" class="project-mini-list"></div>
            </div></details>
            <details class="project-card"><summary>≡ Change Journal</summary><div class="project-card-body"><div id="projectJournalList" class="project-mini-list project-journal-list"></div></div></details>
            <details class="project-card"><summary>Memoria del proyecto</summary><div class="project-card-body">
              <div class="project-memory-add"><select id="projectMemoryKind"><option value="note">Nota</option><option value="rule">Regla</option><option value="decision">Decisión</option><option value="baseline">Baseline</option></select><input id="projectMemoryInput" placeholder="Nueva memoria técnica…"><button id="projectMemoryAddBtn">＋</button></div>
              <div id="projectMemoryList" class="project-mini-list"></div>
            </div></details>
            <details class="project-card"><summary>Tareas</summary><div class="project-card-body">
              <div class="project-task-add"><input id="projectTaskInput" placeholder="Nueva tarea…"><button id="projectTaskAddBtn">＋</button></div>
              <div id="projectTaskList" class="project-mini-list"></div>
            </div></details>
            <details class="project-card"><summary>Versiones / Snapshots</summary><div class="project-card-body"><div id="projectVersionList" class="project-mini-list"></div></div></details>
            <details class="project-card"><summary>Validación</summary><div class="project-card-body"><div id="projectValidation" class="project-mini-list"><span class="muted">Aún no ejecutada.</span></div></div></details>
          </aside>
        </div>
      </div>
    </section>

    <section id="view-images" class="view">
      <div class="split"><div class="panel"><h3>Forge Image Studio</h3><label>Prompt<textarea id="imgPrompt" rows="7" placeholder="Describe la imagen..."></textarea></label><label>Negative Prompt<textarea id="imgNegative" rows="4"></textarea></label><div class="form-grid"><label>Modelo<select id="forgeModel"></select></label><label>Sampler<select id="forgeSampler"></select></label><label>Scheduler<select id="forgeScheduler"></select></label><label>Upscaler<select id="forgeUpscaler"></select></label><label>Preset<select id="imgPreset"><option value="1024x1024">1024×1024</option><option value="1024x576">16:9 base</option><option value="768x1024">Vertical</option><option value="3840x2160">4K UHD 3840×2160</option><option value="2160x3840">4K Vertical 2160×3840</option></select></label><label>Steps<input id="imgSteps" type="number" min="10" max="60" value="28"></label><label>CFG<input id="imgCfg" type="number" min="1" max="15" step="0.5" value="6.5"></label><label>Denoise<input id="imgDenoise" type="number" min="0" max="1" step="0.05" value="0.25"></label><label>Seed<input id="imgSeed" type="number" value="-1"></label><label class="check"><input id="imgHires" type="checkbox" checked> Hires Fix</label></div><button id="generateImageBtn" class="primary wide">Generar con Forge</button><div id="imgProgress" class="progress-box hidden"></div></div><div class="panel result-panel"><div id="imgResult" class="image-result"><span>La imagen aparecerá aquí</span></div></div></div>
    </section>
    <section id="view-memory" class="view"><div class="panel"><h3>Memoria de Nexa</h3><div class="inline"><input id="memoryInput" placeholder="Nuevo recuerdo"><button id="saveMemoryBtn" class="primary">Guardar</button></div><div id="memoryList" class="list"></div></div></section>
    <section id="view-knowledge" class="view"><div class="panel"><h3>Conocimiento local</h3><div class="inline"><input id="knowledgeInput" placeholder="Buscar en conocimiento..."><button id="knowledgeSearchBtn" class="primary">Buscar</button></div><div id="knowledgeResults" class="list"></div></div></section>
    <section id="view-settings" class="view"><div class="panel"><h3>Ajustes controlados desde la web</h3><div id="pairingBox" style="margin:0 0 18px;padding:16px;border:1px solid #2a4160;border-radius:14px;background:#0a1523"><h3 style="margin:0 0 8px">Conexión con esta PC</h3><p id="pairingText" class="muted" style="margin:0 0 12px">La página está funcionando, pero Nexa local todavía no está conectado.</p><a class="primary" href="download-connector.php" style="display:inline-block;text-decoration:none">Descargar CONNECT-NEXA-WEB.cmd</a><p class="muted" style="margin:12px 0 0">Ejecuta ese archivo una sola vez, cierra y vuelve a abrir Nexa AI y espera unos 10 segundos.</p></div><div class="form-grid"><label>Modelo Ollama<input id="setModel"></label><label>Perfil<select id="setProfile"><option value="fast">Rápido</option><option value="light">Ligero</option></select></label><label>Contexto<input id="setContext" type="number" min="1024" max="32768"></label><label>Forge URL<input id="setForgeUrl" value="http://127.0.0.1:7860"></label></div><button id="saveSettingsBtn" class="primary">Guardar en Nexa</button> <button id="resetTransportBtn" type="button">Reiniciar transporte web</button><p id="transportState" class="muted" style="margin-top:10px"></p><hr><div id="statusDetails" class="status-grid"></div></div></section>
    <section id="view-users" class="view"><div class="panel users-panel"><div class="users-head"><div><h3>Usuarios de Nexa AI Web</h3><p class="muted">Cada usuario tiene conversaciones privadas separadas. Las cuentas normales sólo ven Chat.</p></div><span class="admin-badge">Administrador oficial</span></div><div class="user-create-grid"><label>Nombre<input id="newUserDisplay" placeholder="Ej. Carlos"></label><label>Usuario<input id="newUserName" placeholder="carlos"></label><label>Contraseña<input id="newUserPassword" type="password" placeholder="Mínimo 8 caracteres"></label><button id="createUserBtn" class="primary">+ Crear usuario</button></div><div id="userAdminMessage" class="muted user-admin-message"></div><div id="usersList" class="users-list"></div></div></section>
    <?php endif; ?>
  </main>
</div><script src="assets/app.js?v=3800"></script><script src="assets/developer-chat-bridge.js?v=2700"></script></body></html>
