<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/api/common.php';
if(!nexa_is_setup()){header('Location: ../setup.php');exit;}
$user=nexa_current_user();if(!$user){header('Location: ../');exit;}
if(($user['role']??'')!=='admin'){http_response_code(403);exit('Developer: solo administrador.');}
$csrf=nexa_csrf();
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="nexa-csrf" content="<?=htmlspecialchars($csrf,ENT_QUOTES)?>">
<title>Nexa Developer · Web Control v16.10</title><link rel="icon" href="../assets/nexa-favicon.png"><link rel="stylesheet" href="assets/developer.css?v=16"></head>
<body>
<div class="layout">
<aside class="sidebar"><div class="brand"><img src="../assets/nexa-logo.png" alt="Nexa"><div><strong>NEXA DEV</strong><small>WEB CONTROL CENTER</small></div></div>
<a class="back" href="../">← Volver a Nexa Web</a>
<div class="nav-title">CENTRO DE CONTROL</div><nav id="devTabs">
<button data-tab="chat" class="active">✦ Chat Developer</button>
<button data-tab="work">▣ Trabajo autónomo</button>
<button data-tab="model">◉ Modelo Developer</button>
<button data-tab="tools">⌘ Herramientas</button>
<button data-tab="planning">◇ Planificador</button>
<button data-tab="limits">◷ Tiempo y límites</button>
<button data-tab="memory">▤ Memoria de ejecución</button>
<button data-tab="editing">✎ Programación y parches</button>
<button data-tab="qa">✓ QA por proyecto</button>
<button data-tab="repair">↻ Motor de reparación</button>
<button data-tab="evaluation">◎ Evaluador independiente</button>
<button data-tab="delivery">⇩ Entregas y ZIP</button>
<button data-tab="tracking">▥ Seguimiento</button>
</nav><div class="sidebar-foot"><div id="bridgeBadge" class="badge muted">PC: sin comprobar</div><p>Solo Qwen2.5-Coder 7B. Los originales nunca se editan desde esta consola.</p></div></aside>
<main class="main"><header><div><small>NEXA AI · NUEVA ARQUITECTURA WEB</small><h1 id="panelTitle">Trabajo autónomo</h1></div><div class="top-actions"><span id="saveState" class="badge">Configuración web</span><button id="saveSettings" class="primary">Guardar parámetros</button></div></header>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
<section class="panel visible" data-panel="chat">
  <div class="heading"><h2>Chat Developer · las 12 áreas conectadas</h2>
    <p>Las instrucciones crean trabajos en el motor real de Nexa Developer. Qwen2.5-Coder 7B se consulta en Windows mediante la cola existente; todos los archivos, herramientas, QA, reparaciones, evaluaciones y ZIP permanecen en Hostinger. Este chat es independiente del Chat normal y de Image Studio.</p></div>
  <div class="form-grid">
    <label>Proyecto importado<select id="chatProjectSelect"><option value="">Selecciona un proyecto…</option></select></label>
    <label>Conversaciones de este proyecto<select id="chatThreadSelect"><option value="">Nueva conversación…</option></select></label>
  </div>
  <div class="inline-actions"><button id="chatNew" class="secondary" type="button">＋ Nueva conversación</button>
    <button id="chatProbeQwen" class="secondary" type="button">Probar Qwen real</button>
    <button id="chatRefresh" class="secondary" type="button">Actualizar conversación</button>
    <button id="chatOpenRun" class="secondary" type="button">Abrir tarea en Trabajo autónomo</button></div>
  <div class="notice"><strong>Puente Windows:</strong> si Qwen se queda esperando o marca timeout, primero <a href="pair-windows.php" target="_blank" rel="noopener noreferrer">verifica y conecta ESTA copia Developer</a>. No uses el conector de la página principal para cambiar el servidor original.</div>
  <div id="chatProbeResult" class="notice">Conexión Qwen sin probar en esta sesión. No se considerará que el modelo está conectado hasta recibir una respuesta real.</div>
  <div id="chat16Status" class="notice">Selecciona un proyecto, crea una conversación y envía una tarea de programación. El progreso proviene de Hostinger y de la cola real de Qwen.</div>
  <div id="chat16Messages" class="devchat-messages" aria-live="polite"><div class="devchat-empty">Aquí aparecerán tus instrucciones y el estado comprobable de cada ejecución.</div></div>
  <div id="chat16Events" class="devchat-events" aria-live="polite"></div>
  <label>Escribe una tarea para Qwen (se desarrollará en una copia aislada de Hostinger)
    <textarea id="chat16Input" rows="4" maxlength="12000" placeholder="Ejemplo: revisa README.md y crea un archivo CHANGELOG_NEXA.txt con un resumen comprobable. Ejecuta QA y prepara un ZIP de cambios. No toques el proyecto original."></textarea></label>
  <div class="inline-actions"><button id="chat16Send" class="primary big" type="button">➤ Enviar a Qwen Developer</button>
    <span class="muted">Cuando una tarea siga ejecutándose, espera su finalización antes de enviar la siguiente. Cron de Hostinger puede continuarla con la página cerrada.</span></div>
</section>
<section class="panel" data-panel="work"><div class="heading"><h2>Nuevo proyecto y tarea</h2><p>Laboratorio web con proyecto ZIP importado. Qwen se consulta desde Windows sin editar sus archivos. Qwen y toda la orquestación permanecen controlados desde esta web.</p></div><div class="notice"><strong>Modo actual:</strong> <span id="modeStatus">Cargando…</span>. La programación se realiza en la web. El original no se modifica.</div>
<div class="form-grid"><label>Proyecto<select id="projectSelect"><option value="">Cargando proyectos...</option></select></label>
<div class="label-row"><label>Nuevo proyecto<input id="newProject" placeholder="Nombre del proyecto"></label><button id="createProject" class="secondary">Crear</button></div></div>
<div class="form-grid"><label style="display:none">Ruta heredada (no se utiliza en Developer Web)<input id="pcLocalRoot" placeholder=""></label><label>URL HTTPS de staging (Browser QA)<input id="stagingUrl" placeholder="https://staging.ejemplo.com"></label></div>
<div class="inline-actions"><button id="saveProjectLocal" class="secondary">Guardar URL de staging</button></div>
<div class="notice"><strong>Conexión con esta copia de Nexa Web</strong><p>Si duplicas la página en otra ruta o dominio, Windows puede seguir consultando la URL anterior. La prueba de conexión confirma si realmente recibe órdenes desde esta copia. <a href="pair-windows.php">Conectar esta copia como SEGUNDO destino Windows</a> (sin reinstalar EXE ni reemplazar la conexion del sitio original).</p></div>
<div class="inline-actions"><button id="importZip" class="secondary">Importar ZIP al proyecto</button><input id="projectZip" type="file" accept=".zip,application/zip" hidden><a href="../" class="plain-link">Abrir Projects · Archivos</a><button id="probePc" class="secondary">Probar conexión con Windows</button></div>
<section class="inner" id="symbols03Panel"><h3>03 · Funciones, clases y métodos del proyecto</h3>
<p>Analizador web de solo lectura. PHP usa el tokenizador del lenguaje; JavaScript/TypeScript usan detección léxica conservadora. Las referencias mostradas son candidatas y no equivalen a vínculos resueltos por Aider. No cambia archivos ni ejecuta código.</p>
<div class="inline-actions"><label>Buscar símbolo o ruta<input id="symbols03Query" placeholder="Ej.: CustomerService, clientes.php" maxlength="100"></label><button id="symbols03Scan" class="secondary" type="button">Analizar símbolos</button><button id="symbols03More" class="secondary" type="button" disabled>Ver siguientes archivos</button></div>
<div id="symbols03Status" class="muted" role="status">Selecciona un proyecto para examinar su código.</div><div id="symbols03Results" class="list"></div>
<div class="inner" id="aider03Panel"><h4>Aider · Puente seguro de análisis (solo Developer)</h4>
<p>Conserva el análisis Web actual. Aider utiliza una cola Developer independiente de Chat e imágenes. La Web NO enviará órdenes hasta que un Worker Aider anuncie soporte para el protocolo de solo lectura. Los archivos en D: y Hostinger deben coincidir (SHA-256); si no, se descartan los resultados. Sin ejecutable Windows compatible, no se necesitan pruebas repetidas ni se cambia el EXE.</p>
<label>Carpeta del mismo proyecto en Windows (no es la carpeta de Aider)<input id="aider03Root" type="text" placeholder="D:\Projects\MiProyecto" maxlength="700" autocomplete="off" spellcheck="false"></label>
<div class="inline-actions"><button id="aider03SaveRoot" type="button" class="secondary">Guardar ruta del proyecto</button><button id="aider03Health" type="button" class="secondary">Comprobar puente Aider</button><button id="aider03Analyze" type="button" class="secondary" disabled>Analizar con Aider</button></div>
<div id="aider03Status" class="muted" role="status">Pendiente de comprobar el puente. El detector Web sigue funcionando.</div>
<pre id="aider03Output" class="diff" style="white-space:pre-wrap;max-height:260px;overflow:auto">Sin resultado Aider; las referencias Web continúan disponibles.</pre>
</div>
<div class="inner" id="symbols03RefsPanel" hidden><h4>Referencias del símbolo seleccionado</h4>
<div id="symbols03RefsStatus" class="muted" role="status">Selecciona «Buscar usos» en un símbolo.</div>
<div id="symbols03RefsResults" class="list"></div>
<div class="inline-actions"><button id="symbols03RefsMore" class="secondary" type="button" disabled>Buscar en siguientes archivos</button><button id="symbols03RefsClose" class="secondary" type="button">Cerrar referencias</button></div>
</div>
</section>
<label>Instrucción para Qwen<textarea id="request" rows="6" placeholder="Revisa el proyecto, implementa ..., prueba los cambios y entrégame un ZIP con solo archivos modificados."></textarea></label>
<section class="inner"><h3>Pruebas de aceptación reales</h3><p>Opcional: define pruebas instrumentales que Nexa debe superar. El plan de Qwen también puede proponerlas. Los criterios de aquí tienen prioridad y se guardan con el trabajo.</p>
<label>Pruebas JSON — no pegues código PHP; usa criterios concretos<textarea id="acceptanceCriteria" rows="5" spellcheck="false" placeholder='[{"type":"file_changed","path":"clientes.php"},{"type":"file_contains","path":"clientes.php","text":"Sistema de clientes administrado por Nexa AI"},{"type":"syntax","path":"clientes.php"}]'></textarea></label>
<div class="inline-actions"><button id="saveAcceptance" class="secondary" disabled>Guardar criterios del trabajo</button><button id="verifyAcceptance" class="secondary" disabled>✓ Evaluar evidencia disponible</button><a id="downloadQaJson" class="plain-link hidden" href="#">⇩ Descargar reporte QA JSON</a></div>
<div id="acceptanceResults" class="list muted">Los criterios se comprobarán contra el código y las herramientas, no contra las afirmaciones del modelo.</div></section>
<div class="inline-actions"><button id="startRun" class="primary big">▶ Iniciar tarea</button><button id="pauseRun" class="secondary" disabled>Ⅱ Pausar</button><button id="resumeRun" class="secondary" disabled>↻ Reanudar</button><button id="cancelRun" class="danger" disabled>✕ Cancelar</button><button id="undoLast" class="secondary" disabled>↶ Revertir último cambio en copia</button></div>
<div class="status-grid"><div class="stat"><small>ESTADO</small><strong id="runStatus">Sin tarea</strong></div><div class="stat"><small>FASE</small><strong id="runPhase">—</strong></div><div class="stat"><small>PASOS</small><strong id="runSteps">0</strong></div><div class="stat"><small>ARCHIVOS MODIFICADOS</small><strong id="runFiles">0</strong></div></div>
<div class="twocol"><section class="inner"><h3>Objetivos y criterios de aceptación</h3><div id="objectiveList" class="list muted">Aparecerán cuando Qwen genere el plan.</div></section><section class="inner"><h3>Evidencia y QA</h3><div id="qaResults" class="list muted">No hay validaciones todavía.</div></section></div>
<section class="inner"><h3>Archivos propuestos y diffs</h3><div id="changes" class="list muted">No hay cambios todavía.</div><div class="inline-actions"><a id="downloadZip" class="download hidden" href="#">⇩ Descargar ZIP de cambios (revisión)</a><button id="downloadReport" class="secondary">Ver informe de QA</button><button id="refreshRun" class="secondary">Actualizar resultados</button></div><pre id="diffView" class="diff hidden"></pre></section>
<section class="inner"><h3>Acciones y registros</h3><div id="runEvents" class="events">Sin eventos.</div></section>
<section class="inner"><h3>Trabajos anteriores</h3><div id="recentRuns" class="list muted">Cargando historial...</div></section>
</section>
<section class="panel" data-panel="model"><div class="heading"><h2>Modelo dedicado a programación</h2><p>Modelo exclusivo. Las opciones se envían desde Hostinger a Ollama mediante tu Nexa Windows actual.</p></div><div class="form-grid"><label>Motor<input value="qwen2.5-coder:7b" disabled></label><label>Temperatura<input data-cfg="temperature" type="number" min="0" max="1" step="0.01"></label><label>Contexto<input data-cfg="context" type="number" min="2048" max="32768"></label><label>Tokens de respuesta<input data-cfg="tokens" type="number" min="256" max="8192"></label><label>Top P<input data-cfg="topP" type="number" min="0.05" max="1" step="0.05"></label></div></section>
<section class="panel" data-panel="tools"><div class="heading"><h2>Herramientas</h2><p>Herramientas configurables desde Hostinger. Área 2 centralizada en Hostinger: archivos, Git, terminal, SQLite y navegador de staging sobre el proyecto web importado. Nexa Windows solo presta Qwen.</p></div><div id="toolToggles" class="toggles"></div><button id="probeTools" class="secondary">Diagnóstico de herramientas Hostinger</button><pre id="capabilitiesResult" class="diff"></pre>
<section class="inner"><h3>Herramientas disponibles por proyecto</h3><p>Todas las herramientas de desarrollo operan en el laboratorio web. Selecciona y pausa una tarea para ejecutar secuencias verificables sin Qwen.</p>
<button id="toolsCatalog" class="secondary">Consultar catálogo de herramientas de esta tarea</button><pre id="toolsCatalogResult" class="diff"></pre>
<label>Secuencia de herramientas JSON (1–12 pasos)<textarea id="toolSteps" rows="8" spellcheck="false">[{"action":"files_web","operation":"list"}]</textarea></label>
<div class="inline-actions"><button id="toolsExecute" class="secondary">▶ Ejecutar lote en tarea pausada</button><span id="toolsStatus" class="muted">Sin lote manual</span></div>
<pre id="toolsOutput" class="diff"></pre>
<div class="notice"><strong>Área 2 · Web Tools v8:</strong> archivos (hash, lectura, búsqueda, mover, copiar, borrar con manifiesto), Git local, SQLite de ensayo, terminal para sintaxis y pruebas autorizadas, navegador HTTPS staging. Para JavaScript real se requiere Playwright/Chromium instalado en Hostinger; sin ese motor la web muestra esa comprobación como no disponible.</div>
<div class="inline-actions"><button id="toolExampleGit" class="secondary">Ejemplo Git completo</button><button id="toolExampleSqlite" class="secondary">Ejemplo SQLite</button><button id="toolExampleTerminal" class="secondary">Ejemplo terminal</button><button id="toolExampleFiles" class="secondary">Ejemplo archivos</button><button id="toolExampleBrowser" class="secondary">Ejemplo navegador</button></div>
<label>Importar SQLite existente al laboratorio web (máx. 8 MB)<input id="sqliteLabFile" type="file" accept=".sqlite,.sqlite3,.db,application/vnd.sqlite3"/></label>
<div class="inline-actions"><button id="sqliteLabAttach" class="secondary">Importar base a tarea pausada</button><a id="sqliteLabDownload" class="plain-link" href="#">Descargar SQLite de prueba</a></div>
</section></section>
<section class="panel" data-panel="planning">
<div class="heading"><h2>Planificador · Área 4</h2><p>Plan ejecutable con dependencias verificadas, evidencia por objetivo, revisiones y avance persistente. Solo trabaja con copias importadas a Hostinger; Qwen devuelve instrucciones.</p></div>
<div class="toggles" data-toggles="planning"></div>
<div class="form-grid"><label>Máximo de objetivos (1–60)<input data-cfg="planning.maxObjectives" type="number" min="1" max="60"></label><label>Estrategia<select data-cfg="planning.strategy"><option value="phased">Por fases</option><option value="direct">Plan directo y breve</option><option value="research-first">Investigar primero</option></select></label></div>
<div class="notice"><strong>Regla del plan:</strong> un objetivo solo se completa por pruebas verificables o por una aprobación humana expresamente registrada. Las dependencias impiden avanzar prematuramente; los pasos pendientes no se marcan como aprobados.</div>
<section class="inner"><h3>Progreso y dependencias del trabajo seleccionado</h3>
<div class="status-grid"><div class="stat"><small>PROGRESO VERIFICADO</small><strong id="planPercent">0%</strong></div><div class="stat"><small>OBJETIVOS COMPLETADOS</small><strong id="planCounts">0 / 0</strong></div><div class="stat"><small>OBJETIVO ACTIVO</small><strong id="planActive">—</strong></div><div class="stat"><small>REVISIÓN DEL PLAN</small><strong id="planRevision">0</strong></div></div>
<div id="planGoalList" class="list muted">Selecciona una tarea y espera el plan de Qwen.</div>
</section>
<section class="inner"><h3>Protección contra falsos objetivos completos · v16.7</h3><p>Para solicitudes de carga de documentos personales, el plan exige evidencia de recepción, validación, persistencia y acceso autorizado. La autoprueba reproduce el clientes.php incompleto y debe rechazarlo; no lee imágenes reales.</p><button id="feature17Selftest" class="secondary">Autoprueba: rechazar formulario de fotos incompleto</button><pre id="feature17Output" class="diff">Pendiente de ejecutar.</pre></section>
<section class="inner"><h3>Prueba independiente del Planificador (sin Qwen)</h3>
<p>Si Qwen no responde o una tarea conserva una solicitud pendiente, prueba el Planificador usando una tarea nueva ya pausada y una copia aislada del proyecto seleccionado. No altera la tarea anterior ni la cola de Windows.</p>
<div class="inline-actions"><button id="planCreateManual" class="primary">Crear prueba manual con este JSON</button></div>
<div id="planLockReason" class="notice" role="status">Selecciona una tarea o crea una prueba manual.</div>
</section>
<section class="inner"><h3>Editar plan JSON (solo con tarea pausada)</h3><p>IDs estables, dependsOn con IDs existentes, sin ciclos. Los objetivos completados conservan su evidencia solo si el título, dependencias y criterios no cambian. Un plan incorrecto se rechaza sin editar la tarea.</p>
<textarea id="planEditor" rows="14" spellcheck="false" placeholder='{"objectives":[{"id":"o1","title":"Comprobar archivos","phase":"investigacion","dependsOn":[],"checks":[{"type":"file_exists","path":"index.php"}]}]}'></textarea>
<div class="inline-actions"><button id="planLoad" class="secondary">↻ Cargar plan de la tarea</button><button id="planPreview" class="secondary">Validar dependencias</button><button id="planSave" class="secondary">Guardar revisión del plan</button><button id="planVerify" class="secondary">Verificar objetivo activo</button></div>
<pre id="planOutput" class="diff">Sin operaciones del plan.</pre>
</section>
<section class="inner"><h3>Aceptación humana excepcional</h3><p>Solo si el criterio no se puede comprobar instrumentalmente. Se registra como aceptación humana, nunca como una prueba automática.</p>
<label>Razón y evidencia de revisión manual<textarea id="planManualReason" rows="3" placeholder="Explica exactamente qué comprobaste, por qué y en qué entorno (mínimo 20 caracteres)."></textarea></label>
<button id="planManualApprove" class="secondary">Registrar aprobación humana del objetivo activo</button></section>
</section>
<section class="panel" data-panel="limits"><div class="heading"><h2>Tiempo y límites · Área 5</h2><p>Límites aplicados por Hostinger a tareas Web. Se cuenta el tiempo activo; las pausas no gastan presupuesto. El Runtime Qwen conserva sus propios límites físicos por solicitud.</p></div>
<div class="form-grid"><label>Máximo de pasos (1–5000)<input data-cfg="limits.maxSteps" type="number" min="1" max="5000"></label><label>Segundos por operación (10–900)<input data-cfg="limits.operationSeconds" type="number" min="10" max="900"></label><label>Minutos activos por tarea (1–10080)<input data-cfg="limits.totalMinutes" type="number" min="1" max="10080"></label><label>Máximo de tareas simultáneas (1–8)<input data-cfg="limits.concurrency" type="number" min="1" max="8"></label><label>Reintentos de Qwen (0–20)<input data-cfg="limits.retries" type="number" min="0" max="20"></label></div>
<div class="notice"><strong>Las opciones superiores se guardan para tareas nuevas.</strong> Puedes cambiar los límites de una tarea existente cuando esté pausada, sin perder el tiempo activo o los pasos consumidos. No se reinicia silenciosamente el presupuesto al reanudar.</div>
<section class="inner"><h3>Consumo real de la tarea seleccionada</h3>
<div class="form-grid"><label>Seleccionar tarea para modificar sus límites<select id="limitTaskSelect"><option value="">Cargando historial de tareas…</option></select></label><div class="inline-actions"><button id="limitRefreshTasks" type="button" class="secondary">Actualizar tareas y estado</button><button id="limitCreateManualTest" type="button" class="secondary">Crear tarea pausada de prueba (sin Qwen)</button></div></div>
<div id="limitTaskInfo" class="notice" role="status" aria-live="polite">Selecciona una tarea pausada. Si no hay ninguna, crea una tarea de prueba sin Qwen.</div>
<div class="status-grid"><div class="stat"><small>TIEMPO ACTIVO</small><strong id="limitActive">—</strong></div><div class="stat"><small>TIEMPO RESTANTE</small><strong id="limitRemaining">—</strong></div><div class="stat"><small>PASOS CONSUMIDOS</small><strong id="limitSteps">—</strong></div><div class="stat"><small>PASOS RESTANTES</small><strong id="limitStepsLeft">—</strong></div></div>
<div class="inline-actions"><button id="limitApplyRun" class="secondary">Aplicar estos límites a tarea pausada</button><button id="limitSelfTest" class="secondary">Autoprueba del Área 5 (sin Qwen)</button></div><pre id="limitDiagnostic" class="diff">Selecciona una tarea o ejecuta la autoprueba.</pre></section></section>
<section class="panel" data-panel="memory"><div class="heading"><h2>Memoria persistente de ejecución</h2><p>El historial, los errores, los objetivos y las evidencias se conservan en SQLite para reanudar trabajos.</p></div><div class="toggles" data-toggles="memory"></div><div class="form-grid"><label>Acciones en contexto<input data-cfg="memory.history" type="number"></label><label>Caracteres por lectura<input data-cfg="memory.readChars" type="number"></label><label>Archivos en catálogo<input data-cfg="memory.catalogFiles" type="number"></label></div></section>
<section class="panel" data-panel="editing"><div class="heading"><h2>Edición, parches y duplicados</h2><p>Reemplazos exactos sobre copias aisladas, anclas únicas, SHA-256 y validación antes de guardar.</p></div><div class="form-grid"><label>Ubicación del laboratorio<select data-cfg="workspace.kind" id="workspaceKind"><option value="web-isolated">Hostinger · ZIP importado a Projects</option></select></label></div><div class="notice">La copia y todas las herramientas del Developer están en Hostinger. Windows conecta el modelo Qwen exclusivamente.</div><div class="toggles" data-toggles="editing"></div><div class="form-grid"><label>Motor de edición<select data-cfg="editing.mode"><option value="exact-patch">Parche exacto</option><option value="replace">Reemplazo</option><option value="create">Creación controlada</option></select></label></div>
<section class="inner" id="editingV11"><h3>Área 7 · Programación y parches en Hostinger</h3>
<p>Transacciones de múltiples archivos: crear, reemplazar, parches exactos, copiar, mover, borrar y revertir todo el lote. La copia original importada no se modifica. Antes de guardar se comprueba SHA y sintaxis de todos los archivos.</p>
<div class="inline-actions"><button id="edit11Create" class="secondary">Crear tarea aislada de prueba (sin Qwen)</button><button id="edit11Test" class="secondary">Ejecutar prueba real del Área 7</button><button id="edit11Undo" class="secondary">Revertir último lote completo</button></div>
<div id="edit11Info" class="notice">Selecciona un proyecto en Trabajo autónomo y crea una tarea de ensayo.</div>
<pre id="edit11Output" class="diff">Sin pruebas todavía. No tienes que pegar código manualmente.</pre>
</section></section>
<section class="panel" data-panel="qa"><div class="heading"><h2>QA por proyecto · Área 8</h2><p>Pruebas reales de la copia modificada en Hostinger. PHP CLI, sintaxis, JSON, contenido, SQLite de ensayo y staging HTTPS. Sin usar Node ni Windows para programar.</p></div><div class="toggles" data-toggles="qa"></div>
<section class="inner"><h3>QA funcional sobre copia temporal</h3>
<p>La suite ejecuta pruebas sobre una segunda copia desechable. Nunca se llama éxito a un caso pendiente o fallido. Las pruebas se asocian al SHA de la revisión; tras editar hay que repetirlas.</p>
<div class="notice"><strong>Seguridad:</strong> ejecutar código PHP arbitrario no equivale a aislamiento de sistema operativo. Utiliza únicamente proyectos tuyos o confiables. Las pruebas de navegador inspeccionan staging externo, no el nuevo ZIP hasta desplegarlo.</div>
<div class="inline-actions"><button id="qa12Create" class="secondary">Crear tarea QA aislada (sin Qwen)</button><button id="qa12Selftest" class="secondary">Autoprueba real del Área 8</button><button id="qa12Discover" class="secondary">Detectar pruebas del proyecto</button></div>
<div class="inline-actions"><button id="qa12Run" class="secondary">Ejecutar QA del proyecto</button><button id="qa12Save" class="secondary">Guardar suite</button><button id="qa12PhpExample" class="secondary">Usar ejemplo PHP del proyecto</button></div>
<label>Casos de QA del proyecto (JSON; se genera automáticamente al detectar)<textarea id="qa12Suite" spellcheck="false" rows="6" placeholder='[{"name":"PHP real","type":"php_test","path":"tests/check.php","expect":"OK"}]'></textarea></label>
<div id="qa12Info" class="notice">Selecciona un proyecto y crea una tarea QA de copia. La autoprueba incluye fallos intencionales para comprobar que se detectan.</div>
<pre class="diff" id="qa12Output">Sin resultado aún.</pre>
</section></section>
<section class="panel" data-panel="repair"><div class="heading"><h2>Motor de reparación · Área 9</h2><p>QA funcional real → diagnóstico → Qwen corrige varios archivos por edit_batch → nuevo QA. Si no mejora, revierte el lote con SHA; pausa al agotar reintentos.</p></div><div class="toggles" data-toggles="repair"></div><div class="form-grid"><label>Intentos máximos de reparación<input data-cfg="repair.attempts" type="number" min="1" max="30"></label></div>
<section class="inner"><h3>Autoprueba real de reparación en Hostinger</h3><p>Crea archivos dañados de prueba en una copia aislada, detecta errores con PHP real, intenta una reparación incorrecta y la revierte. Luego corrige dos archivos juntos y vuelve a ejecutar QA. Deshace todo al terminar. No usa Qwen y no modifica tus proyectos originales.</p>
<div class="inline-actions"><button id="repair13Create" class="secondary" type="button">Crear tarea aislada de reparación (sin Qwen)</button><button id="repair13Test" class="secondary" type="button">Ejecutar autoprueba real del Área 9</button></div>
<div id="repair13Info" class="notice">Selecciona un proyecto en Trabajo autónomo. La autoprueba utiliza una nueva copia.</div><pre id="repair13Output" class="diff">Sin resultados todavía.</pre>
</section></section>
<section class="panel" data-panel="evaluation"><div class="heading"><h2>Evaluador independiente · Área 10</h2><p>Verificación de requisitos por objetivo + pruebas funcionales vinculadas al SHA vigente. Staging y afirmaciones de Qwen no certifican cambios sin probar.</p></div><div class="toggles" data-toggles="evaluation"></div>
<div class="notice"><strong>Comprobaciones disponibles:</strong> file_changed, file_exists, file_contains, file_not_contains, syntax, no_duplicates, sqlite_table, browser_text, browser_url, test_passed. Las comprobaciones navegador observan staging y NO garantizan que el ZIP propuesto esté desplegado.</div>
<section class="inner"><h3>Autoprueba del Área 10 — un clic, sin Qwen</h3><p>Usa PHP real en un laboratorio temporal para comprobar cobertura, dependencias, resultados fallidos, cambios de SHA, QA vencido y prevención de falsas aprobaciones. No modifica el proyecto importado.</p>
<div class="inline-actions"><button id="eval14Create" class="secondary" type="button">Crear tarea aislada del evaluador (sin Qwen)</button><button id="eval14Test" class="secondary" type="button">Ejecutar autoprueba independiente</button></div>
<pre id="eval14Output" class="diff">Sin prueba ejecutada.</pre></section>
<section class="inner"><h3>Vincular pruebas funcionales con objetivos</h3><p>Opcional para suites de integración cuyos archivos son distintos a los objetivos. El editor propone asociaciones a partir de los casos actuales; revisa antes de guardar. La ausencia de cobertura se informa como pendiente, nunca como aprobado.</p>
<div class="inline-actions"><button id="eval14Suggest" class="secondary" type="button">Preparar asociaciones automáticas</button><button id="eval14SaveLinks" class="secondary" type="button">Guardar asociaciones</button></div>
<textarea id="eval14Links" rows="6" spellcheck="false" placeholder='{"o1":["Prueba PHP real"]}'></textarea></section>
<div class="inline-actions"><button id="verifyAcceptancePanel" class="secondary">Evaluar requisitos del proyecto</button></div>
<div id="eval14Summary" class="notice">Sin evaluación independiente v14 en esta tarea.</div><div id="evaluationDetails" class="list muted">Abre una tarea para ver los resultados independientes.</div></section>
<section class="panel" data-panel="delivery"><div class="heading"><h2>Entregas, ZIP e informes</h2><p>La entrega propuesta contiene solo los archivos efectivamente distintos de la base. No se instala automáticamente.</p></div><div class="toggles" data-toggles="delivery"></div></section>
<section class="panel" data-panel="tracking"><div class="heading"><h2>Área 12 · Seguimiento y recuperación</h2><p>Historial duradero en SQLite, pausas manuales protegidas, bloqueo exclusivo por tarea, recuperación tras interrupciones y observación del cron de Hostinger.</p></div>
<div class="toggles" data-toggles="tracking"></div><div class="form-grid"><label>Segundos entre comprobaciones<input data-cfg="tracking.pollSeconds" type="number"></label></div>
<section class="inner"><h3>Estado de cron y tareas</h3><p>Una pestaña abierta puede avanzar tareas mientras visitas Nexa. Para continuar sin navegador, programa en Hostinger la ejecución CLI de <code>developer/cron.php</code> cada minuto. La web no puede activar cron por sí sola.</p>
<div class="inline-actions"><button type="button" class="secondary" id="track15Health">Consultar actividad real de cron</button><button type="button" class="secondary" id="track15Create">Crear prueba aislada (sin Qwen)</button><button type="button" class="secondary" id="track15Test">Autoprueba de interrupción y recuperación</button></div>
<pre id="track15HealthOutput" class="diff">Cron aún no comprobado. Última ejecución y limitaciones se mostrarán aquí.</pre>
<pre id="track15Output" class="diff">Prueba sin ejecutar; no modifica tu proyecto ni envía nada a Qwen.</pre>
</section></section>
<footer>Nexa Developer Web v16.10 · Contratos funcionales y análisis · Áreas 1–12 preservadas · Laboratorio Hostinger.</footer>
</main></div><script src="assets/developer.js?v=16-7-contract-check-symbols03-aider-isolated-v2" defer></script></body></html>
