<?php
declare(strict_types=1);
require_once __DIR__.'/engine.php';
require_once __DIR__.'/chat-v16.php';
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$user=nexa_require_admin();$uid=(int)$user['id'];$pdo=nd_db();nd16_schema($pdo);
$method=$_SERVER['REQUEST_METHOD']??'GET';
$action=(string)($method==='GET'?($_GET['action']??'dashboard'):($_GET['action']??''));
try{
    if($method==='GET'){
        // Developer Chat v16: administrator-only, using existing nd_runs/jobs and Qwen queue.
        if($action==='chat16_threads'){
            $projectId=(string)($_GET['projectId']??'');
            if($projectId!=='')nxp_project($projectId,$uid);
            nexa_json(['ok'=>true,'threads'=>nd16_threads($pdo,$uid,$projectId)]);
        }
        if($action==='chat16_thread'){
            nexa_json(['ok'=>true,'detail'=>nd16_detail($pdo,$uid,(string)($_GET['id']??''))]);
        }
        if($action==='chat16_probe_status'){
            nexa_json(['ok'=>true,'probe'=>nd16_probe_result($pdo,$uid,(string)($_GET['jobId']??''))]);
        }

        if($action==='runtime_recovery_health')nexa_json(['ok'=>true,'recovery'=>nd20_version_health()]);
        if($action==='settings')nexa_json(['ok'=>true,'config'=>nd_config($uid)]);
        // Developer only: project-owned, read-only symbol inspection. No Aider subprocess.
        if($action==='symbols03'){
            $projectId=(string)($_GET['projectId']??'');nxp_project($projectId,$uid);
            $offset=max(0,(int)($_GET['offset']??0));
            $limit=max(1,min(40,(int)($_GET['limit']??20)));
            $query=substr(trim((string)($_GET['query']??'')),0,100);
            nexa_json(['ok'=>true,'analysis'=>nd03a_merge($projectId,$uid,nd03_project_page($projectId,$offset,$limit,$query))]);
        }

        // Developer-only, read-only cross-file symbol references. Owner and current SHA checked.
        if($action==='symbols03refs'){
            $projectId=(string)($_GET['projectId']??'');nxp_project($projectId,$uid);
            require_once __DIR__.'/symbols-v03-refs.php';
            $path=substr((string)($_GET['path']??''),0,500);
            $name=substr((string)($_GET['name']??''),0,260);
            $type=substr((string)($_GET['type']??''),0,40);
            $line=max(1,(int)($_GET['line']??0));
            $sha=strtolower(trim((string)($_GET['sha256']??'')));
            if($name===''||!in_array($type,['class','interface','trait','enum','function','method','arrow-function'],true)
              ||$line>100000||($sha!==''&&!preg_match('/^[a-f0-9]{64}$/',$sha)))throw new RuntimeException('Solicitud de referencias inválida.');
            nexa_json(['ok'=>true,'references'=>nd03r_references_page($projectId,$path,$name,$type,$line,$sha,
              max(0,(int)($_GET['offset']??0)),max(1,min(20,(int)($_GET['limit']??15))))]);
        }

        // Aider point 03: capability-gated, read-only analysis; old Windows is never sent unsupported jobs.
        if($action==='aider03_status'){
            $projectId=(string)($_GET['projectId']??'');$project=nxp_project($projectId,$uid);
            nexa_json(['ok'=>true,'capability'=>nd03a_capability(),
                'project'=>['id'=>$projectId,'configured'=>trim((string)($project['local_root']??''))!==''],
                'aider'=>nd03a_status($pdo,$uid,$projectId)]);
        }
        if($action==='projects'){
            $stmt=$pdo->prepare('SELECT id,name,description,local_root,staging_url,updated_at FROM nexa_projects WHERE user_id=? ORDER BY updated_at DESC');$stmt->execute([$uid]);
            $projects=[];foreach($stmt->fetchAll() as $p){$p['count']=count(nxp_walk($p['id']));$projects[]=$p;}
            nexa_json(['ok'=>true,'projects'=>$projects]);
        }
        if($action==='runs'){
            $stmt=$pdo->prepare('SELECT id FROM nd_runs WHERE user_id=? ORDER BY created_at DESC LIMIT 100');$stmt->execute([$uid]);
            $runs=[];foreach($stmt->fetchAll(PDO::FETCH_COLUMN) as $id)$runs[]=nd_status(nd_run($id,$uid));
            nexa_json(['ok'=>true,'runs'=>$runs]);
        }
        if($action==='run'||$action==='events'){
            $r=nd_run((string)($_GET['id']??''),$uid);$stmt=$pdo->prepare('SELECT id,kind,message,meta_json,created_at FROM nd_events WHERE run_id=? AND id>? ORDER BY id ASC LIMIT 200');
            $stmt->execute([$r['id'],max(0,(int)($_GET['after']??0))]);$events=[];
            foreach($stmt->fetchAll() as $row){$row['meta']=json_decode($row['meta_json'],true)?:[];unset($row['meta_json']);$events[]=$row;}
            nexa_json(['ok'=>true,'run'=>nd_status($r),'events'=>$events]);
        }
        if($action==='download'){
            $r=nd_run((string)($_GET['id']??''),$uid);$file=nd_root($r['id']).'/CHANGED_FILES_ONLY.zip';
            if(!is_file($file)||!in_array($r['status'],['review_required','incomplete'],true)||!isset($r['state']['artifact']))throw new RuntimeException('ZIP no disponible.');
            $contract=nd17_evaluate($r);
            if(in_array(($contract['status']??'not_applicable'),['pending','failed'],true))throw new RuntimeException('ENTREGA BLOQUEADA: la subida segura de documentos no está demostrada. '.substr(implode(' | ',$contract['missing']??[]),0,900));
            if(filesize($file)!==(int)($r['state']['artifact']['bytes']??-1)||hash_file('sha256',$file)!==($r['state']['artifact']['sha256']??''))throw new RuntimeException('ZIP corrupto: tamaño o SHA no coincidente.');
            header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="NEXA_DEV2_CAMBIOS_'.$r['id'].'.zip"');header('Content-Length: '.filesize($file));readfile($file);exit;
        }
        if($action==='sqlite_download'){
            $r=nd_run((string)($_GET['id']??''),$uid);
            if(nd_remote_mode($r))throw new RuntimeException('Base SQLite disponible solo en laboratorio Web.');
            $file=nd6_db_location($r);
            if(!is_file($file))throw new RuntimeException('No hay SQLite de prueba.');
            header('Content-Type: application/vnd.sqlite3');
            header('Content-Disposition: attachment; filename="nexa_sqlite_laboratorio_'.$r['id'].'.sqlite"');
            header('Content-Length: '.filesize($file));readfile($file);exit;
        }
        if($action==='download_report'){
            $r=nd_run((string)($_GET['id']??''),$uid);
            $report=['runId'=>$r['id'],'projectId'=>$r['project_id'],'model'=>'qwen2.5-coder:7b','version'=>'web-control/4.0',
              'request'=>$r['request'],'status'=>$r['status'],'phase'=>$r['phase'],'objectives'=>$r['state']['objectives']??[], 'planProgress'=>ndp9_progress($r),'planHistory'=>$r['state']['planHistory']??[],
              'acceptanceChecks'=>$r['state']['acceptanceChecks']??[], 'evaluation'=>$r['state']['evaluation']??null, 'evaluation14Links'=>$r['state']['evaluator14Links']??[],
              'qa'=>$r['state']['qa']??null, 'featureContract17'=>nd17_evaluate($r), 'repair13'=>$r['state']['repair13']??null, 'qaFunctional'=>nd12_valid_result($r), 'qaFunctionalStale'=>isset($r['state']['qa12Result'])&&nd12_valid_result($r)===null, 'qaSuite'=>$r['state']['qa12Suite']??[], 'changes'=>$r['state']['changes']??[], 'artifact'=>$r['state']['artifact']??null,
              'history'=>$r['state']['history']??[], 'createdAt'=>$r['created_at'],'updatedAt'=>$r['updated_at'],
              'limitation'=>'No certifica automáticamente pruebas funcionales de aplicaciones no desplegadas.'];
            header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="NEXA_QA_'.$r['id'].'.json"');
            echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;
        }
        if($action==='diff'){
            $r=nd_run((string)($_GET['id']??''),$uid);$path=nd_safe_path((string)($_GET['path']??''));
            if(nd_remote_mode($r)){
                if(!isset($r['state']['changes'][$path]))throw new RuntimeException('Archivo no modificado.');
                $before=(string)($r['state']['originalContent'][$path]??'');
                $after=$r['state']['readContent'][$path]??null;
                if(!is_string($after))throw new RuntimeException('Vista del cambio local no disponible; consulta el ZIP.');
            }else{
                if(!isset(nd_changes($r['id'])[$path]))throw new RuntimeException('No hay cambios en ese archivo.');
                $source=nxp_path($r['project_id'],$path);$before=is_file($source)?(string)file_get_contents($source):'';
                $after=(string)file_get_contents(nd_file($r['id'],$path,true));
            }
            $old=explode("\n",$before);$new=explode("\n",$after);$prefix=0;while(isset($old[$prefix],$new[$prefix])&&$old[$prefix]===$new[$prefix])$prefix++;
            $oi=count($old)-1;$ni=count($new)-1;while($oi>=$prefix&&$ni>=$prefix&&$old[$oi]===$new[$ni]){$oi--;$ni--;}
            $diff='--- original/'.$path."\n".'+++ propuesto/'.$path."\n".'@@ -'.($prefix+1).','.max(0,$oi-$prefix+1).' +'.($prefix+1).','.max(0,$ni-$prefix+1).' @@'."\n";
            foreach(array_slice($old,$prefix,max(0,$oi-$prefix+1)) as $line)$diff.='- '.$line."\n";
            foreach(array_slice($new,$prefix,max(0,$ni-$prefix+1)) as $line)$diff.='+ '.$line."\n";
            nexa_json(['ok'=>true,'path'=>$path,'diff'=>substr($diff,0,160000),'before'=>substr($before,0,90000),'after'=>substr($after,0,90000),
              'beforeSha256'=>hash('sha256',$before),'afterSha256'=>hash('sha256',$after)]);
        }
        if($action==='report'){
            $r=nd_run((string)($_GET['id']??''),$uid);
            $report=['id'=>$r['id'],'mode'=>$r['state']['mode']??'web-isolated','model'=>'qwen2.5-coder:7b',
                'status'=>$r['status'],'request'=>$r['request'],'summary'=>$r['state']['modelSummary']??'',
                'objectives'=>$r['state']['objectives']??[], 'planProgress'=>ndp9_progress($r),'planHistory'=>$r['state']['planHistory']??[],'evaluation'=>$r['state']['evaluation']??null, 'evaluation14Links'=>$r['state']['evaluator14Links']??[],
                'qa'=>$r['state']['qa']??null,'qaFunctional'=>nd12_valid_result($r), 'qaFunctionalStale'=>isset($r['state']['qa12Result'])&&nd12_valid_result($r)===null,
                'changes'=>$r['state']['changes']??(nd_remote_mode($r)?[]:nd_changes($r['id'])),
                'artifact'=>$r['state']['artifact']??null,'acceptanceChecks'=>$r['state']['acceptanceChecks']??[],'history'=>$r['state']['history']??[],
                'disclaimer'=>'No se certifica funcionalidad sin pruebas independientes. ZIP sujeto a revisión.'];
            nexa_json(['ok'=>true,'report'=>$report]);
        }
        if($action==='tracking15_health')nexa_json(['ok'=>true,'health'=>nd15_health($pdo,$uid)]);
        if($action==='tools_web_health')nexa_json(['ok'=>true,'health'=>nd7_health()]);
        if($action==='capabilities'){
            // The remote capabilities are known only after a real connected PC reply.
            $stmt=$pdo->prepare('SELECT status,error_text,result_json,updated_at FROM jobs WHERE user_id=? AND type IN ("developer.webv2.capabilities","developer.capabilities") ORDER BY created_at DESC LIMIT 1');$stmt->execute([$uid]);
            nexa_json(['ok'=>true,'lastProbe'=>$stmt->fetch()?:null]);
        }
        throw new RuntimeException('Acción GET no soportada.');
    }
    if($method!=='POST')nexa_json(['ok'=>false,'error'=>'Método no permitido'],405);
    nexa_require_admin_csrf();$in=nexa_read_json();$action=(string)($in['action']??'');
    if($action==='chat16_new'){
        $projectId=(string)($in['projectId']??'');
        $thread=nd16_new($pdo,$uid,$projectId,(string)($in['title']??''));
        nexa_json(['ok'=>true,'thread'=>$thread]);
    }
    if($action==='chat16_send'){
        $result=nd16_send($pdo,$uid,(string)($in['threadId']??''),(string)($in['message']??''));
        nexa_json(['ok'=>true]+$result);
    }
    if($action==='chat16_probe'){
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM jobs WHERE user_id=? AND type="developer.ai.generate" AND status IN ("queued","running") AND created_at>=?');
        $stmt->execute([$uid,gmdate('c',time()-600)]);
        if((int)$stmt->fetchColumn()>20)throw new RuntimeException('Demasiadas solicitudes Qwen pendientes. Espera antes de probar otra vez.');
        nexa_json(['ok'=>true,'jobId'=>nd16_probe($pdo,$uid)]);
    }
    if($action==='save_settings'){
        $config=nd_clean_config(is_array($in['config']??null)?$in['config']:[]);
        $stmt=$pdo->prepare('INSERT INTO nd_settings(user_id,config_json,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET config_json=excluded.config_json,updated_at=excluded.updated_at');
        $stmt->execute([$uid,json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),nexa_now()]);
        nexa_json(['ok'=>true,'config'=>$config]);
    }
    if($action==='tracking15_create_test'){
        $projectId=(string)($in['projectId']??'');nxp_project($projectId,$uid);
        $config=nd_config($uid);$config['workspace']['kind']='web-isolated';
        $config['tracking']['autoResume']=true;
        $id='nd_'.nexa_uuid();$baseline=nd_prepare($projectId,$id,$uid);$now=nexa_now();
        $state=['mode'=>'web-isolated','tracking15ManualTest'=>true,'tracking15'=>[],
            'startEpoch'=>time(),'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>null],
            'limitToolSteps'=>0,'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],
            'history'=>[],'baselineCount'=>count($baseline),'acceptanceChecks'=>[],
            'lastFeedback'=>'Autoprueba de seguimiento sin Qwen: no altera archivos originales.'];
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,'Prueba manual del Área 12: interrupción y recuperación',
            'paused','tracking15_selftest',json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'tracking15-created','Laboratorio de seguimiento aislado, sin Qwen ni edición.');
        nexa_json(['ok'=>true,'run'=>nd_status(nd_run($id,$uid))]);
    }
    if($action==='tracking15_selftest'){
        $r=nd_run((string)($in['id']??''),$uid);
        $result=nd15_selftest($pdo,$r);
        nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status(nd_run($r['id'],$uid)), 'health'=>nd15_health($pdo,$uid)]);
    }
    if($action==='feature17_selftest'){
        nexa_json(['ok'=>true,'result'=>nd17_selftest()]);
    }
    if($action==='limits_selftest'){
        nexa_json(['ok'=>true,'result'=>nd10_selftest()]);
    }
    // Area 5: create a dedicated paused, Web-only test task. No Qwen request,
    // no tool execution, and no edits to imported project originals.
    if($action==='limits_create_test'){
        $projectId=(string)($in['projectId']??'');
        nxp_project($projectId,$uid);
        $config=nd_config($uid);
        $config['workspace']['kind']='web-isolated';
        $config['limits']=nd10_clean_limits($config['limits']??[]);
        $id='nd_'.nexa_uuid();
        $baseline=nd_prepare($projectId,$id,$uid);
        $state=['mode'=>'web-isolated','limitsManualTest'=>true,'startEpoch'=>time(),
            'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>null],
            'limitToolSteps'=>0,'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],
            'history'=>[],'readFiles'=>[],'baselineCount'=>count($baseline),
            'acceptanceChecks'=>[],'evaluationRepairs'=>0,
            'lastFeedback'=>'Prueba aislada del Área 5 sin Qwen; tarea pausada.'];
        $now=nexa_now();
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,'Prueba manual Tiempo y límites (sin Qwen)',
            'paused','action',
            json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'limits-manual-test','Área 5: tarea pausada creada para comprobar actualización de límites; sin solicitar Qwen.');
        nexa_json(['ok'=>true,'id'=>$id,'run'=>nd_status(nd_run($id,$uid))]);
    }
    if($action==='limits_update_run'){
        $r=nd_run((string)($in['id']??''),$uid);
        if(!nd10_can_update_limits($r))
            throw new RuntimeException('Tarea en estado '.($r['status']??'desconocido').'. Para aplicar límites selecciona una tarea PAUSADA o INCOMPLETA en Tiempo y límites; puedes crear una prueba manual sin Qwen.');
        // Area 5: pending model requests / paused tool chains are preserved, not executed or cancelled.
        // Updated budgets take effect on subsequent work; an already queued model timeout may retain its initial limit.
        $r['config']['limits']=nd10_clean_limits($in['limits']??null,$r['config']['limits']??[]);
        $r['state']['limitRevision']=(int)($r['state']['limitRevision']??0)+1;
        $u=$pdo->prepare('UPDATE nd_runs SET config_json=?,updated_at=? WHERE id=? AND user_id=?');
        $u->execute([json_encode($r['config'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),nexa_now(),$r['id'],$uid]);
        nd_log($r,'limits-update','Limites de la tarea actualizados desde Hostinger, revision '.$r['state']['limitRevision'].'.');
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    if($action==='aider03_analyze'){
        $projectId=(string)($in['projectId']??'');nxp_project($projectId,$uid);
        nexa_json(['ok'=>true,'aider'=>nd03a_start($pdo,$uid,$projectId)]);
    }
    if($action==='create_project'){
        $name=trim((string)($in['name']??''));if(strlen($name)<2||strlen($name)>120)throw new RuntimeException('Nombre de proyecto inválido.');
        $pid='prj_'.nexa_uuid();$now=nexa_now();$stmt=$pdo->prepare('INSERT INTO nexa_projects(id,user_id,name,description,baseline,base_url,staging_url,production_url,approval_mode,github_repo,github_branch,local_root,developer_mode,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$pid,$uid,$name,'','','','','','semi','','main','','web',0,$now,$now]);
        nxp_workspace_dir($pid);nexa_json(['ok'=>true,'id'=>$pid]);
    }
    if($action==='create_run'){
        $projectId=(string)($in['projectId']??'');$request=trim((string)($in['request']??''));
        if(strlen($request)<12||strlen($request)>12000)throw new RuntimeException('Escribe una tarea de 12 a 12000 caracteres.');
        nxp_project($projectId,$uid);
        $config=nd_config($uid);$config['workspace']['kind']='web-isolated';$id='nd_'.nexa_uuid();
        $checks=ndv4_checks($in['criteria']??[]);
        if($config['planning']['requireAcceptance']&&empty($checks)){
            // Qwen may create objective checks; no fake successful acceptance is allowed.
            // An empty user list is permitted and results are labelled pending until checked.
        }
        $active=$pdo->prepare('SELECT COUNT(*) FROM nd_runs WHERE user_id=? AND status="running"');$active->execute([$uid]);
        nd10_assert_slot($pdo,$uid,$config['limits']['concurrency']);
        $mode=$config['workspace']['kind'];$baseline=[];
        if($mode==='pc-isolated'){
            $root=trim((string)(nxp_project($projectId,$uid)['local_root']??''));
            if($root==='')throw new RuntimeException('Configura y guarda la carpeta PC Workspace en Projects.');
            if(!is_dir(nd_root($id)))mkdir(nd_root($id),0750,true);
        }else{$baseline=nd_prepare($projectId,$id,$uid);}
        $state=['mode'=>$mode,'startEpoch'=>time(),'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>time()], 'limitToolSteps'=>0,'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],'history'=>[],'readFiles'=>[],
          'baselineCount'=>count($baseline),'acceptanceChecks'=>$checks,'evaluationRepairs'=>0,'lastFeedback'=>'Lee archivos relevantes antes de editar y comprueba cada criterio.'];
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,$request,'running',$mode==='pc-isolated'?'pc_prepare':'plan',json_encode($state,JSON_UNESCAPED_UNICODE),json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),nexa_now(),nexa_now()]);
        nd_event($id,'created',$mode==='pc-isolated'?'Laboratorio local solicitado: se creará en Nexa Windows sin editar originales.':'Copia web creada: '.count($baseline).' archivos; originales intactos');
        nexa_json(['ok'=>true,'id'=>$id,'run'=>nd_status(nd_run($id,$uid))]);
    }
    // Área 10: autoprueba independiente con archivos PHP y evidencias SHA reales.
    if($action==='evaluator14_create_test'){
        $projectId=(string)($in['projectId']??'');nxp_project($projectId,$uid);
        $config=nd_config($uid);$config['workspace']['kind']='web-isolated';
        $config['qa']['functional']=true;$config['qa']['php']=true;
        $id='nd_'.nexa_uuid();$baseline=nd_prepare($projectId,$id,$uid);$now=nexa_now();
        $state=['mode'=>'web-isolated','evaluator14ManualTest'=>true,'startEpoch'=>time(),
            'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>null],
            'limitToolSteps'=>0,'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],
            'history'=>[],'readFiles'=>[],'baselineCount'=>count($baseline),
            'acceptanceChecks'=>[],'lastFeedback'=>'Área 10: auditoría independiente sin Qwen.'];
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,'Prueba manual del Área 10: evaluación independiente',
            'paused','action',json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'evaluator14-test-created','Área 10: tarea pausada aislada sin Qwen.');
        nexa_json(['ok'=>true,'run'=>nd_status(nd_run($id,$uid))]);
    }
    if($action==='evaluator14_selftest'){
        $r=nd_run((string)($in['id']??''),$uid);
        if(empty($r['state']['evaluator14ManualTest']))throw new RuntimeException('Selecciona una tarea de prueba del Área 10.');
        $result=nd14_selftest($r);
        nd_log($r,'evaluator14-selftest','Evaluación independiente: '.$result['passed'].'/'.$result['total'].' verificaciones PHP/QA.');
        nd_save($r);nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status($r)]);
    }
    if($action==='evaluator14_links'){
        $r=nd_run((string)($in['id']??''),$uid);
        if(!in_array($r['status'],['paused','incomplete'],true)||$r['wait_job']!==''||isset($r['state']['toolChain']))
            throw new RuntimeException('Pausa la tarea y espera a que termine el lote para asignar evidencia a objetivos.');
        $links=$in['links']??null;
        if(!is_array($links)||array_is_list($links)||count($links)>60)throw new RuntimeException('Asociaciones inválidas: objeto de objetivos requerido.');
        $validIds=array_column($r['state']['objectives']??[],'id');$validNames=array_column($r['state']['qa12Suite']??[],'name');
        $clean=[];
        foreach($links as $id=>$names){
            if(!in_array((string)$id,$validIds,true)||!is_array($names)||!array_is_list($names)||count($names)>20)
                throw new RuntimeException('Objetivo o asociación inválida: '.$id);
            $clean[(string)$id]=[];
            foreach($names as $name){if(!is_string($name)||!in_array($name,$validNames,true))throw new RuntimeException('Caso de QA no configurado: '.$name);$clean[(string)$id][]=$name;}
            $clean[(string)$id]=array_values(array_unique($clean[(string)$id]));
        }
        $r['state']['evaluator14Links']=$clean;unset($r['state']['evaluation'],$r['state']['artifact']);
        @unlink(nd_root($r['id']).'/CHANGED_FILES_ONLY.zip');
        nd_log($r,'evaluator14-links','Asociación explícita de pruebas por objetivo actualizada.');
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r),'links'=>$clean]);
    }
    // Area 9: isolated manual repair test, identical workspace protections as Area 7/8.
    if($action==='repair13_create_test'){
        $projectId=(string)($in['projectId']??'');nxp_project($projectId,$uid);
        $config=nd_config($uid);$config['workspace']['kind']='web-isolated';
        $config['qa']['php']=true;$config['qa']['functional']=true;
        $config['tools']['files']=true;$config['repair']['attempts']=max(3,(int)$config['repair']['attempts']);
        $config['repair']['rollback']=true;$config['repair']['stopRepeated']=true;
        $id='nd_'.nexa_uuid();$base=nd_prepare($projectId,$id,$uid);$now=nexa_now();
        $state=['mode'=>'web-isolated','repair13ManualTest'=>true,'startEpoch'=>time(),
            'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>null],'limitToolSteps'=>0,
            'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],'history'=>[],'readFiles'=>[],
            'baselineCount'=>count($base),'acceptanceChecks'=>[],
            'lastFeedback'=>'Prueba de reparación transaccional y QA real en Hostinger. Sin Qwen.'];
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,'Prueba manual del Área 9: reparación de varios archivos',
            'paused','action',json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'repair13-test-created','Área 9: laboratorio aislado pausado, sin Qwen.');
        nexa_json(['ok'=>true,'run'=>nd_status(nd_run($id,$uid))]);
    }
    if($action==='repair13_selftest'){
        $r=nd_run((string)($in['id']??''),$uid);
        $result=nd13_selftest($r);nd_save($r);
        nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status($r)]);
    }
    // Area 8: isolated, web-only functional QA. No Windows job created.
    if($action==='qa12_create_test'){
        $projectId=(string)($in['projectId']??'');nxp_project($projectId,$uid);
        $config=nd_config($uid);$config['workspace']['kind']='web-isolated';
        $config['qa']['php']=true;$config['qa']['json']=true;$config['qa']['functional']=true;
        $id='nd_'.nexa_uuid();$baseline=nd_prepare($projectId,$id,$uid);$now=nexa_now();
        $state=['mode'=>'web-isolated','qa12ManualTest'=>true,'startEpoch'=>time(),
            'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>null],'limitToolSteps'=>0,
            'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],'history'=>[], 'readFiles'=>[],
            'baselineCount'=>count($baseline),'acceptanceChecks'=>[],'lastFeedback'=>'QA funcional en copia aislada. Sin consultas a Qwen.'];
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,'Prueba manual del Área 8: QA de copia Web',
            'paused','action',json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'qa12-created','QA manual: laboratorio duplicado en Hostinger, sin Qwen.');
        nexa_json(['ok'=>true,'run'=>nd_status(nd_run($id,$uid))]);
    }
    if(in_array($action,['qa12_autodiscover','qa12_save','qa12_run','qa12_selftest'],true)){
        $r=nd_run((string)($in['id']??''),$uid);nd12_allowed($r);
        if($action==='qa12_autodiscover')nexa_json(['ok'=>true,'suite'=>nd12_auto_suite($r)]);
        if($action==='qa12_save'){
            $suite=nd12_suite($in['suite']??null);
            $r['state']['qa12Suite']=$suite;unset($r['state']['qa12Result'],$r['state']['evaluation'],$r['state']['artifact']);
            nd_log($r,'qa-suite','Suite QA actualizada: '.count($suite).' casos (sin ejecutar).');nd_save($r);
            nexa_json(['ok'=>true,'run'=>nd_status($r),'suite'=>$suite]);
        }
        if($action==='qa12_run'){
            $suite=$in['suite']??($r['state']['qa12Suite']??nd12_auto_suite($r));
            $result=nd12_execute($r,$suite);
            unset($r['state']['evaluation'],$r['state']['artifact']);
            nd_log($r,'qa-functional','Suite real: '.$result['passed'].' aprobados, '.$result['failed'].' fallidos, '.$result['pending'].' pendientes. SHA '.$result['fingerprint']);
            nd_save($r);nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status($r)]);
        }
        $result=nd12_selftest($r);nd_log($r,'qa-selftest','Autoprueba Área 8: '.$result['passed'].'/'.$result['total'].'; incluye pruebas negativas que deben fallar.');
        nd_save($r);nexa_json(['ok'=>true,'result'=>$result]);
    }
    // Área 7: independent manual test task, Web-only, never calls Qwen.
    if($action==='edit11_create_test'){
        $projectId=(string)($in['projectId']??'');nxp_project($projectId,$uid);
        $config=nd_config($uid);$config['workspace']['kind']='web-isolated';$config['tools']['files']=true;
        $id='nd_'.nexa_uuid();$baseline=nd_prepare($projectId,$id,$uid);
        $now=nexa_now();$state=['mode'=>'web-isolated','editingManualTest'=>true,'startEpoch'=>time(),
            'limitClock'=>['schema'=>1,'elapsedSeconds'=>0,'runningSince'=>null],'limitToolSteps'=>0,
            'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],'history'=>[], 'readFiles'=>[],
            'baselineCount'=>count($baseline),'acceptanceChecks'=>[],'lastFeedback'=>'Prueba del Área 7 sin conexión a Qwen.'];
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,'Prueba manual del Área 7: edición segura de copias Web',
            'paused','action',json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'editing-test-created','Área 7: nueva copia aislada sin Qwen.');
        nexa_json(['ok'=>true,'run'=>nd_status(nd_run($id,$uid))]);
    }
    if($action==='edit11_test'){
        $r=nd_run((string)($in['id']??''),$uid);
        if(empty($r['state']['editingManualTest'])||$r['status']!=='paused'||$r['wait_job']!==''||isset($r['state']['toolChain']))
            throw new RuntimeException('Solo una tarea manual pausada del Área 7 puede ejecutar esta autoprueba.');
        if(!empty($r['state']['edit11TestDone']))throw new RuntimeException('La prueba ya se ejecutó. Crea otra tarea aislada si quieres repetirla.');
        $result=nd11_selftest_workspace($r);$r['state']['edit11TestDone']=true;$r['state']['edit11TestResult']=$result;
        nd_save($r);nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status($r)]);
    }
    if($action==='edit11_batch'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']!=='paused'||$r['wait_job']!==''||isset($r['state']['toolChain']))throw new RuntimeException('Se necesita una tarea pausada y libre de herramientas.');
        $result=nd11_batch($r,$in['operations']??null,false);
        nd_save($r);nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status($r)]);
    }
    if($action==='edit11_undo'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']!=='paused'||$r['wait_job']!==''||isset($r['state']['toolChain']))throw new RuntimeException('Se necesita tarea pausada y libre.');
        $result=nd11_undo($r);nd_save($r);nexa_json(['ok'=>true,'result'=>$result,'run'=>nd_status($r)]);
    }
    if($action==='rollback_last'){
        $r=nd_run((string)($in['id']??''),$uid);
        ndv4_rollback($r);
        // A restored file must invalidate any stale objective verification in the Web plan.
        if(!empty($r['state']['objectives'])&&!nd_remote_mode($r))ndp9_revalidate_completed($r);
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    // Área 4: isolated offline planner test. No Qwen job is created and no
    // existing task/job is modified. The supplied plan is validated before
    // any workspace is copied or any task is inserted.
    if($action==='plan_create_manual_test'){
        $projectId=(string)($in['projectId']??'');
        nxp_project($projectId,$uid);
        $config=nd_config($uid);
        $config['workspace']['kind']='web-isolated';
        // A manual planner test is self-contained and does not require Qwen.
        $config['planning']['enabled']=true;
        $rawPlan=is_array($in['plan']??null)?$in['plan']:[];
        ndp9_validate($rawPlan,(int)($config['planning']['maxObjectives']??12),
            !empty($config['planning']['requireAcceptance']),(string)($config['planning']['strategy']??'phased'));
        $id='nd_'.nexa_uuid();
        $baseline=nd_prepare($projectId,$id,$uid);
        $state=['mode'=>'web-isolated','plannerManualTest'=>true,'startEpoch'=>time(),
            'steps'=>0,'edits'=>0,'errors'=>0,'objectives'=>[],'history'=>[],
            'readFiles'=>[],'baselineCount'=>count($baseline),'acceptanceChecks'=>[],
            'evaluationRepairs'=>0,'lastFeedback'=>'Prueba manual aislada del Planificador: sin solicitudes a Qwen.'];
        $run=['id'=>$id,'user_id'=>$uid,'project_id'=>$projectId,
            'request'=>'Prueba manual del Planificador web sin conexión a Qwen',
            'status'=>'paused','phase'=>'action','wait_job'=>'','lease_until'=>0,
            'error'=>'','finished_at'=>'','state'=>$state,'config'=>$config];
        ndp9_install($run,$rawPlan,false);
        $now=nexa_now();
        $stmt=$pdo->prepare('INSERT INTO nd_runs(id,user_id,project_id,request,status,phase,state_json,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$uid,$projectId,$run['request'],'paused','action',
            json_encode($run['state'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),
            json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$now,$now]);
        nd_event($id,'plan-manual-test','Planificador manual creado y pausado: '.count($run['state']['objectives']).' objetivos. Ningún trabajo Qwen solicitado.');
        nexa_json(['ok'=>true,'id'=>$id,'run'=>nd_status(nd_run($id,$uid))]);
    }
    // Area 4: only paused, owner-authenticated tasks can change a plan.
    if($action==='plan_preview'){
        $r=nd_run((string)($in['id']??''),$uid);
        $preview=ndp9_validate(is_array($in['plan']??null)?$in['plan']:[],
          (int)($r['config']['planning']['maxObjectives']??12),!empty($r['config']['planning']['requireAcceptance']),
          (string)($r['config']['planning']['strategy']??'phased'));
        ndp9_mutation_guard($preview,(string)$r['request']);
        nd17_must_plan($preview,(string)$r['request'],$r['state']['featureContract17Kind']??null);
        nexa_json(['ok'=>true,'objectives'=>$preview,'count'=>count($preview),'message'=>'Dependencias, identificadores y criterios válidos. Nada fue modificado.']);
    }
    if($action==='plan_save'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']!=='paused'||$r['wait_job']!==''||isset($r['state']['toolChain']))
            throw new RuntimeException('Para editar el plan, pausa la tarea y espera a que termine cualquier operación.');
        if(empty($r['config']['planning']['enabled']))throw new RuntimeException('Activa Planificador antes de editar objetivos.');
        $expected=(int)($in['expectedRevision']??-1);
        if($expected!==(int)($r['state']['planRevision']??0))throw new RuntimeException('PLAN_CONFLICT: alguien actualizó el plan. Recarga antes de guardar.');
        ndp9_install($r,is_array($in['plan']??null)?$in['plan']:[],true);
        if($r['phase']==='wait_plan')throw new RuntimeException('El plan de Qwen continúa pendiente.');
        $r['phase']='action';$r['error']='';
        unset($r['state']['evaluation']);
        nd_log($r,'plan-revision','Plan editado en Hostinger: revisión '.$r['state']['planRevision'].' · '.count($r['state']['objectives']).' objetivos.');
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    if($action==='plan_verify'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']!=='paused'||$r['wait_job']!==''||isset($r['state']['toolChain']))
            throw new RuntimeException('Pausa la tarea para verificar su objetivo activo.');
        if(empty($r['state']['objectives']))throw new RuntimeException('La tarea todavía no tiene un plan.');
        $result=ndp9_refresh($r);
        if(ndp9_progress($r)['done']===count($r['state']['objectives']))$r['phase']='evaluate';
        nd_log($r,'plan-verify','Verificación independiente del objetivo '.($result['objectiveId']??'').' · '.$result['status'],$result);
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r),'verification'=>$result]);
    }
    if($action==='plan_approve_manual'){
        $r=nd_run((string)($in['id']??''),$uid);
        $objectiveId=trim((string)($in['objectiveId']??''));$reason=(string)($in['reason']??'');
        if(($in['acknowledge']??false)!==true)throw new RuntimeException('Debes confirmar que es aceptación humana, NO una prueba automatizada.');
        ndp9_manual_approve($r,$objectiveId,$reason);
        nd_log($r,'plan-manual','Aprobación HUMANA explícita del objetivo '.$objectiveId.'; no equivale a prueba instrumental.',
          ['objectiveId'=>$objectiveId,'reason'=>substr($reason,0,1000)]);
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    if($action==='save_criteria'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']==='cancelled')throw new RuntimeException('Trabajo cancelado.');
        $r['state']['acceptanceChecks']=ndv4_checks($in['criteria']??[]);
        $r['state']['evaluation']=null;
        nd_log($r,'acceptance','Criterios actualizados: '.count($r['state']['acceptanceChecks']).'.');
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    if($action==='verify_acceptance'){
        $r=nd_run((string)($in['id']??''),$uid);
        $changes=nd_remote_mode($r)?($r['state']['changes']??[]):nd_changes($r['id']);
        $qa=$r['state']['qa']??['checks'=>[],'failed'=>0,'pending'=>0];
        $r['state']['evaluation']=ndv4_evaluate($r,$changes,$qa);
        $r['state']['evaluation']['independent14']=nd14_assess($r,$changes,$qa);
        nd_log($r,'acceptance','Evaluación independiente: '.$r['state']['evaluation']['passed'].' aprobados / '.$r['state']['evaluation']['failed'].' fallidos / '.$r['state']['evaluation']['pending'].' pendientes.');
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    if($action==='sqlite_attach'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']!=='paused'||$r['wait_job']!=='')throw new RuntimeException('Pausa una tarea web antes de adjuntar una base de ensayo.');
        if(nd_remote_mode($r)||empty($r['config']['tools']['sqlite']))throw new RuntimeException('Activa SQLite en laboratorio Hostinger.');
        $encoded=(string)($in['base64']??'');
        if(strlen($encoded)>11*1024*1024)throw new RuntimeException('La base excede el límite.');
        $bytes=base64_decode($encoded,true);
        if(!is_string($bytes))throw new RuntimeException('Base64 inválido.');
        $result=nd6_db_attach($r,$bytes);
        unset($r['state']['evaluation'],$r['state']['qa'],$r['state']['artifact']);
        $r['state']['evidence']=array_values(array_filter($r['state']['evidence']??[],fn($ev)=>($ev['kind']??'')!=='sqlite-lab-schema'));
        nd_log($r,'sqlite-attach','Base SQLite importada únicamente al laboratorio web. SHA '.$result['sha256']);
        nd_save($r);nexa_json(['ok'=>true,'database'=>$result]);
    }
    if($action==='tools_catalog'){
        $r=nd_run((string)($in['id']??''),$uid);
        nexa_json(['ok'=>true,'catalog'=>nd5_catalog($r)]);
    }
    if($action==='tools_execute'){
        $r=nd_run((string)($in['id']??''),$uid);
        if($r['status']!=='paused'||$r['wait_job']!=='')throw new RuntimeException('Pausa la tarea antes de ejecutar herramientas manualmente.');
        if(isset($r['state']['toolChain']))throw new RuntimeException('Hay un lote en progreso.');
        $requestedSteps=$in['steps']??null;$budget=nd10_snapshot($r,time());
        if($budget['remainingSeconds']<=0)throw new RuntimeException('Tiempo activo agotado. Aumenta los minutos de esta tarea desde Área 5.');
        if(is_array($requestedSteps)&&count($requestedSteps)>$budget['remainingSteps'])
            throw new RuntimeException('El lote de herramientas excede los pasos restantes. Amplia el limite en Área 5.');
        nd5_chain_start($r,$requestedSteps,true);
        nd10_assert_slot($pdo,$uid,(int)($r['config']['limits']['concurrency']??1),$r['id']);
        $r['status']='running';$r['error']='';nd10_clock_start($r,time());$r['state']['startEpoch']=time();
        nd_save($r);nexa_json(['ok'=>true,'run'=>nd_status($r)]);
    }
    if($action==='capabilities_probe'){
        $id=nexa_uuid();$now=nexa_now();$stmt=$pdo->prepare('INSERT INTO jobs(id,type,payload_json,status,created_at,updated_at,user_id) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([$id,'developer.webv2.capabilities','{}','queued',$now,$now,$uid]);
        nexa_json(['ok'=>true,'jobId'=>$id,'message'=>'Consulta enviada; revisa la respuesta después de que Windows procese la cola.']);
    }
    if(in_array($action,['tick','pause','resume','cancel'],true)){
        $id=(string)($in['id']??'');
        if($action==='tick'){
            $result=nd15_process($pdo,$id,$uid,'browser');
            nexa_json(['ok'=>true,'run'=>nd_status(nd_run($id,$uid)),'trackingTick'=>$result]);
        }
        $pdo->exec('BEGIN IMMEDIATE');$trackingMutationOpen=true;
        try{$r=nd_run($id,$uid);
        if($action==='pause'&&$r['status']==='running'){nd10_clock_stop($r,time());$r['status']='paused';nd_log($r,'pause','Trabajo pausado desde Nexa Web');}
        if($action==='cancel'&&!in_array($r['status'],['cancelled','review_required'],true)){$r['status']='cancelled';$r['phase']='cancelled';$r['finished_at']=nexa_now();nd_log($r,'cancel','Trabajo cancelado. Original intacto.');
            if($r['wait_job']!==''){$s=$pdo->prepare('UPDATE jobs SET status="cancel_requested",updated_at=? WHERE id=? AND status IN ("queued","running")');$s->execute([nexa_now(),$r['wait_job']]);}}
        if($action==='resume'&&in_array($r['status'],['paused','incomplete'],true)){
            $exhausted=nd10_limit_reason($r,time());
            if($exhausted!=='')throw new RuntimeException($exhausted);
            nd10_assert_slot($pdo,$uid,(int)($r['config']['limits']['concurrency']??1),$r['id']);
            $r['status']='running';$r['error']='';nd10_clock_start($r,time());$r['state']['startEpoch']=time();$r['state']['errors']=0;
            if($r['phase']==='complete'||$r['phase']==='evaluate')$r['phase']='action';
            if($r['wait_job']!==''&&!nexa_job($r['wait_job'])){$r['wait_job']='';$r['phase']='action';nd_log($r,'recovery','La orden anterior expiró; Qwen reexaminará el laboratorio sin tocar originales.');}
            nd_log($r,'resume','Reanudado desde la última etapa persistida.');
        }
        nd_save($r);$pdo->exec('COMMIT');$trackingMutationOpen=false;
        nexa_json(['ok'=>true,'run'=>nd_status($r)]);
        }catch(Throwable $e){if($trackingMutationOpen)try{$pdo->exec('ROLLBACK');}catch(Throwable $ignored){}throw $e;}
    }
    throw new RuntimeException('Acción POST desconocida: '.$action);
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();nexa_json(['ok'=>false,'error'=>$e->getMessage()],400);}
