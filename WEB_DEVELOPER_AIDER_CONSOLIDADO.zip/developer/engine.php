<?php
declare(strict_types=1);
/** Nexa Developer Web v1 — isolated web workspaces and persistent Ollama orchestration. */
require_once dirname(__DIR__).'/api/web/project-lib.php';
require_once dirname(__DIR__).'/api/web/developer-syntax-lib.php';
require_once __DIR__.'/bridge-v3.php';
require_once __DIR__.'/quality-v4.php';
require_once __DIR__.'/planner-v9.php';
require_once __DIR__.'/limits-v10.php';
require_once __DIR__.'/editing-v11.php';
require_once __DIR__.'/qa-v12.php';
require_once __DIR__.'/repair-v13.php';
require_once __DIR__.'/evaluator-v14.php';
require_once __DIR__.'/tracking-v15.php';
require_once __DIR__.'/tools-v5.php';
require_once __DIR__.'/no-progress-v16-2.php';
require_once __DIR__.'/recovery-v16-8.php';
require_once __DIR__.'/recovery-v16-9.php';
require_once __DIR__.'/recovery-v16-10.php';
const ND20_ENGINE_HOOK='16.10.0';
require_once __DIR__.'/php-output-v16-3.php';
require_once __DIR__.'/analysis-v16-4.php';
require_once __DIR__.'/symbols-v03.php'; // Developer-only read-only symbol analyzer
require_once __DIR__.'/aider-v03.php'; // Strict Windows analysis protocol; never executes arbitrary code
require_once __DIR__.'/feature-contract-v16-7.php';

function nd_db(): PDO {
    $pdo=nxp_schema();
    $pdo->exec('CREATE TABLE IF NOT EXISTS nd_settings (user_id INTEGER PRIMARY KEY, config_json TEXT NOT NULL, updated_at TEXT NOT NULL)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS nd_runs (
        id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, project_id TEXT NOT NULL, request TEXT NOT NULL,
        status TEXT NOT NULL, phase TEXT NOT NULL, state_json TEXT NOT NULL,
        config_json TEXT NOT NULL, wait_job TEXT NOT NULL DEFAULT "", lease_until INTEGER NOT NULL DEFAULT 0,
        error TEXT NOT NULL DEFAULT "", created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        finished_at TEXT NOT NULL DEFAULT "")');
    $pdo->exec('CREATE INDEX IF NOT EXISTS nd_runs_user ON nd_runs(user_id,created_at)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS nd_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL, kind TEXT NOT NULL,
        message TEXT NOT NULL, meta_json TEXT NOT NULL DEFAULT "{}", created_at TEXT NOT NULL)');
    $pdo->exec('CREATE INDEX IF NOT EXISTS nd_events_run ON nd_events(run_id,id)');
    nd15_schema($pdo);
    return $pdo;
}
function nd_defaults(): array {
    return [
        'model'=>'qwen2.5-coder:7b','temperature'=>0.08,'context'=>12288,'tokens'=>3500,'topP'=>0.85,
        'tools'=>['files'=>true,'search'=>true,'terminal'=>false,'git'=>false,'gitNetwork'=>false,'browser'=>false,'sqlite'=>false],
        'planning'=>['enabled'=>true,'maxObjectives'=>12,'requireAcceptance'=>true,'strategy'=>'phased'],
        'limits'=>['maxSteps'=>80,'operationSeconds'=>120,'totalMinutes'=>120,'concurrency'=>1,'retries'=>4],
        'memory'=>['enabled'=>true,'history'=>18,'readChars'=>17000,'catalogFiles'=>500,'checkpoints'=>true],
        'editing'=>['mode'=>'exact-patch','duplicateGuard'=>true,'requireRead'=>true,'rollback'=>true],
        'qa'=>['php'=>true,'javascript'=>true,'json'=>true,'sqlite'=>true,'browser'=>false,'functional'=>false,'required'=>true],
        'repair'=>['attempts'=>4,'rollback'=>true,'stopRepeated'=>true,'pauseOnFailure'=>true],
        'evaluation'=>['requireSyntax'=>true,'requireEvidence'=>true,'independent'=>true],
        'delivery'=>['onlyChanges'=>true,'sha256'=>true,'includeReport'=>true],
        'tracking'=>['autoResume'=>true,'pollSeconds'=>4,'logDetails'=>true],
        'workspace'=>['kind'=>'web-isolated','localRoot'=>'']
    ];
}
function nd_bool($v): bool {return $v === true || $v === 1;}
function nd_int($v,int $min,int $max):int{return max($min,min($max,(int)$v));}
function nd_clean_config(array $in): array {
    $c=nd_defaults();
    // Qwen Coder is the ONLY model for Developer, never substitute gpt-oss.
    $c['temperature']=max(0,min(1,(float)($in['temperature']??$c['temperature'])));
    $c['topP']=max(0.05,min(1,(float)($in['topP']??$c['topP'])));
    $c['context']=nd_int($in['context']??12288,2048,32768);
    $c['tokens']=nd_int($in['tokens']??3500,256,8192);
    foreach(['tools','qa'] as $group){if(is_array($in[$group]??null)){foreach($c[$group] as $key=>$old){if(array_key_exists($key,$in[$group]))$c[$group][$key]=nd_bool($in[$group][$key]);}}}
    foreach(['planning','memory','editing','repair','evaluation','delivery','tracking','workspace'] as $g){
        if(!is_array($in[$g]??null))continue;
        foreach($c[$g] as $k=>$old){if(!array_key_exists($k,$in[$g]))continue;$v=$in[$g][$k];
            if(is_bool($old))$c[$g][$k]=nd_bool($v);
            elseif(is_int($old))$c[$g][$k]=nd_int($v,1,2000);
            elseif(is_string($old))$c[$g][$k]=substr(trim((string)$v),0,700);
        }
    }
    if(is_array($in['limits']??null))$c['limits']=nd10_clean_limits($in['limits'],$c['limits']);
    $c['planning']['strategy']=in_array($c['planning']['strategy'],['phased','direct','research-first'],true)?$c['planning']['strategy']:'phased';
    $c['planning']['maxObjectives']=nd_int($c['planning']['maxObjectives'],1,60);
    $c['editing']['mode']=in_array($c['editing']['mode'],['exact-patch','replace','create'],true)?$c['editing']['mode']:'exact-patch';
    $c['workspace']['kind']='web-isolated'; // Nuevo Developer: proyectos y herramientas solo en Hostinger // Always edits an isolated copy
    return $c;
}
function nd_config(int $userId):array{
    $stmt=nd_db()->prepare('SELECT config_json FROM nd_settings WHERE user_id=?');$stmt->execute([$userId]);
    $x=$stmt->fetchColumn();return nd_clean_config(is_string($x)?(json_decode($x,true)?:[]):[]);
}
function nd_event(string $id,string $kind,string $message,array $meta=[]):void{
    $s=nd_db()->prepare('INSERT INTO nd_events(run_id,kind,message,meta_json,created_at) VALUES(?,?,?,?,?)');
    $s->execute([$id,$kind,mb_substr($message,0,4000),json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),nexa_now()]);
}
function nd_run(string $id,int $userId):array{
    if(!preg_match('/^nd_[a-f0-9]{32}$/',$id))throw new RuntimeException('Run inválido.');
    $s=nd_db()->prepare('SELECT * FROM nd_runs WHERE id=? AND user_id=?');$s->execute([$id,$userId]);$r=$s->fetch();
    if(!$r)throw new RuntimeException('Run no encontrado.');
    $r['state']=json_decode($r['state_json'],true)?:[];
    $r['config']=json_decode($r['config_json'],true)?:nd_defaults();
    unset($r['state_json'],$r['config_json']);return $r;
}
function nd_save(array $r):void{
    if(($r['status']??'')==='running')nd10_clock_start($r,time());else nd10_clock_stop($r,time());
    $stmt=nd_db()->prepare('UPDATE nd_runs SET status=?,phase=?,state_json=?,wait_job=?,lease_until=?,error=?,updated_at=?,finished_at=? WHERE id=? AND user_id=?');
    $stmt->execute([$r['status'],$r['phase'],json_encode($r['state'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),$r['wait_job'],(int)$r['lease_until'],$r['error']??'',nexa_now(),$r['finished_at']??'',$r['id'],$r['user_id']]);
}
function nd_root(string $id):string {return dirname(nexa_db_path()).'/developer-v2/'.$id;}
function nd_stage(string $id):string{return nd_root($id).'/workspace';}
function nd_safe_path(string $rel):string{
    if(strlen($rel)<1||strlen($rel)>480||str_contains($rel,"\0")||str_contains($rel,'\\'))throw new RuntimeException('Ruta no permitida.');
    $rel=str_replace('\\','/',$rel);
    if(str_starts_with($rel,'/')||preg_match('~^[A-Za-z]:~',$rel))throw new RuntimeException('Ruta absoluta no permitida.');
    foreach(explode('/',$rel) as $p){if($p===''||$p==='.'||$p==='..'||str_starts_with($p,'.env')||in_array(strtolower($p),['.git','vendor','node_modules','private','secrets','data','uploads'],true))throw new RuntimeException('Ruta protegida.');}
    if(!nxp_is_text_path($rel))throw new RuntimeException('Solamente archivos de código y texto.');
    return $rel;
}
function nd_file(string $id,string $rel,bool $exists=false):string{
    $rel=nd_safe_path($rel);$root=nd_stage($id);$dest=$root.'/'.$rel;
    if(!str_starts_with($dest,$root.'/'))throw new RuntimeException('Ruta fuera del laboratorio.');
    $dir=$root;foreach(explode('/',$rel) as $part){$dir.='/'.$part;if(is_link($dir))throw new RuntimeException('Symlink bloqueado.');}
    if($exists&&!is_file($dest))throw new RuntimeException('Archivo inexistente.');
    return $dest;
}
function nd_manifest(string $id):array{
    $root=nd_stage($id);if(!is_dir($root))return [];
    $out=[];$iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
    foreach($iterator as $f){if(!$f->isFile()||$f->isLink())continue;$rel=str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));try{nd_safe_path($rel);}catch(Throwable $e){continue;}
        $out[$rel]=['sha256'=>hash_file('sha256',$f->getPathname()),'size'=>$f->getSize()];
    }
    ksort($out,SORT_NATURAL);return $out;
}
function nd_prepare(string $projectId,string $runId,int $userId):array{
    nxp_project($projectId,$userId);$root=nd_stage($runId);if(is_dir($root))throw new RuntimeException('Laboratorio ya existe.');
    if(!mkdir($root,0750,true))throw new RuntimeException('No se pudo crear laboratorio.');
    $count=0;
    foreach(nxp_walk($projectId) as $row){if(empty($row['text'])||(int)$row['size']>1800000)continue;
        $rel=$row['path'];try{$dst=nd_file($runId,$rel);}catch(Throwable $e){continue;}
        $src=nxp_path($projectId,$rel);if(!is_file($src)||is_link($src))continue;
        if(!is_dir(dirname($dst)))mkdir(dirname($dst),0750,true);
        if(!copy($src,$dst))throw new RuntimeException('No se pudo preparar archivo '.$rel);
        $count++;
    }
    if($count===0)throw new RuntimeException('El proyecto no tiene archivos de código. Primero importa un ZIP en Projects.');
    $manifest=nd_manifest($runId);
    file_put_contents(nd_root($runId).'/baseline.json',json_encode($manifest,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    return $manifest;
}
function nd_base(string $id):array{return json_decode((string)@file_get_contents(nd_root($id).'/baseline.json'),true)?:[];}
function nd_changes(string $id):array{
    $base=nd_base($id);$now=nd_manifest($id);$changed=[];
    foreach($now as $path=>$meta)if(!isset($base[$path])||$base[$path]['sha256']!==$meta['sha256'])$changed[$path]=$meta;
    return $changed;
}
function nd_label_guard(string $task,string $before,string $after,string $path):?string{
    if(!preg_match('/\.(php|html|htm)$/i',$path))return null;
    if(!preg_match('/(?:agrega|agregar|añade|anade|inserta|coloca|texto|mostrar|show)/iu',$task))return null;
    if(!preg_match('/[\"“]([^\"”\r\n]{15,180})[\"”]/u',$task,$m))return null;
    $label=trim((string)$m[1]);if(count(preg_split('/\s+/u',$label))<3||str_contains($label,'<'))return null;
    $lower=static fn(string $v):string=>function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);
    $count=substr_count($lower($after),$lower($label));
    $old=substr_count($lower($before),$lower($label));
    if($count>max(1,$old))return 'TEXTO_DUPLICADO: la frase solicitada aparece '.$count.' veces.';
    if($count>0&&preg_match('/debajo del t[ií]tulo|below the (?:main )?title/iu',$task)){
        $idx=strpos($after,$label);$foot=strpos($after,'page_footer(');$head=strpos($after,'page_header(');
        if($foot!==false&&$idx!==false&&$idx>$foot)return 'UBICACION_INCORRECTA: la frase quedó después de page_footer().';
        if($head!==false&&$idx!==false&&$idx<$head)return 'UBICACION_INCORRECTA: la frase quedó antes del encabezado.';
    }
    return null;
}
function nd_syntax(string $path,string $src,array $c):array{
    $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));
    if($ext==='php'&&$c['qa']['php']){
        $result=nexa_developer_php_syntax($src);
        return ['path'=>$path,'kind'=>'php-parser','verified'=>$result['checked'],'ok'=>$result['valid'],'message'=>$result['error']?:'PHP grammar correcta'];
    }
    if($ext==='sql'&&!empty($c['qa']['sqlite']))return ndv4_sql_syntax($path,$src);
    if(($ext==='json'||$ext==='jsonl')&&$c['qa']['json']){
        try{if($ext==='json')json_decode($src,true,512,JSON_THROW_ON_ERROR);
            else foreach(explode("\n",$src) as $l)if(trim($l)!=='')json_decode($l,true,512,JSON_THROW_ON_ERROR);
            return ['path'=>$path,'kind'=>'json-parser','verified'=>true,'ok'=>true,'message'=>'JSON válido'];
        }catch(Throwable $e){return ['path'=>$path,'kind'=>'json-parser','verified'=>true,'ok'=>false,'message'=>$e->getMessage()];}
    }
    if(in_array($ext,['js','cjs','mjs'],true)&&$c['qa']['javascript']){
        // Shared hosting may disable process execution. Only node --check, never user code execution.
        if(function_exists('proc_open')&&!in_array('proc_open',array_map('trim',explode(',',ini_get('disable_functions'))),true)){
            $tmp=tempnam(sys_get_temp_dir(),'ndjs_');if($tmp!==false){$js=$tmp.'.'.$ext;rename($tmp,$js);file_put_contents($js,$src);
                $pipes=[];$process=@proc_open(['node','--check',$js],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,null,null,['bypass_shell'=>true]);
                if(is_resource($process)){fclose($pipes[0]);$stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$code=proc_close($process);@unlink($js);
                    if($code===0)return ['path'=>$path,'kind'=>'node-check','verified'=>true,'ok'=>true,'message'=>'Node sintaxis correcta'];
                    if($code!==127 && !str_contains(strtolower($stderr),'not found'))return ['path'=>$path,'kind'=>'node-check','verified'=>true,'ok'=>false,'message'=>substr($stderr?:$stdout,0,800)];
                }else @unlink($js);
            }
        }
        return ['path'=>$path,'kind'=>'node-check','verified'=>false,'ok'=>null,'message'=>'Node no disponible en hosting; revisión local pendiente'];
    }
    return ['path'=>$path,'kind'=>'manual-review','verified'=>false,'ok'=>null,'message'=>'Sin verificador ejecutable para esta extensión'];
}
function nd_checks(string $runId,array $config):array{
    $checks=[];foreach(nd_changes($runId) as $path=>$m){if($m['size']>1800000){$checks[]=['path'=>$path,'ok'=>false,'verified'=>true,'message'=>'Archivo excede tamaño soportado'];continue;}
        $checks[]=nd_syntax($path,(string)file_get_contents(nd_file($runId,$path,true)),$config);
    }return $checks;
}
function nd_log(array &$r,string $kind,string $detail,array $meta=[]):void{
    $r['state']['history'][]=['kind'=>$kind,'detail'=>mb_substr($detail,0,1200),'at'=>nexa_now()];
    if(count($r['state']['history'])>300)$r['state']['history']=array_slice($r['state']['history'],-300);
    nd_event($r['id'],$kind,$detail,$meta);
}
function nd_queue(array &$r,string $stage,array $messages):void{
    $c=$r['config'];$payload=['model'=>'qwen2.5-coder:7b','messages'=>$messages,'temperature'=>$c['temperature'],'topP'=>$c['topP'],
      'context'=>$c['context'],'numPredict'=>$c['tokens'],'timeoutMs'=>$c['limits']['operationSeconds']*1000];
    nd15_queue_model($r,$stage,$payload);
}
function nd_local_path(array $r,string $rel,bool $db=false):string{
    $project=nxp_project($r['project_id'],(int)$r['user_id']);
    $base=trim((string)($project['local_root']??''));
    if($base===''||strlen($base)>800||preg_match('/[\x00-\x1f]/',$base))throw new RuntimeException('Configura antes PC Workspace en Projects.');
    $rel=str_replace('\\','/',$rel);
    if($db){if(!preg_match('~^[a-zA-Z0-9_./ -]+\.(sqlite|sqlite3|db|sql)$~iD',$rel))throw new RuntimeException('Ruta de base no permitida.');
      foreach(explode('/',$rel) as $seg)if($seg===''||$seg==='.'||$seg==='..')throw new RuntimeException('Ruta de base inválida.');
    }else $rel=nd_safe_path($rel);
    return rtrim($base,'\\/').'\\'.str_replace('/','\\',$rel);
}
function nd_queue_tool(array &$r,string $type,array $payload):void{
    $id=nexa_uuid();$stmt=nd_db()->prepare('INSERT INTO jobs(id,type,payload_json,status,created_at,updated_at,user_id) VALUES(?,?,?,?,?,?,?)');
    $stmt->execute([$id,$type,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'queued',nexa_now(),nexa_now(),$r['user_id']]);
    $r['wait_job']=$id;$r['phase']='wait_tool';$r['state']['lastPcTool']=match($type){'developer.db.inspect'=>'pc_database','developer.browser.run'=>'pc_browser','developer.terminal.run'=>'pc_terminal','developer.git.run'=>'pc_git',default=>'pc-tool'};nd_log($r,'pc-tool','Ejecutando herramienta local autorizada: '.$type,['jobId'=>$id]);
}
function nd_pc_action(array &$r,array $a):bool{
    $kind=strtolower((string)($a['action']??''));$c=$r['config'];
    if($kind==='pc_status'){$type='developer.capabilities';$payload=[];}
    elseif($kind==='pc_read'){
        if(!$c['tools']['files'])throw new RuntimeException('Lectura PC desactivada.');
        $type='developer.file.read';$payload=['root'=>nd_remote_root($r),'path'=>nd_safe_path((string)($a['path']??''))];
    }elseif($kind==='pc_git'){
        if(!$c['tools']['git'])throw new RuntimeException('Git PC desactivado.');
        $op=(string)($a['operation']??'status');if(!in_array($op,['status','diff','log','branch','show','rev-parse'],true))throw new RuntimeException('Solo consultas Git de lectura.');
        $project=nxp_project($r['project_id'],(int)$r['user_id']);$root=trim((string)($project['local_root']??''));if($root==='')throw new RuntimeException('Sin PC Workspace.');
        $type='developer.git.run';$payload=['root'=>$root,'operation'=>$op];
        if($op==='log')$payload['limit']=max(1,min(50,(int)($a['limit']??20)));
        if(in_array($op,['show','rev-parse'],true)){$ref=(string)($a['ref']??'HEAD');if(!preg_match('/^[A-Za-z0-9._\/-]{1,100}$/',$ref)||str_starts_with($ref,'-'))throw new RuntimeException('Referencia Git inválida.');$payload['ref']=$ref;}
        if($op==='diff'&&is_array($a['paths']??null))$payload['paths']=array_slice(array_map(fn($x)=>nd_safe_path((string)$x),$a['paths']),0,12);
    }elseif($kind==='pc_database'){
        if(!$c['tools']['sqlite'])throw new RuntimeException('SQLite PC desactivado.');
        $type='developer.db.inspect';$payload=['path'=>nd_local_path($r,(string)($a['path']??''),true)];
    }elseif($kind==='pc_terminal'){
        if(!$c['tools']['terminal'])throw new RuntimeException('Terminal PC desactivada.');
        $command=strtolower((string)($a['command']??''));$check=(string)($a['check']??'version');
        if(!in_array($command,['node','php','git'],true))throw new RuntimeException('Comando de comprobación no permitido.');
        if($check==='syntax'&&in_array($command,['node','php'],true)){$file=nd_local_path($r,(string)($a['path']??''));$args=$command==='php'?['-l',$file]:['--check',$file];}
        elseif($check==='version')$args=[$command==='node'||$command==='git'?'--version':'-v'];
        else throw new RuntimeException('Solo comprobaciones de sintaxis o versión, sin ejecutar código arbitrario.');
        $project=nxp_project($r['project_id'],(int)$r['user_id']);$root=trim((string)($project['local_root']??''));if($root==='')throw new RuntimeException('Sin PC Workspace.');
        $type='developer.terminal.run';$payload=['cwd'=>$root,'command'=>$command,'args'=>$args,'timeoutMs'=>$c['limits']['operationSeconds']*1000];
    }elseif($kind==='pc_browser'){
        if(!$c['tools']['browser'])throw new RuntimeException('Browser PC desactivado.');
        $project=nxp_project($r['project_id'],(int)$r['user_id']);$url=(string)($project['staging_url']??'');
        if(!preg_match('~^https://[^\s]+$~i',$url))throw new RuntimeException('Configura URL de staging HTTPS en Projects antes de probar Browser.');
        // Only explicit staging URL and bounded UI actions. Never navigate elsewhere.
        $steps=[];
        if(is_array($a['steps']??null)){
            foreach(array_slice($a['steps'],0,15) as $step){
                if(!is_array($step))continue;
                $op=strtolower((string)($step['action']??''));
                if(!in_array($op,['waitfor','asserttext','asserturl','extract','click','type','select','press','wait','goto'],true))continue;
                $one=['action'=>$op];
                foreach(['selector','contains','attribute','text','value','key'] as $k)if(isset($step[$k])&&is_scalar($step[$k]))$one[$k]=substr((string)$step[$k],0,350);
                if($op==='goto'){
                    $next=trim((string)($step['url']??''));$start=parse_url($url);$target=parse_url($next);
                    if(!is_array($target)||strtolower((string)($target['scheme']??''))!=='https'||strtolower((string)($target['host']??''))!==strtolower((string)($start['host']??''))||($target['port']??443)!==($start['port']??443))throw new RuntimeException('Browser goto debe permanecer en el mismo origen HTTPS de staging.');
                    $one['url']=substr($next,0,1000);
                }
                if(in_array($op,['waitfor','goto'],true))$one['timeoutMs']=min(45000,max(1000,(int)($step['timeoutMs']??15000)));
                if($op==='wait')$one['ms']=min(4000,max(0,(int)($step['ms']??500)));
                $steps[]=$one;
            }
        }
        $type='developer.browser.run';$payload=['url'=>$url,'screenshot'=>false,'steps'=>$steps,'timeoutMs'=>$c['limits']['operationSeconds']*1000];
    }else return false;
    nd_queue_tool($r,$type,$payload);return true;
}
function nd_model_json(string $raw):array{
    $raw=trim($raw);
    // Accept a COMPLETE object, optionally enclosed in one Markdown JSON fence.
    // Never salvage an inner {"operation":...} from a truncated batch: it would
    // alter the action's meaning and could run unintended code.
    if(preg_match('/\A```(?:json)?\s*(.*?)\s*```\z/is',$raw,$match))$raw=trim($match[1]);
    try{$decoded=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}
    catch(JsonException $e){throw new RuntimeException('JSON mal formado o incompleto: '.$e->getMessage());}
    if(!is_array($decoded)||array_is_list($decoded)||$decoded===[])throw new RuntimeException('Qwen debe devolver un objeto JSON completo.');
    return $decoded;
}

function nd_context(array $r):string{
    $c=$r['config'];$parts=[];
    if(nd_remote_mode($r)){
        foreach(array_slice($r['state']['catalog']??[],0,$c['memory']['catalogFiles']) as $name)$parts[]=$name;
    }else{
        $manifest=nd_manifest($r['id']);foreach(array_slice($manifest,0,$c['memory']['catalogFiles'],true) as $name=>$meta)$parts[]=$name.' ('.$meta['size'].' bytes)';
    }
    $history=!empty($c['memory']['enabled'])?array_slice($r['state']['history']??[],-$c['memory']['history']):[];
    $plan=array_map(static fn($g)=>['id'=>$g['id']??'','title'=>$g['title']??'','phase'=>$g['phase']??'','dependsOn'=>$g['dependsOn']??[],
        'acceptance'=>$g['acceptance']??'','checks'=>$g['checks']??[],'status'=>$g['status']??'pending','attempts'=>$g['attempts']??0],$r['state']['objectives']??[]);
    $progress=ndp9_progress($r);
    return 'SOLICITUD: '.$r['request']."\nPLAN VIGENTE REV ".$progress['revision'].': '.json_encode($plan,JSON_UNESCAPED_UNICODE).
       "\nPROGRESO Y OBJETIVO ACTIVO: ".json_encode($progress,JSON_UNESCAPED_UNICODE)."\nCRITERIOS DE ACEPTACIÓN DEL USUARIO: ".json_encode($r['state']['acceptanceChecks']??[],JSON_UNESCAPED_UNICODE)."\nARCHIVOS DISPONIBLES:\n".implode("\n",$parts)."\nCAMBIOS: ".implode(', ',array_keys(nd_remote_mode($r)?($r['state']['changes']??[]):nd_changes($r['id'])))."\nHISTORIAL: ".json_encode($history,JSON_UNESCAPED_UNICODE)."\nULTIMA EVIDENCIA: ".substr((string)($r['state']['lastFeedback']??''),0,20000).nd03_context($r).nd03a_context($r);
}
function nd_plan_prompt(array $r):array{
    $sys='Eres SOLO qwen2.5-coder:7b. Planifica la solicitud REAL para un laboratorio WEB aislado. ' .
      'Devuelve EXCLUSIVAMENTE un JSON: {"summary":"...","objectives":[{"id":"o1","title":"...","phase":"investigacion","dependsOn":[],"acceptance":"...","checks":[{"type":"file_exists","path":"index.php"}]},{"id":"o2","title":"...","phase":"implementacion","dependsOn":["o1"],"acceptance":"...","checks":[{"type":"file_changed","path":"index.php"},{"type":"syntax","path":"index.php"}]}]}. ' .
      'Los IDs son únicos (o1,o2...), dependsOn usa IDs existentes y NO debe tener ciclos. Divide tareas complejas en fases y objetivos pequeños; fija dependencias reales. ' .
      'Cada objetivo lleva criterios verificables; tipos permitidos: file_changed, file_contains, file_not_contains, file_exists, syntax, no_duplicates, sqlite_table, browser_text, browser_url, test_passed. ' .
      'Para PHP que al ejecutarse debe devolver texto EXACTO, usa {"type":"php_output","path":"archivo.php","text":"SALIDA EXACTA"}; NUNCA uses browser_text para un archivo PHP sin desplegar. php_output exige QA funcional habilitado, ejecuta PHP CLI en copia temporal y compara salida exacta. browser_text solo observa HTTPS publicado. ' .
      'No inventes resultados ni datos. Si una meta requiere juicio humano, explica en acceptance qué debe comprobarse y no la marques como aprobada. ' .
      'Incluye sintaxis PHP/JS cuando corresponda; staging no prueba contenido nuevo sin desplegar. ' .
      'Si la tarea pide AGREGAR, EDITAR o CREAR una funcionalidad, el plan DEBE tener al menos un criterio file_changed para los archivos de CÓDIGO realmente modificados. file_exists, leer un archivo o afirmar que está listo NO demuestran una implementación. '
      .'Prioriza nombres que EXISTEN en el catálogo, no inventes rutas. Nunca uses rutas absolutas ni los directorios protegidos uploads/, data/, private/, secrets/, vendor/, node_modules/ o .git/ COMO path de criterios o herramientas. Puedes PROGRAMAR el manejo de uploads de usuarios dentro de clientes.php u otros archivos de código autorizados; NO manipules las licencias reales ni alteres la protección. '
      .'Para formularios con documentos personales exige una solución segura: validar MIME y tamaño, autorizar acceso, proteger datos privados y no exponer imágenes por URL pública. Si el entorno no permite garantizar estos requisitos, mantenlos pendientes, no afirmes éxito. '
      .'Antes de planificar consulta el CATÁLOGO Y LOS FRAGMENTOS DE CÓDIGO EN CONTEXTO. No marques un plan de desarrollo como terminado sin cambios nuevos y sus evidencias. '
      .'Si el usuario pide dos fotos de identidad en Nuevo cliente, DEBES conservar license_no como texto y añadir campos de archivo distintos; formulario multipart, $_FILES, validación de errores/tamaño/MIME finfo, nombres aleatorios, almacenamiento privado, migración SQLite y recuperación autenticada. Añade tres tests PHP ejecutables sobre el laboratorio, rutas tests/upload_positive.test.php, tests/upload_invalid.test.php y tests/upload_denied.test.php. Deben ejecutar solicitudes HTTP multipart reales y realizar aserciones; el primero verifica las dos fotos y persistencia, el segundo rechaza MIME/tamaño inválido, el tercero rechaza un acceso no autorizado. QA debe ejecutarlos en la copia temporal. Si faltan, mantén pendiente. Un par de inputs NO cumple el encargo; no digas listo si faltan partes. Nunca manipules licencias reales. '
      .'No elimines requisitos del usuario. Respeta límite de '.$r['config']['planning']['maxObjectives'].' objetivos. Estrategia '.$r['config']['planning']['strategy'].'.';
    $context=nd_context($r);
    if(!nd_remote_mode($r)){
        $man=nd_manifest((string)$r['id']);
        $parts=[];$used=0;
        foreach(array_keys($man) as $path){
            if(!preg_match('/\.(php|js|html|css|sql)$/i',$path))continue;
            $stem=strtolower(pathinfo($path,PATHINFO_FILENAME));
            $relevance=(preg_match('/client|customer|usuario|user/i',$path)&&preg_match('/client|licencia|selfie|foto|imagen|customer|photo/i',$r['request']))||
                (str_contains(strtolower($r['request']),$stem)&&strlen($stem)>=5);
            if(!$relevance)continue;
            $file=nd_file((string)$r['id'],$path,true);
            if(!is_file($file)||filesize($file)>300000)continue;
            $bytes=(string)file_get_contents($file,false,null,0,2800);
            $parts[]='ARCHIVO REAL: '.$path.' SHA256='.($man[$path]['sha256']??'').'\n'. $bytes;
            $used+=strlen($bytes);if(count($parts)>=3||$used>7000)break;
        }
        if($parts)$context.="\nFRAGMENTOS REALES PARA PLANIFICAR (solo lectura; no son evidencia QA):\n".implode("\n---\n",$parts);
    }
    return [['role'=>'system','content'=>$sys],['role'=>'user','content'=>$context]];
}
function nd_action_prompt(array $r):array{
    if(nd16a_mode($r))return nd16a_prompt($r);
    $c=$r['config'];$tools=['list','read','finish'];if($c['tools']['search'])$tools[]='search';if($c['tools']['files'])$tools=array_merge($tools,['replace','patch','create']);
    if($c['tools']['files'])$tools[]='edit_batch';
    if(nd_remote_mode($r))$tools[]='pc_status';foreach(array_merge(nd6_catalog_extra($r),nd7_catalog($r)) as $toolName=>$toolInfo)if($toolInfo['enabled']&&(nd_remote_mode($r)||!in_array($toolName,['git_local','terminal_local'],true)))$tools[]=$toolName;if(nd_remote_mode($r))$tools[]='pc_qa';$tools[]='tool_batch';if(nd_remote_mode($r)){if($c['tools']['git'])$tools[]='pc_git';if($c['tools']['sqlite'])$tools[]='pc_database';if($c['tools']['terminal'])$tools[]='pc_terminal';if($c['tools']['browser'])$tools[]='pc_browser';}
    $system='Eres SOLO qwen2.5-coder:7b en Developer Web. Responde UNA ÚNICA ACCIÓN JSON, NUNCA markdown. Acciones disponibles: '.implode(', ',$tools).'. '.
      'Permite herramientas secuenciales: {"action":"tool_batch","steps":[{"action":"read","path":"archivo.php"},{"action":"git_web","operation":"status"}]}. Máximo 12 pasos; cada paso devuelve evidencia real antes de continuar. No incluyas finish en un lote. '.
      'Formatos: {"action":"list"}, {"action":"search","term":"texto"}, {"action":"read","path":"archivo.php","startLine":1}, '.
      '{"action":"replace","path":"archivo.php","find":"fragmento EXACTO que existe","replace":"nuevo"}, '.
      '{"action":"patch","path":"archivo.php","hunks":[{"find":"texto exacto 1","replace":"nuevo 1"},{"find":"texto exacto 2","replace":"nuevo 2"}]}, '.
      '{"action":"create","path":"archivo-nuevo.php","content":"código"}, '.
      '{"action":"finish","summary":"qué implementaste","needsMoreWork":false}. '.
      'Para HTML visible en PHP, lee el archivo antes, inserta entre ?> y <?php en posición válida; NO insertes después de page_footer(). '.
      'Todas las herramientas de programación y QA se controlan y ejecutan en laboratorio WEB Hostinger; Windows solo atiende consultas de Qwen. '.
      'Ejemplos WEB: {"action":"git_web","operation":"init"}, {"action":"git_web","operation":"add","paths":["clientes.php"]}, {"action":"sqlite_local","operation":"migrate","sql":"CREATE TABLE demo(id INTEGER PRIMARY KEY)"}, {"action":"terminal_web","operation":"syntax","program":"php","path":"clientes.php"}, {"action":"browser_web","operation":"assert_status","status":200}. NO uses herramientas PC para editar proyectos. '.
      'Si un archivo ya tiene exactamente el contenido solicitado, NO intentes crearlo o reemplazarlo otra vez: usa finish para que se verifique el objetivo activo. Si NO_CHANGE, deja de editar y pide finish. No supongas aprobación sin QA. No uses replace a ciegas. No repitas acciones. Si recibes error, vuelve a leer y cambia de estrategia. '.
      'Para imágenes de identidad de clientes: no transformes license_no en file; utiliza dos campos nuevos y $_FILES con enctype multipart; código real del backend, persistencia SQLite de las dos referencias, validación MIME/size/error, almacenamiento privado, descarga solo autorizada y pruebas independientes reales tests/upload_positive.test.php, tests/upload_invalid.test.php y tests/upload_denied.test.php mediante PHP+cURL multipart, con aserciones y QA de copia. Un input type=file NO es funcionalidad terminada. No afirmes éxito si hay contrato pendiente. '.
      'El host verifica y revierte cambios inválidos; no supongas éxito. Nunca toques secretos ni originales. ' .
      'Estrategia de planificación: '.$c['planning']['strategy'].'. Trabaja SOLAMENTE en el objetivo activo del plan. Los objetivos dependientes solo avanzan cuando el evaluador verifica sus predecesores. Finish significa FIN DEL OBJETIVO ACTIVO, no fin de todo el proyecto. Si recibes un criterio fallido, repara antes de finish. Si es research-first, inspecciona primero estructura, búsqueda y código antes de editar. ' .
      'Modo de edición configurado: '.$c['editing']['mode'].'. Usa patch cuando haya varios cambios acotados en el mismo archivo; se acepta o rechaza todo el parche. Cada objetivo tendrá comprobaciones independientes. Antes de finish revisa qué pruebas siguen pendientes y corrige los defectos verificables. ' .
      'Para cambios de VARIOS archivos como una única operación, usa edit_batch: {"action":"edit_batch","operations":[{"operation":"replace","path":"index.php","sha256":"SHA leido","find":"ancla unica","replace":"nuevo"},{"operation":"create","path":"nuevo.php","content":"<?php echo 1;"}]}. El motor valida TODOS, conserva backups, admite create/write/replace/patch/copy/move/delete y revierte el lote entero si falla. SIEMPRE leer y obtener SHA del contenido actual para editar/borrar/copiar/mover archivos existentes. NO editar originales, solo laboratorio web. ' .
      'No confundas pruebas de staging (página desplegada) con validación del código nuevo sin desplegar. ' .
      'En laboratorio web, usa tools WEB: {"action":"files_web","operation":"hash","path":"index.php"}, {"action":"git_web","operation":"status"}, {"action":"terminal_web","operation":"syntax","program":"php","path":"index.php"}, {"action":"browser_web","operation":"assert_status","status":200}. SQLite usa sqlite_local init/schema/query/migrate/integrity/restore en base de prueba. Browser Web solo staging autorizado: HTTP no ejecuta JS, y headless exige Playwright en Hostinger. Para ejecutar pruebas del proyecto se exige approveTests=true; pruebas no equivalen a certificación de seguridad. No uses acciones PC para programar un ZIP web. La web nunca edita originales.';
    $system.=' '.nd18_action_prompt_instruction($r);
    return [['role'=>'system','content'=>$system],['role'=>'user','content'=>nd_context($r)]];
}
function nd_tool(array &$r,array $a):void{
    $action=strtolower(trim((string)($a['action']??$a['tool']??$a['operation']??'')));
    $aliases=['read_file'=>'read','file_read'=>'read','edit_file'=>'replace','replace_text'=>'replace','patch_file'=>'replace','write_file'=>'create','create_file'=>'create','list_files'=>'list','search_files'=>'search','done'=>'finish','complete'=>'finish'];
    $action=$aliases[$action]??$action;
    $a['action']=$action;
    if(nd16a_mode($r)&&!isset($r['state']['analysis16']))nd16a_begin($r);
    nd16a_guard($r,$action);nd13_check_action($r,$a);$a['path']=$a['path']??$a['file']??$a['file_path']??null;
    $a['find']=$a['find']??$a['old_text']??null;$a['replace']=$a['replace']??$a['new_text']??null;
    $a['content']=$a['content']??$a['code']??null;
    $id=$r['id'];$c=$r['config'];$feedback='';
    if($action==='edit_batch'){
        $result=nd11_batch($r,$a['operations']??null,true);
        $r['state']['lastFeedback']='EDIT_BATCH: '.json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        return;
    }
    if($action==='tool_batch'){
        $batch=$a['steps']??null;
        if(is_array($batch)&&count($batch)>nd10_snapshot($r,time())['remainingSteps'])
            throw new RuntimeException('Lote excede pasos restantes; reduce el lote o amplia el limite de la tarea pausada.');
        nd5_chain_start($r,$batch,false);return;
    }
    if(nd_remote_mode($r)&&nd_remote_action($r,$a))return;
    if($action==='list'){
        $files=array_keys(nd_manifest($id));$feedback='ARCHIVOS: '.implode(', ',array_slice($files,0,650));
        if(nd16a_mode($r))$r['state']['analysis16']['listed']=true;
    }elseif($action==='search'&&$c['tools']['search']){
        $term=trim((string)($a['term']??''));if(strlen($term)<2||strlen($term)>160)throw new RuntimeException('search.term inválido.');
        $matches=[];foreach(nd_manifest($id) as $path=>$meta){if(stripos($path,$term)!==false)$matches[]=$path.' (ruta)';if($meta['size']>400000)continue;
            $x=(string)file_get_contents(nd_file($id,$path,true));$at=stripos($x,$term);if($at!==false)$matches[]=$path.' ...'.substr($x,max(0,$at-100),240);
            if(count($matches)>55)break;
        }$feedback='SEARCH '.$term.': '.implode("\n",$matches);
    }elseif($action==='read'){
        $path=nd_safe_path((string)($a['path']??''));$src=(string)file_get_contents(nd_file($id,$path,true));
        $start=max(1,min(1000000,(int)($a['startLine']??1)));
        $lines=explode("\n",$src);$snippet=implode("\n",array_slice($lines,$start-1));
        $feedback='READ '.$path.' sha256='.hash('sha256',$src).' bytes='.strlen($src).' startLine='.$start.' totalLines='.count($lines)."\n".substr($snippet,0,$c['memory']['readChars']);
        $r['state']['readFiles'][$path]=hash('sha256',$src);
        if(nd16a_mode($r))$r['state']['analysis16']['readFiles'][$path]=hash('sha256',$src);
    }elseif(in_array($action,['replace','patch','create'],true)&&$c['tools']['files']){
        $path=nd_safe_path((string)($a['path']??''));$dest=nd_file($id,$path,$action!=='create');
        $exists=is_file($dest);$before=$exists?(string)file_get_contents($dest):'';
        if($action==='create'){
            if($exists)throw new RuntimeException('Archivo existente: usa replace después de leer.');
            $after=$a['content']??null;if(!is_string($after)||strlen($after)>1800000)throw new RuntimeException('Contenido inválido.');
        }else{
            if($c['editing']['requireRead']&&!isset($r['state']['readFiles'][$path]))throw new RuntimeException('Primero usa read para conocer el archivo.');
            if(isset($r['state']['readFiles'][$path])&&$r['state']['readFiles'][$path]!==hash('sha256',$before))throw new RuntimeException('PRECONDITION_SHA: cambió el archivo; vuelve a leer.');
            if($action==='patch')$after=ndv4_apply_patch($before,$a['hunks']??null);
            else{
                $find=$a['find']??null;$replace=$a['replace']??null;if(!is_string($find)||$find===''||!is_string($replace))throw new RuntimeException('replace requiere find/replace exactos.');
                $count=substr_count($before,$find);if($count!==1)throw new RuntimeException('ANCHOR_NON_UNIQUE: encontrados '.$count.' fragmentos; identifica un ancla única.');
                if($find===$replace)throw new RuntimeException('NO_CHANGE: contenido idéntico.');
                $after=substr_replace($before,$replace,strpos($before,$find),strlen($find));
            }
            if($before===$after)throw new RuntimeException('NO_CHANGE: no hubo edición.');
            if($action==='replace'&&$c['editing']['duplicateGuard']&&strlen($replace)>24 && substr_count($after,$replace)>max(1,substr_count($before,$replace)))throw new RuntimeException('DUPLICATE_GUARD: el mismo bloque ya aparece.');
        }
        if($c['repair']['stopRepeated']&&$action==='replace'&&isset($r['state']['lastEdit'])&&($r['state']['lastEdit']['path']??'')===$path&&($r['state']['lastEdit']['after']??'')===hash('sha256',$after))throw new RuntimeException('DUPLICATE_GUARD: no se permite aplicar de nuevo el mismo resultado.');
        if(strlen($after)>1800000)throw new RuntimeException('Archivo demasiado grande.');
        $issue=nd_label_guard($r['request'],$before,$after,$path);if($issue!==null)throw new RuntimeException($issue);
        $syntax=nd_syntax($path,$after,$c);
        if($syntax['ok']===false)throw new RuntimeException('QA_RECHAZADO '.$path.': '.$syntax['message']);
        if(!is_dir(dirname($dest)))mkdir(dirname($dest),0750,true);
        $tmp=$dest.'.ndtmp';if(file_put_contents($tmp,$after,LOCK_EX)===false)throw new RuntimeException('No se pudo escribir en la copia.');
        if(!rename($tmp,$dest)){@unlink($tmp);throw new RuntimeException('No se pudo aplicar el cambio.');}
        try{ndv4_checkpoint($r,$path,$exists?$before:null,$after);}catch(Throwable $e){
            if($exists)file_put_contents($dest,$before,LOCK_EX);else @unlink($dest);
            throw $e;
        }
        $r['state']['readFiles'][$path]=hash('sha256',$after);
        $r['state']['lastEdit']=['path'=>$path,'after'=>hash('sha256',$after)];
        $r['state']['edits']=($r['state']['edits']??0)+1;
        // Area 4: an accepted edit must invalidate stale goal approvals immediately.
        if(!empty($r['state']['objectives']))ndp9_revalidate_completed($r);
        unset($r['state']['evaluation'],$r['state']['qa'],$r['state']['artifact']);
        @unlink(nd_root($id).'/CHANGED_FILES_ONLY.zip');
        $feedback='EDICIÓN ACEPTADA '.$path.' SHA256='.hash('sha256',$after).' QA='.json_encode($syntax,JSON_UNESCAPED_UNICODE);
    }elseif($action==='finish'){
        if(nd16a_mode($r)){nd16a_finish($r,(string)($a['summary']??''));return;}
        $summary=(string)($a['summary']??'');
        if(ndp9_requires_change((string)($r['request']??'')) && ndp9_abandoned_finish($summary)){
            $r['state']['abandonedFinishCount']=(int)($r['state']['abandonedFinishCount']??0)+1;
            $r['state']['lastFeedback']='FIN_RECHAZADO: el plan vigente ya fue validado; no repitas el error de un plan anterior. Lee los archivos y aplica los cambios solicitados antes de terminar. Si una ruta está protegida, cambia el diseño del código, no la seguridad.';
            if($r['state']['abandonedFinishCount']>=2){
                $r['status']='paused';$r['error']='PLAN_STALLED: Qwen abandonó un plan válido dos veces sin implementar cambios. Se detuvo para evitar un bucle.';
                $r['state']['lastFeedback']=$r['error'];
            }
            nd_log($r,'finish-rejected',$r['state']['lastFeedback']);
            return;
        }
        $r['state']['modelSummary']=substr($summary,0,1800);
        if(!empty($a['needsMoreWork'])){$r['status']='paused';$r['state']['lastFeedback']='Qwen indicó trabajo pendiente';}
        elseif(!ndp9_goal_finish($r))$r['phase']='evaluate';
        nd_log($r,'finish',$r['state']['modelSummary']?:'Qwen solicitó finalizar un objetivo');return;
    }elseif(nd7_dispatch($r,$a)){
        ndp9_tag_tool_evidence($r,$a);
        if(($a['action']??'')==='files_web'&&in_array((string)($a['operation']??''),['copy','move','delete','restore_deleted'],true)&&!empty($r['state']['objectives']))
            ndp9_revalidate_completed($r);
        return;
    }
    elseif(nd6_dispatch($r,$a)){ndp9_tag_tool_evidence($r,$a);return;}
    elseif(nd_pc_action($r,$a)){return;}
    else throw new RuntimeException('Acción no permitida o herramienta desactivada: '.$action);
    $r['state']['lastFeedback']=$feedback;
    $sig=hash('sha256',json_encode($a,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    if($c['repair']['stopRepeated']&&$sig===($r['state']['lastSig']??'')&&!in_array($action,['read','list','search','replace','create'],true)){
        $r['state']['repeats']=($r['state']['repeats']??0)+1;
        if($r['state']['repeats']>=2)throw new RuntimeException('REPEAT_GUARD: acción repetida sin progreso.');
    }else $r['state']['repeats']=0;
    $r['state']['lastSig']=$sig;
    nd_log($r,'tool:'.$action,$feedback);
}
function nd_evaluate(array &$r):void{
    $changes=nd_changes($r['id']);$deleted=nd7_deletions($r);$checks=nd_checks($r['id'],$r['config']);
    $qa=['checks'=>$checks,'failed'=>count(array_filter($checks,fn($x)=>($x['ok']??null)===false)),
       'pending'=>count(array_filter($checks,fn($x)=>empty($x['verified'])))];
    // Area 8: real project QA is mandatory ONLY when functional QA is enabled.
    // Never use stale results after a source/database revision.
    if(!empty($r['config']['qa']['functional'])){
        $suite=$r['state']['qa12Suite']??nd12_auto_suite($r);
        if($suite){
            $functional=nd12_valid_result($r);
            if(!$functional)$functional=nd12_execute($r,$suite);
            $qa['functional']=$functional;
            $qa['failed']+=$functional['failed'];$qa['pending']+=$functional['pending'];
        }else{
            $qa['pending']++;$qa['functional']=['status'=>'pending','reason'=>'No hay casos funcionales disponibles. Configura una suite; no se certifica funcionalidad sin pruebas.'];
        }
    }
    $evaluation=ndv4_evaluate($r,$changes,$qa);
    $evaluation['independent14']=nd14_assess($r,$changes,$qa);
    $evaluation['featureContract17']=nd17_evaluate($r);
    if(($evaluation['featureContract17']['status']??'not_applicable')==='failed')$evaluation['failed']=max(1,(int)$evaluation['failed']);
    if(($evaluation['featureContract17']['status']??'not_applicable')==='pending')$evaluation['pending']=max(1,(int)$evaluation['pending']);
    // Área 10: nunca considerar certificado un requisito sin QA vigente y enlazado.
    if(($evaluation['independent14']['status']??'')==='failed')$evaluation['failed']=max(1,(int)$evaluation['failed']);
    if(($evaluation['independent14']['status']??'')==='pending')$evaluation['pending']=max(1,(int)$evaluation['pending']);
    $evaluation['functionalQA']=$qa['functional']??null;
    if(!empty($qa['functional'])){
        $evaluation['failed']+=(int)($qa['functional']['failed']??0);
        $evaluation['pending']+=(int)($qa['functional']['pending']??0)+((($qa['functional']['status']??'')==='pending'&&!isset($qa['functional']['pending']))?1:0);
    }
    $r['state']['evaluation']=$evaluation;$r['state']['qa']=$qa;$r['state']['changes']=$changes;$r['state']['deletions']=$deleted;
    // Every new evaluation supersedes a prior delivery; never expose a stale ZIP
    // after a repaired/failed or reconfigured QA run.
    unset($r['state']['artifact']);
    @unlink(nd_root($r['id']).'/CHANGED_FILES_ONLY.zip');
    $evaluation['syntaxChecks']=$qa['checks']??[];
    if($evaluation['failed']>0 && nd13_retry($r,$evaluation))return;
    if($r['status']==='paused')return; // rollback conflict or repeated failures require human review
    if($evaluation['failed']===0 && $qa['failed']===0)nd13_success($r,$evaluation);
    if(in_array(($evaluation['featureContract17']['status']??'not_applicable'),['pending','failed'],true)){
        $r['status']='incomplete';
        $r['error']='FUNCIONALIDAD INCOMPLETA (documentos privados): '.substr(implode(' | ',$evaluation['featureContract17']['missing']??[]),0,1400);
    }
    elseif(count($changes)===0&&count($deleted)===0){$r['status']='incomplete';$r['error']='No existen modificaciones verificables.';}
    elseif($qa['failed']>0||$evaluation['failed']>0){$r['status']='incomplete';$r['error']='No se cumplieron '.($qa['failed']+$evaluation['failed']).' verificaciones obligatorias.';}
    else{$r['status']='review_required';$r['error']=$evaluation['pending']?'Hay '.$evaluation['pending'].' criterios/validaciones pendientes.':'Cambios verificados instrumentalmente; falta aceptación funcional real.';}
    $r['phase']='complete';$r['finished_at']=nexa_now();
    nd_log($r,'evaluate','Resultados: '.count($changes).' archivos; '.$evaluation['passed'].' criterios aprobados, '.$evaluation['failed'].' fallidos, '.$evaluation['pending'].' pendientes; estado '.$r['status']);
    if((count($changes)>0||count($deleted)>0)&&$qa['failed']===0&&$evaluation['failed']===0&&
      (empty($r['config']['qa']['functional'])||$qa['pending']===0)&&
      ($evaluation['independent14']['status']??'pending')!=='failed'&&
      !in_array(($evaluation['featureContract17']['status']??'not_applicable'),['pending','failed'],true))nd_build_zip($r);
}
/** Failed deterministic assertions can trigger a repair instead of shipping a known-bad ZIP. */
function ndv4_retry_evaluation(array &$r,array $evaluation):bool{
    $max=(int)($r['config']['repair']['attempts']??0);
    $attempt=(int)($r['state']['evaluationRepairs']??0);
    if($attempt>=$max)return false;
    $failed=array_values(array_filter($evaluation['criteria']??[],fn($x)=>$x['status']==='failed'&&in_array($x['type'],['file_changed','file_contains','file_not_contains','no_duplicates','syntax'],true)));
    if(!$failed)return false;
    $r['state']['evaluationRepairs']=$attempt+1;
    $message='QA INDEPENDIENTE RECHAZÓ la entrega. Reparación '.($attempt+1).'/'.$max.': '.
      substr(json_encode($failed,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),0,3000).
      '. Lee de nuevo los archivos, corrige esos criterios y ejecuta finish de nuevo. No declares éxito sin evidencias.';
    $r['state']['lastFeedback']=$message;$r['phase']='action';
    nd_log($r,'acceptance-repair',$message);return true;
}

function nd_zip_store(array $entries,string $dest):void{
    $fp=fopen($dest,'wb');if(!$fp)throw new RuntimeException('No se pudo crear ZIP');
    $central='';$offset=0;$count=0;
    try{
        foreach($entries as $name=>$data){
            nd_safe_path((string)$name);if(!is_string($data))throw new RuntimeException('ZIP requiere texto binario definido');
            $size=strlen($data);$crc=crc32($data);$nlen=strlen($name);
            $local=pack('VvvvvvVVVvv',0x04034b50,20,0,0,0,0,$crc,$size,$size,$nlen,0);
            $record=$local.$name.$data;if(fwrite($fp,$record)!==strlen($record))throw new RuntimeException('Error escribiendo ZIP');
            $central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,0,0,$crc,$size,$size,$nlen,0,0,0,0,0,$offset).$name;
            $offset+=strlen($record);$count++;
        }
        fwrite($fp,$central);fwrite($fp,pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($central),$offset,0));
    }finally{fclose($fp);}
}
function nd_build_zip(array &$r):void{
    $changed=nd_changes($r['id']);$deleted=nd7_deletions($r);if(!$changed&&!$deleted)return;
    $dest=nd_root($r['id']).'/CHANGED_FILES_ONLY.zip';
    if(class_exists('ZipArchive')){
        $z=new ZipArchive();if($z->open($dest,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Error al generar ZIP');
        foreach($changed as $path=>$m)$z->addFile(nd_file($r['id'],$path,true),$path);
        if($deleted)$z->addFromString('NEXA_DELETIONS.json',json_encode(['version'=>1,'deleted'=>$deleted,'note'=>'Elimina estas rutas al aplicar el paquete, solo después de revisar'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
        $z->close();
    }else{
        // Portable, store-only ZIP fallback on hosts without php-zip.
        $entries=[];foreach($changed as $name=>$meta)$entries[$name]=(string)file_get_contents(nd_file($r['id'],$name,true));
        if($deleted)$entries['NEXA_DELETIONS.json']=json_encode(['version'=>1,'deleted'=>$deleted,'note'=>'Elimina estas rutas solo después de revisar'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
        nd_zip_store($entries,$dest);
    }
    $r['state']['artifact']=['name'=>'CHANGED_FILES_ONLY.zip','bytes'=>filesize($dest),'sha256'=>hash_file('sha256',$dest),'files'=>count($changed),'deleted'=>$deleted];
    nd_log($r,'artifact','ZIP generado: '.count($changed).' archivos',['sha256'=>$r['state']['artifact']['sha256']]);
}
function nd_tick(array &$r):void{
    if($r['status']!=='running')return;
    $s=&$r['state'];$c=$r['config'];
    nd10_clock_start($r,time());
    $limitReason=nd10_limit_reason($r,time());
    if($limitReason!==''){
        if(isset($s['toolChain']))nd5_chain_finish($r,$limitReason);
        if($r['wait_job']!=='' && in_array($r['phase'],['wait_plan','wait_action'],true)){
            $jobId=$r['wait_job'];$stmt=nd_db()->prepare('UPDATE jobs SET status="cancel_requested",updated_at=? WHERE id=? AND status IN ("queued","running")');
            $stmt->execute([nexa_now(),$jobId]);
            $r['wait_job']='';unset($s['waitSince']);
            $r['phase']=$r['phase']==='wait_plan'?'plan':'action';
            nd_log($r,'limit-job-cancel','Solicitud pendiente cancelada por el limite de tarea.',['jobId'=>$jobId]);
        }
        $r['status']='paused';$r['error']=$limitReason;nd_log($r,'limit',$limitReason);return;
    }
    if($r['phase']==='pc_prepare'&&nd_remote_mode($r)){nd_remote_prepare($r);return;}
    if($r['wait_job']!==''){
        $j=nexa_job($r['wait_job']);if(!$j){$r['status']='paused';$r['error']='Trabajo de Qwen desaparecido';return;}
        if(!in_array($j['status'],['done','error','cancelled'],true)){
            $since=(int)($s['waitSince']??time());
            if($r['phase']!=='wait_tool'&&time()-$since >= $c['limits']['operationSeconds']){
                $jobId=$r['wait_job'];
                $pdo=nd_db();$stmt=$pdo->prepare('UPDATE jobs SET status="cancel_requested",updated_at=? WHERE id=? AND status IN ("queued","running")');
                $stmt->execute([nexa_now(),$jobId]);
                $r['wait_job']='';unset($s['waitSince']);
                $r['status']='paused';$r['phase']=$r['phase']==='wait_plan'?'plan':'action';
                $r['error']='Qwen superó el tiempo por operación ('.$c['limits']['operationSeconds'].' s). Solicitud cancelada; revisa antes de reanudar.';
                nd_log($r,'operation-timeout',$r['error'],['jobId'=>$jobId]);return;
            }
            return;
        }
        $wasTool=$r['phase']==='wait_tool';
        $r['wait_job']='';unset($s['waitSince']);$r['phase']=$r['phase']==='wait_plan'?'plan_result':'action_result';
        if($wasTool&&nd_remote_mode($r)&&isset($r['state']['pendingOp'])){
            nd_remote_complete($r,$j);return;
        }
        if($wasTool){
            $s['steps']=($s['steps']??0)+1;
            $s['lastFeedback']='PC TOOL '.($j['status']==='done'?'RESULT':'ERROR').': '.substr(json_encode($j['result']??['error'=>$j['error_text']],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),0,18000);
            nd_log($r,'pc-result',$s['lastFeedback']);
            $r['state']['evidence'][]=['kind'=>($r['state']['lastPcTool']??'pc-tool'),'result'=>$j['result']??[],'at'=>nexa_now()];
            if(count($r['state']['evidence'])>50)$r['state']['evidence']=array_slice($r['state']['evidence'],-50);
            $r['phase']='action';return;
        }
        if($j['status']!=='done'){
            $s['errors']=($s['errors']??0)+1;$s['lastFeedback']='Qwen / PC error: '.($j['error_text']??$j['status']);
            nd_log($r,'model-error',$s['lastFeedback']);
            if($s['errors']>$c['limits']['retries']){$r['status']='paused';$r['error']=$s['lastFeedback'];return;}
            $r['phase']='action';return;
        }
        $content=(string)($j['result']['content']??'');
        try{$reply=nd_model_json($content);}
        catch(Throwable $e){
            $s['errors']=($s['errors']??0)+1;
            if($r['phase']==='action_result'){
                nd19_json_failure($r,$content);
                nd20_note_failure($r,'json');
                if($r['status']==='paused')return;
            }else{
                $s['lastFeedback']='JSON_INVALID_PLAN: '.$e->getMessage();nd_log($r,'invalid-json',$s['lastFeedback']);
            }
            if($s['errors']>$c['limits']['retries']){$r['status']='paused';$r['error']=$s['lastFeedback'];return;}
            $r['phase']=$r['phase']==='plan_result'?'plan':'action';return;
        }
        if($r['phase']==='plan_result'){
            if(nd16a_mode($r)){nd16a_begin($r);return;}
            try{
                ndp9_install($r,$reply);
                $s['errors']=0;$r['phase']='action';
                unset($s['lastRejectedPlanHash'],$s['sameRejectedPlanCount'],$s['abandonedFinishCount']);
                $s['lastFeedback']='Plan validado por Nexa. Ahora ejecuta los objetivos sobre el código real. No uses finish para repetir un rechazo anterior.';
                nd_log($r,'plan','Plan de '.count($s['objectives']).' objetivos, dependencias verificadas. Revisión '.($s['planRevision']??1));
            }catch(Throwable $e){
                $s['errors']=($s['errors']??0)+1;
                $hash=hash('sha256',json_encode($reply,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                $s['sameRejectedPlanCount']=$hash===($s['lastRejectedPlanHash']??'')?(int)($s['sameRejectedPlanCount']??0)+1:1;
                $s['lastRejectedPlanHash']=$hash;
                $s['lastFeedback']='PLAN RECHAZADO: '.$e->getMessage().'. El plan fue rechazado; NO envíes finish. Envía otro JSON de PLAN con rutas de código reales y criterios file_changed para cambios pedidos.';
                nd_log($r,'plan-rejected',$s['lastFeedback']);
                if($s['errors']>$c['limits']['retries']||$s['sameRejectedPlanCount']>=2){$r['status']='paused';$r['error']='PLAN_NO_PROGRESS: '.$s['lastFeedback'];}
                else $r['phase']='plan';
            }return;
        }
        // Analysis-only jobs: Hostinger has already inspected the files.
        // Do not execute repeated list/read operations chosen by the model.
        if(nd16a_mode($r)){
            $s['steps']=($s['steps']??0)+1;
            nd16a_reply($r,$reply);
            return;
        }
        $s['steps']=($s['steps']??0)+1;
        $beforeEdits=(int)($s['edits']??0);
        $beforeBatchSerial=(int)($s['edit11Serial']??0);
        $beforeObjective=$s['activeObjectiveId']??null;
        try{
            nd_tool($r,$reply);$s['errors']=0;
            nd16_clear_noop_if_progress($r,$beforeEdits,$beforeBatchSerial,$beforeObjective);
            nd18_clear_if_progress($r,$beforeEdits,$beforeBatchSerial,$beforeObjective);
            nd19_clear_if_progress($r,$beforeEdits,$beforeBatchSerial,$beforeObjective);
            nd20_note_progress($r,$beforeEdits,$beforeBatchSerial,$beforeObjective);
        }catch(Throwable $e){
            $noChange=nd16_handle_noop($r,$reply,$e);
            $recovered=$noChange?true:nd20_after_conflict($r,$reply,$e);
            if($recovered){$s['errors']=0;}
            else{
                $s['errors']=($s['errors']??0)+1;
                $s['lastFeedback']='OPERACIÓN RECHAZADA: '.$e->getMessage();nd_log($r,'rejected',$s['lastFeedback']);
                if($s['errors']>$c['repair']['attempts']){$r['status']='paused';$r['error']=$s['lastFeedback'];return;}
            }
            $msg=$e->getMessage();
            if(str_starts_with($msg,'CREATE_EXISTS ')||str_starts_with($msg,'Archivo existente:'))nd20_note_failure($r,'exists');
            elseif(str_starts_with($msg,'PRECONDITION_SHA')||str_starts_with($msg,'READ_STALE'))nd20_note_failure($r,'stale');
            nd20_note_progress($r,$beforeEdits,$beforeBatchSerial,$beforeObjective);
        }
        if($r['phase']==='action_result')$r['phase']='action';return;
    }
    if($r['phase']==='action'&&isset($r['state']['toolChain'])){
        $before=(int)($r['state']['toolChain']['cursor']??0);
        nd5_chain_tick($r);
        $after=isset($r['state']['toolChain'])?(int)$r['state']['toolChain']['cursor']:(int)count($r['state']['toolLastRun']['steps']??[]);
        if($after>$before)$s['limitToolSteps']=($s['limitToolSteps']??0)+($after-$before);
        return;
    }
    if($r['phase']==='evaluate'&&nd16a_mode($r)){nd16a_begin($r);return;}
    if($r['phase']==='evaluate'){if(ndv4_schedule_acceptance($r))return; if(nd_remote_mode($r)){nd_remote_queue_qa($r);}else{nd_evaluate($r);}return;}
    if($r['phase']==='plan'&&nd16a_mode($r)){nd16a_begin($r);return;}
    if($r['phase']==='plan'&&$c['planning']['enabled']){nd_queue($r,'plan',nd_plan_prompt($r));return;}
    if($r['phase']==='plan'){$r['phase']='action';return;}
    if($r['phase']==='action'){
        if(nd16a_mode($r)){if(!isset($r['state']['analysis16']))nd16a_begin($r);nd16a_inspect($r);if($r['status']==='running')nd_queue($r,'action',nd16a_prompt($r));return;}
        // Recover an existing Qwen-authored plan that incorrectly demands
        // deployed-browser evidence for an explicit, local PHP CLI output.
        // The correction is recorded, never represents staging as verified,
        // and never modifies the source project.
        if(nd16_php_reconcile($r)){
            ndp9_goal_finish($r);
            return;
        }
        nd_queue($r,'action',!empty($s['jsonRecovery19']['count'])?nd19_compact_prompt($r):nd_action_prompt($r));return;
    }
}
function nd_status(array $r):array{
    $s=$r['state'];return ['mode'=>$s['mode']??'web-isolated','pcWorkspaceId'=>$s['pcWorkspaceId']??null,'pendingOp'=>$s['pendingOp']['kind']??null,'id'=>$r['id'],'projectId'=>$r['project_id'],'request'=>$r['request'],'status'=>$r['status'],'phase'=>$r['phase'],
        'limits'=>nd10_snapshot($r,time()),'configuredLimits'=>nd10_clean_limits($r['config']['limits']??[]),
        'steps'=>$s['steps']??0,'edits'=>$s['edits']??0,'error'=>$r['error'],'objectives'=>$s['objectives']??[],
        'planProgress'=>ndp9_progress($r),'planSummary'=>$s['planSummary']??'','planHistory'=>$s['planHistory']??[],
        'qa'=>$s['qa']??null,'qa12Suite'=>$s['qa12Suite']??[],'qa12Result'=>nd12_valid_result($r),'qa12Stale'=>isset($s['qa12Result'])&&nd12_valid_result($r)===null,'evaluation'=>$s['evaluation']??null,'acceptanceChecks'=>$s['acceptanceChecks']??[],'evaluationRepairs'=>$s['repair13']['attempts']??($s['evaluationRepairs']??0),'repair13'=>$s['repair13']??null,'checkpoints'=>array_map(fn($x)=>['id'=>$x['id'],'path'=>$x['path'],'at'=>$x['at'],'used'=>$x['used']??false],$s['checkpoints']??[]),'artifact'=>$s['artifact']??null,'deletions'=>$s['deletions']??(nd_remote_mode($r)?[]:nd7_deletions($r)),'changes'=>nd_remote_mode($r)?($s['changes']??[]):nd_changes($r['id']),
        'toolBatch'=>isset($s['toolChain'])?['cursor'=>$s['toolChain']['cursor'],'total'=>count($s['toolChain']['steps'])]:null,'toolLastRun'=>$s['toolLastRun']??null,'waitJob'=>$r['wait_job']!==''?'waiting':'','createdAt'=>$r['created_at'],'updatedAt'=>$r['updated_at'],
        'lastFeedback'=>substr((string)($s['lastFeedback']??''),0,1700),'summary'=>$s['modelSummary']??'',
        'analysisReport'=>$s['analysisReport']??null,
        'tracking15'=>['recoveredLeases'=>(int)($s['tracking15']['recoveredLeases']??0),'missingJobs'=>(int)($s['tracking15']['missingJobs']??0),'lastPhase'=>$r['phase']]];
}
