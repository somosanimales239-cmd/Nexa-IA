<?php
declare(strict_types=1);
/**
 * Nexa Developer 03.2: bounded read-only reference lookup in imported Web workspaces.
 * Results are STATIC EVIDENCE or CANDIDATES, not runtime-verified cross-file links.
 * This module does NOT call Aider, execute imported PHP/JS, modify workspaces or SQLite.
 */
const ND03R_VERSION='web-symbols-03.2';
const ND03R_EXTENSIONS=['php','js','cjs','mjs','jsx','ts','tsx'];
function nd03r_name_ids():array {
    $ids=[T_STRING];
    foreach(['T_NAME_QUALIFIED','T_NAME_FULLY_QUALIFIED','T_NAME_RELATIVE'] as $name)if(defined($name))$ids[]=constant($name);
    return $ids;
}
function nd03r_file(string $projectId,string $rel):?string {
    if($rel===''||str_contains($rel,"\0")||str_contains($rel,'\\')||str_starts_with($rel,'/')||strlen($rel)>500)return null;
    foreach(explode('/',$rel) as $piece)if($piece===''||$piece==='.'||$piece==='..')return null;
    if(!in_array(strtolower(pathinfo($rel,PATHINFO_EXTENSION)),ND03R_EXTENSIONS,true))return null;
    $root=realpath(nxp_workspace_dir($projectId));$file=nxp_path($projectId,$rel);
    if(!$root||is_link($file)||!is_file($file))return null;
    $real=realpath($file);
    if(!$real||!str_starts_with($real,$root.DIRECTORY_SEPARATOR))return null;
    if((int)filesize($real)>ND03_MAX_SOURCE)return null;
    return $real;
}
function nd03r_name(string $name):string{return strtolower(ltrim($name,'\\'));}
function nd03r_php_name_info(string $source):array {
    $t=nd03_php_tokens($source);$n=count($t);$ns='';$imports=['class'=>[],'function'=>[]];$depth=0;$nsDepth=-1;$namespaceCount=0;
    for($i=0;$i<$n;$i++){
        $v=$t[$i];if($v['id']===0){if($v['text']==='{')$depth++;elseif($v['text']==='}')$depth--;continue;}
        if($v['id']===T_NAMESPACE){$namespaceCount++;$raw='';$terminator='';
            for($j=$i+1;$j<$n;$j++){if(in_array($t[$j]['text'],[';','{'],true)){$terminator=$t[$j]['text'];break;}$raw.=$t[$j]['text'];}
            $ns=trim(preg_replace('/\s+/','',$raw)??$raw,'\\');$imports=['class'=>[],'function'=>[]];
            $nsDepth=$terminator==='{'?$depth+1:-1;continue;
        }
        if($v['id']!==T_USE||($depth!==0&&$depth!==$nsDepth))continue;
        $j=nd03_php_sig($t,$i+1);$kind='class';
        if(($t[$j]['id']??null)===T_FUNCTION){$kind='function';$j=nd03_php_sig($t,$j+1);}
        // Group imports and trait use are deliberately not resolved here.
        $raw='';for($k=$j;$k<$n&&$k<$j+80;$k++){if($t[$k]['text']===';')break;$raw.=$t[$k]['text'];}
        if(($t[$k]['text']??'')!==';'||str_contains($raw,'{')||str_contains($raw,'('))continue;
        foreach(explode(',',$raw) as $part){$part=trim($part);
            if(!preg_match('/^([A-Za-z_][A-Za-z0-9_\\\\]*)(?:\s+as\s+([A-Za-z_][\w]*))?$/i',$part,$m))continue;
            $full=trim($m[1],'\\');$short=$m[2]??substr($full,(strrpos($full,'\\')===false?0:strrpos($full,'\\')+1));
            if($short!=='')$imports[$kind][strtolower($short)]=$full;
        }
    }
    return ['namespace'=>$ns,'imports'=>$imports,'namespaceCount'=>$namespaceCount];
}
function nd03r_php_matches(string $name,string $namespace,array $imports,string $kind,string $target):?string {
    $nm=ltrim($name,'\\');$low=strtolower($nm);$want=nd03r_name($target);
    if(str_starts_with($name,'\\'))return $low===$want?'qualified':null;
    if(str_contains($nm,'\\'))return strtolower(($namespace!==''?$namespace.'\\':'').$nm)===$want?'qualified':null;
    if(isset($imports[$kind][$low]))return nd03r_name($imports[$kind][$low])===$want?'import-alias':null;
    return nd03r_name(($namespace!==''?$namespace.'\\':'').$nm)===$want?'same-namespace':null;
}
function nd03r_result(string $path,int $line,string $kind,string $confidence,string $detail):array {
    return ['path'=>$path,'line'=>$line,'kind'=>$kind,'confidence'=>$confidence,'evidence'=>$detail,'runtimeVerified'=>false];
}
function nd03r_php_refs(string $source,string $path,array $target):array {
    $t=nd03_php_tokens($source);$n=count($t);$meta=nd03r_php_name_info($source);$namespace=$meta['namespace'];$imports=$meta['imports'];
    // A multi-namespace PHP file needs token-scoped bindings; do not invent references.
    if(($meta['namespaceCount']??0)>1)return [];
    $nameIds=nd03r_name_ids();$wanted=strtolower((string)$target['name']);$type=(string)$target['type'];$refs=[];
    $classes=[];
    if($type==='method')foreach(nd03_php_definitions($source,$path) as $s){if(in_array($s['type'],['class','trait','interface','enum'],true))$classes[]=$s;}
    for($i=0;$i<$n;$i++){
        $tok=$t[$i];if(!in_array($tok['id'],$nameIds,true)||$tok['text']==='')continue;
        $tokenName=$tok['text'];$base=substr($tokenName,(strrpos($tokenName,'\\')===false?0:strrpos($tokenName,'\\')+1));
        if(strtolower($base)!==$wanted&&!in_array($type,['class','interface','trait','enum','function'],true))continue;
        $prev=nd03_php_sig($t,$i-1,-1);$next=nd03_php_sig($t,$i+1);$before=$t[$prev]??[];$after=$t[$next]??[];
        $prevId=$before['id']??null;$nextText=$after['text']??'';
        if($type==='function'){
            if($nextText!=='('||in_array($prevId,[T_FUNCTION,T_FN,T_NEW,T_OBJECT_OPERATOR,T_NULLSAFE_OBJECT_OPERATOR,T_DOUBLE_COLON],true))continue;
            $match=nd03r_php_matches($tokenName,$namespace,$imports,'function',$target['qualifiedName']);
            if($match===null)continue;
            $refs[]=nd03r_result($path,$tok['line'],'function-call',$match==='same-namespace'?'lexical':'import-linked',$match);
        }elseif($type==='method'){
            if($nextText!=='('||!in_array($prevId,[T_OBJECT_OPERATOR,T_NULLSAFE_OBJECT_OPERATOR,T_DOUBLE_COLON],true))continue;
            $owner=(string)($target['container']??'');$beforeOwner=$t[nd03_php_sig($t,$prev-1,-1)]??[];
            if($prevId===T_DOUBLE_COLON){
                if(!in_array($beforeOwner['id']??null,$nameIds,true))continue;
                $match=nd03r_php_matches($beforeOwner['text'],$namespace,$imports,'class',$owner);
                if($match!==null)$refs[]=nd03r_result($path,$tok['line'],'static-method-call','import-linked','Clase identificada: '.$match);
            }elseif(($beforeOwner['text']??'')==='$this'){
                foreach($classes as $class){if($tok['line']>$class['startLine']&&$tok['line']<=$class['endLine']&&nd03r_name($class['qualifiedName'])===nd03r_name($owner)){
                    $refs[]=nd03r_result($path,$tok['line'],'this-method-call','lexical','Método dentro de su clase');break;
                }}
            }
        }else{
            $isClassContext=in_array($prevId,[T_NEW,T_EXTENDS,T_IMPLEMENTS,T_INSTANCEOF],true)||$nextText==='::';
            if(!$isClassContext)continue;
            $match=nd03r_php_matches($tokenName,$namespace,$imports,'class',$target['qualifiedName']);
            if($match===null)continue;
            $refs[]=nd03r_result($path,$tok['line'],'class-reference',$match==='same-namespace'?'lexical':'import-linked',$match);
        }
        if(count($refs)>=100)break;
    }
    return nd03r_dedup($refs);
}
function nd03r_module_path(string $current,string $specifier,string $target):bool {
    if(!str_starts_with($specifier,'.'))return false;
    $base=dirname($current);$parts=[];
    foreach(explode('/',str_replace('\\','/',$base.'/'.$specifier)) as $seg){if($seg===''||$seg==='.')continue;if($seg==='..'){array_pop($parts);continue;}$parts[]=$seg;}
    $normalized=implode('/',$parts);
    $paths=[$normalized];foreach(['.js','.jsx','.ts','.tsx','.mjs','.cjs','/index.js','/index.ts','/index.tsx'] as $suffix)$paths[]=$normalized.$suffix;
    // TypeScript source may be imported using transpiled .js extensions.
    if(str_ends_with($normalized,'.js'))foreach(['.ts','.tsx'] as $suffix)$paths[]=substr($normalized,0,-3).$suffix;
    return in_array($target,$paths,true);
}
function nd03r_js_imports(string $source,string $mask,string $path,string $targetPath):array {
    $imports=[];
    if(preg_match_all('/\bimport\s*\{([^}]{1,700})\}\s*from\s*[\'\"]([^\'\"\r\n]{1,300})[\'\"]/m',$source,$mm,PREG_OFFSET_CAPTURE)){
        foreach($mm[0] as $i=>$hit){$at=$hit[1];if(substr($mask,$at,6)!=='import')continue;
            if(!nd03r_module_path($path,$mm[2][$i][0],$targetPath))continue;
            foreach(explode(',',$mm[1][$i][0]) as $part){$part=trim($part);
                if(preg_match('/^([A-Za-z_$][\w$]*)(?:\s+as\s+([A-Za-z_$][\w$]*))?$/',$part,$m))$imports[$m[1]]=$m[2]??$m[1];
            }
        }
    }
    // CommonJS named destructuring: const { original: alias } = require('./module').
    if(preg_match_all('/\b(?:const|let|var)\s*\{([^}]{1,700})\}\s*=\s*require\s*\(\s*[\'\"]([^\'\"\r\n]{1,300})[\'\"]\s*\)/m',$source,$mm,PREG_OFFSET_CAPTURE)){
        foreach($mm[0] as $i=>$hit){$at=$hit[1];if(!preg_match('/^(?:const|let|var)\b/',substr($mask,$at,6)))continue;
            if(!nd03r_module_path($path,$mm[2][$i][0],$targetPath))continue;
            foreach(explode(',',$mm[1][$i][0]) as $part){$part=trim($part);
                if(preg_match('/^([A-Za-z_$][\w$]*)(?:\s*:\s*([A-Za-z_$][\w$]*))?$/',$part,$m))$imports[$m[1]]=$m[2]??$m[1];
            }
        }
    }
    return $imports;
}
function nd03r_js_refs(string $source,string $path,array $target):array {
    $mask=nd03_js_mask($source);$name=preg_quote($target['name'],'/');$type=$target['type'];$refs=[];
    $imports=nd03r_js_imports($source,$mask,$path,$target['path']);$aliases=[];
    if($type!=='method'){
        foreach($imports as $original=>$local)if($original===$target['name'])$aliases[$local]='import-linked';
        if($path===$target['path'])$aliases[$target['name']]='same-file';
    }
    $targetClass=(string)($target['container']??'');
    $ownerClasses=[];
    if($type==='method'&&$path===$target['path']){
        [$pairs]=nd03_js_brace_pairs($mask);
        $classPattern='/\bclass\s+'.preg_quote($targetClass,'/').'\b[^\{;]{0,300}\{/';
        if(preg_match_all($classPattern,$mask,$cm,PREG_OFFSET_CAPTURE))foreach($cm[0] as $hit){
            $open=$hit[1]+strlen($hit[0])-1;
            if(isset($pairs[$open]))$ownerClasses[]=['start'=>$open,'end'=>$pairs[$open]];
        }
    }
    foreach($aliases as $local=>$why){
        $quoted=preg_quote($local,'/');$pattern=in_array($type,['class','interface','trait','enum'],true)?'/\b(?:new\s+|extends\s+)('.$quoted.')\b/':'/(?<![\w$.])('.$quoted.')\s*\(/';
        if(preg_match_all($pattern,$mask,$matches,PREG_OFFSET_CAPTURE))foreach($matches[1] as $match){
            $at=$match[1];$line=nd03_line($source,$at);
            // A same-line declaration must not be mistaken for a call.
            $prefix=substr($mask,max(0,$at-35),min(35,$at));
            if($path===$target['path']&&$line===$target['startLine']&&preg_match('/\b(?:function|class|const|let|var)\s*$/',$prefix))continue;
            $refs[]=nd03r_result($path,$line,$type==='class'?'class-reference':'function-call',$why==='import-linked'?'import-linked':'lexical',$why);
            if(count($refs)>=100)break;
        }
    }
    if($type==='method'&&$ownerClasses){
        if(preg_match_all('/\bthis\s*\.\s*('.$name.')\s*\(/',$mask,$mm,PREG_OFFSET_CAPTURE))foreach($mm[1] as $match){
            $line=nd03_line($source,$match[1]);foreach($ownerClasses as $class){if($match[1]>$class['start']&&$match[1]<$class['end']){
                $refs[]=nd03r_result($path,$line,'this-method-call','lexical','Dentro de la clase '.$targetClass);break;
            }}
        }
    }
    return nd03r_dedup($refs);
}
function nd03r_dedup(array $refs):array {
    $unique=[];foreach($refs as $r){$key=$r['path'].'|'.$r['line'].'|'.$r['kind'];$unique[$key]=$r;}
    $refs=array_values($unique);usort($refs,static fn($a,$b)=>($a['line']<=>$b['line'])?:strcmp($a['kind'],$b['kind']));return array_slice($refs,0,100);
}
function nd03r_references_page(string $projectId,string $path,string $name,string $type,int $line,string $expectedHash,int $offset=0,int $limit=15):array {
    $file=nd03r_file($projectId,$path);
    if(!$file)throw new RuntimeException('El archivo del símbolo no está disponible o no está permitido.');
    $source=file_get_contents($file);if(!is_string($source))throw new RuntimeException('No se pudo leer el símbolo.');
    $hash=hash('sha256',$source);
    if($expectedHash!==''&&!hash_equals($hash,$expectedHash))throw new RuntimeException('El archivo fue modificado. Vuelve a analizar los símbolos.');
    $def=nd03_analyze_source($path,$source);$target=null;
    foreach($def['symbols'] as $s)if($s['qualifiedName']===$name&&$s['type']===$type&&$s['startLine']===$line){$target=$s;break;}
    if(!$target)throw new RuntimeException('El símbolo no existe en la versión actual del archivo. Vuelve a analizar.');
    $entries=array_values(array_filter(nxp_walk($projectId),static fn($row)=>in_array(strtolower(pathinfo($row['path'],PATHINFO_EXTENSION)),ND03R_EXTENSIONS,true)));
    $total=count($entries);$offset=max(0,min($total,$offset));$limit=max(1,min(20,$limit));$selected=array_slice($entries,$offset,$limit);
    $all=[];$scanned=0;$skipped=[];
    foreach($selected as $row){
        $filePath=nd03r_file($projectId,$row['path']);if(!$filePath){$skipped[]=$row['path'];continue;}
        $content=file_get_contents($filePath);if(!is_string($content)||strlen($content)>ND03_MAX_SOURCE){$skipped[]=$row['path'];continue;}
        $scanned++;
        if(strtolower(pathinfo($row['path'],PATHINFO_EXTENSION))==='php'&&$target['language']==='php')$hits=nd03r_php_refs($content,$row['path'],$target);
        elseif(strtolower(pathinfo($row['path'],PATHINFO_EXTENSION))!=='php'&&$target['language']==='js')$hits=nd03r_js_refs($content,$row['path'],$target);
        else $hits=[];
        foreach($hits as $hit){$all[]=$hit;if(count($all)>=160)break 2;}
    }
    return ['version'=>ND03R_VERSION,'aiderConnected'=>false,'readOnly'=>true,'target'=>['path'=>$path,'name'=>$name,'type'=>$type,'startLine'=>$line,'sha256'=>$hash],
       'totalEligibleFiles'=>$total,'offset'=>$offset,'nextOffset'=>$offset+count($selected)<$total?$offset+count($selected):null,
       'scannedFiles'=>$scanned,'hits'=>$all,'hitsThisPage'=>count($all),'skipped'=>$skipped,
       'note'=>'Vínculos léxicos por espacio de nombres/importación o candidatos acotados. No son referencias verificadas por LSP/Tree-sitter de Aider.'];
}
