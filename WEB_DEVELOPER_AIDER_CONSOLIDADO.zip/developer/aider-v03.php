<?php
declare(strict_types=1);
/**
 * Developer-only Aider analysis boundary. No arbitrary terminal or code execution.
 * Web can enqueue a strictly bounded tool only after the installed Windows worker
 * explicitly advertises this exact protocol in its recent authenticated heartbeat.
 * PHP/JS fallback from symbols-v03.php always remains available.
 */
const ND03A_PROTOCOL='nexa-aider-symbols/v1';
const ND03A_QUEUE_TYPE='developer.aider.analyze';
const ND03A_MAX_FILES=300;
const ND03A_MAX_SYMBOLS=120;
const ND03A_MAX_BYTES=1800000;
function nd03a_schema(PDO $pdo):void {
    // Aider has a SEPARATE queue; api/agent/next.php never sees these jobs.
    // The older nd03_aider_jobs table is deliberately left untouched.
    $pdo->exec('CREATE TABLE IF NOT EXISTS nd03_aider_workers_v2 (
        worker_id TEXT PRIMARY KEY, protocol TEXT NOT NULL, version TEXT NOT NULL,
        analysis_only INTEGER NOT NULL, root_bound INTEGER NOT NULL, available INTEGER NOT NULL,
        last_seen TEXT NOT NULL)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS nd03_aider_jobs_v2 (
        id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, project_id TEXT NOT NULL,
        worker_id TEXT NOT NULL, local_root TEXT NOT NULL,
        status TEXT NOT NULL, report_json TEXT NOT NULL DEFAULT "",
        error_text TEXT NOT NULL DEFAULT "", created_at TEXT NOT NULL, updated_at TEXT NOT NULL)');
    $pdo->exec('CREATE INDEX IF NOT EXISTS nd03_aider_v2_project ON nd03_aider_jobs_v2(user_id,project_id,created_at)');
    $pdo->exec('CREATE INDEX IF NOT EXISTS nd03_aider_v2_poll ON nd03_aider_jobs_v2(worker_id,status,created_at)');
}
function nd03a_root(string $value):string {
    $raw=trim(str_replace('/','\\',$value));
    if(strlen($raw)>700 || !preg_match('/^[A-Za-z]:\\\\(?:[^\\\\:\x00-\x1f]+\\\\)+[^\\\\:\x00-\x1f]+$/D',$raw))
        throw new RuntimeException('Indica una carpeta de proyecto Windows: D:\\Projects\\MiProyecto (no la raiz del disco).');
    if(preg_match('/(?:^|\\\\)\.{1,2}(?:\\\\|$)/',$raw) || strpbrk($raw,'*?"|<>')!==false)
        throw new RuntimeException('Ruta Windows no permitida.');
    return rtrim($raw,'\\');
}
function nd03a_normal_root(string $root):string {return strtolower(str_replace('/','\\',rtrim($root,'\\/')));}
function nd03a_worker_id(string $id):string {
    if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new RuntimeException('Identificador del Worker invalido.');
    return $id;
}
/** Only the authenticated Developer-specific endpoint calls this function. */
function nd03a_worker_hello(PDO $pdo,array $payload):array {
    nd03a_schema($pdo);
    $id=nd03a_worker_id(strtolower(trim((string)($payload['workerId']??''))));
    $proto=(string)($payload['protocol']??'');
    $only=($payload['analysisOnly']??false)===true;
    $bound=($payload['rootBound']??false)===true;
    $available=($payload['available']??false)===true;
    if($proto!==ND03A_PROTOCOL||!$only||!$bound)throw new RuntimeException('Worker no anuncia el protocolo Aider seguro.');
    $version=substr((string)($payload['version']??''),0,40);
    if($version===''||!preg_match('/^[A-Za-z0-9._+\-]+$/D',$version))throw new RuntimeException('Version de Aider invalida.');
    $now=nexa_now();
    $stmt=$pdo->prepare('INSERT INTO nd03_aider_workers_v2(worker_id,protocol,version,analysis_only,root_bound,available,last_seen) VALUES(?,?,?,?,?,?,?) ON CONFLICT(worker_id) DO UPDATE SET protocol=excluded.protocol,version=excluded.version,analysis_only=excluded.analysis_only,root_bound=excluded.root_bound,available=excluded.available,last_seen=excluded.last_seen');
    $stmt->execute([$id,$proto,$version,1,1,$available?1:0,$now]);
    return ['ok'=>true,'protocol'=>ND03A_PROTOCOL,'serverTime'=>$now,'separateQueue'=>true];
}
function nd03a_worker_rows(PDO $pdo):array {
    nd03a_schema($pdo);
    $cut=gmdate('c',time()-180);
    $stmt=$pdo->prepare('SELECT worker_id,version,last_seen FROM nd03_aider_workers_v2 WHERE protocol=? AND available=1 AND analysis_only=1 AND root_bound=1 AND last_seen>=? ORDER BY last_seen DESC,worker_id ASC LIMIT 10');
    $stmt->execute([ND03A_PROTOCOL,$cut]);return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function nd03a_capability(?PDO $pdo=null):array {
    $pdo=$pdo??nd_db();$workers=nd03a_worker_rows($pdo);$supported=count($workers)>0;
    return ['ready'=>$supported,'connected'=>$supported,'protocol'=>ND03A_PROTOCOL,
        'analysisOnly'=>true,'capabilityVerified'=>$supported,'separateQueue'=>true,
        'aiderVersion'=>$supported?$workers[0]['version']:null,
        'workerCount'=>count($workers),
        // The Web never exposes the private worker identifier to the browser.
        'message'=>$supported?'Aider Worker verificado; cola Developer exclusiva y analisis de solo lectura.':
          'No hay Worker Aider compatible en la cola exclusiva. El detector Web sigue operativo.'];
}
function nd03a_jobs(PDO $pdo,int $userId,string $projectId):array {
    nd03a_schema($pdo);
    $s=$pdo->prepare('SELECT * FROM nd03_aider_jobs_v2 WHERE user_id=? AND project_id=? ORDER BY created_at DESC,id DESC LIMIT 1');
    $s->execute([$userId,$projectId]);return $s->fetch(PDO::FETCH_ASSOC)?:[];
}
function nd03a_status(PDO $pdo,int $userId,string $projectId,bool $refresh=true):array {
    $row=nd03a_jobs($pdo,$userId,$projectId);
    if($row && $refresh && in_array($row['status'],['queued','running'],true)){
        $updated=strtotime((string)$row['updated_at']);
        $elapsed=$updated===false?PHP_INT_MAX:time()-$updated;
        $maxAge=$row['status']==='running'?1800:1200;
        if($elapsed>$maxAge){
            $row['status']='error';$row['error_text']='Timeout de la cola Aider: no se recibio resultado. Puedes reintentar.';
            $s=$pdo->prepare('UPDATE nd03_aider_jobs_v2 SET status=?,error_text=?,updated_at=? WHERE id=? AND user_id=? AND status IN ("queued","running")');
            $s->execute([$row['status'],$row['error_text'],nexa_now(),$row['id'],$userId]);
        }
    }
    $report=$row?json_decode((string)$row['report_json'],true):null;
    return ['status'=>$row['status']??'not_requested','jobId'=>$row['id']??null,
        'startedAt'=>$row['created_at']??null,'updatedAt'=>$row['updated_at']??null,
        'error'=>$row['error_text']??'',
        'summary'=>is_array($report)?['filesVerified'=>$report['filesVerified']??0,'symbolsVerified'=>$report['symbolsVerified']??0,
          'skipped'=>$report['skipped']??0,'expectedEligibleFiles'=>$report['expectedEligibleFiles']??0,
          'completeCoverage'=>$report['completeCoverage']??false,'limitations'=>$report['limitations']??[]]:null];
}
function nd03a_start(PDO $pdo,int $userId,string $projectId):array {
    $workers=nd03a_worker_rows($pdo);
    if(!$workers)throw new RuntimeException('No se envio orden: aun no hay Worker Aider en la cola exclusiva.');
    $project=nxp_project($projectId,$userId);
    $root=nd03a_root((string)($project['local_root']??''));
    // Atomic job creation: rapid double-clicks must not queue duplicate scans.
    $pdo->exec('BEGIN IMMEDIATE');
    try{
        $last=nd03a_jobs($pdo,$userId,$projectId);
        if($last && in_array($last['status'],['queued','running'],true)){
            $pdo->exec('COMMIT');return nd03a_status($pdo,$userId,$projectId);
        }
        $id='nda_'.nexa_uuid();$now=nexa_now();$worker=$workers[0]['worker_id'];
        // No arbitrary executable, shell command, script text, or model selection from the Web.
        $stmt=$pdo->prepare('INSERT INTO nd03_aider_jobs_v2(id,user_id,project_id,worker_id,local_root,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)');
        $stmt->execute([$id,$userId,$projectId,$worker,$root,'queued',$now,$now]);
        $pdo->exec('COMMIT');
        return ['status'=>'queued','jobId'=>$id,'message'=>'Orden de solo analisis reservada al Worker Aider compatible.'];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->exec('ROLLBACK');throw $e;}
}
function nd03a_worker_poll(PDO $pdo,string $workerId):array {
    nd03a_schema($pdo);$id=nd03a_worker_id(strtolower($workerId));
    $cut=gmdate('c',time()-180);$known=$pdo->prepare('SELECT 1 FROM nd03_aider_workers_v2 WHERE worker_id=? AND available=1 AND protocol=? AND analysis_only=1 AND root_bound=1 AND last_seen>=?');
    $known->execute([$id,ND03A_PROTOCOL,$cut]);if(!$known->fetchColumn())throw new RuntimeException('Worker sin registro Aider reciente.');
    $pdo->exec('BEGIN IMMEDIATE');
    try{
        $s=$pdo->prepare('SELECT * FROM nd03_aider_jobs_v2 WHERE worker_id=? AND status="queued" ORDER BY created_at,id LIMIT 1');
        $s->execute([$id]);$row=$s->fetch(PDO::FETCH_ASSOC);
        if(!$row){$pdo->exec('COMMIT');return ['ok'=>true,'job'=>null];}
        $now=nexa_now();$s=$pdo->prepare('UPDATE nd03_aider_jobs_v2 SET status="running",updated_at=? WHERE id=? AND status="queued" AND worker_id=?');
        $s->execute([$now,$row['id'],$id]);
        if($s->rowCount()!==1){$pdo->exec('ROLLBACK');return ['ok'=>true,'job'=>null];}
        $pdo->exec('COMMIT');
        return ['ok'=>true,'job'=>['id'=>$row['id'],'type'=>ND03A_QUEUE_TYPE,'payload'=>[
            'protocol'=>ND03A_PROTOCOL,'root'=>$row['local_root'],'analysisOnly'=>true,
            'maxFiles'=>ND03A_MAX_FILES,'maxSymbolsPerFile'=>ND03A_MAX_SYMBOLS,
            'includeFileSha256'=>true,'includeSourceCode'=>false,'allowEdits'=>false]]];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->exec('ROLLBACK');throw $e;}
}
/** Dedicated endpoint accepts results ONLY from the assigned Worker. */
function nd03a_worker_complete(PDO $pdo,string $workerId,array $payload):array {
    nd03a_schema($pdo);$workerId=nd03a_worker_id(strtolower($workerId));
    $jobId=(string)($payload['jobId']??'');if(!preg_match('/^nda_[a-f0-9]{32}$/D',$jobId))throw new RuntimeException('Job Aider invalido.');
    $s=$pdo->prepare('SELECT * FROM nd03_aider_jobs_v2 WHERE id=? AND worker_id=? AND status="running"');
    $s->execute([$jobId,$workerId]);$row=$s->fetch(PDO::FETCH_ASSOC);
    if(!$row)throw new RuntimeException('Job no asignado a este Worker o ya completado.');
    $status=(string)($payload['status']??'error');$error='';$report='';
    if($status==='done'){
        try{
            $result=$payload['result']??null;
            if(!is_array($result)||strlen((string)json_encode($result))>ND03A_MAX_BYTES)throw new RuntimeException('Respuesta Aider ausente o demasiado grande.');
            $validated=nd03a_validate_report($row['project_id'],$row['local_root'],$result);
            $report=(string)json_encode($validated,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
            $status=($validated['completeCoverage']??false)===true?'done':'review_required';
            if($status==='review_required')$error='Analisis Aider parcial: no todos los archivos elegibles coinciden por SHA con Hostinger. Revisar versiones o paginacion.';
        }catch(Throwable $e){$status='error';$error=substr('Informe rechazado: '.$e->getMessage(),0,400);}
    }else{$status='error';$error=substr((string)($payload['error']??'El Worker no completo el analisis.'),0,400);}
    $s=$pdo->prepare('UPDATE nd03_aider_jobs_v2 SET status=?,report_json=?,error_text=?,updated_at=? WHERE id=? AND worker_id=? AND status="running"');
    $s->execute([$status,$report,$error,nexa_now(),$jobId,$workerId]);
    return ['ok'=>true,'accepted'=>$s->rowCount()===1,'status'=>$status,'filesVerified'=>$validated['filesVerified']??0];
}
function nd03a_safe_file(string $projectId,string $rel):?string {
    if($rel===''||strlen($rel)>500||str_contains($rel,'\\')||str_contains($rel,"\0")||str_starts_with($rel,'/'))return null;
    foreach(explode('/',$rel) as $part)if($part===''||$part==='.'||$part==='..')return null;
    if(!in_array(strtolower(pathinfo($rel,PATHINFO_EXTENSION)),ND03_EXTS,true))return null;
    $root=realpath(nxp_workspace_dir($projectId));$file=nxp_path($projectId,$rel);
    if($root===false||!is_file($file)||is_link($file))return null;
    $actual=realpath($file);
    if($actual===false||!str_starts_with($actual,$root.DIRECTORY_SEPARATOR))return null;
    if(filesize($actual)===false||filesize($actual)>ND03_MAX_SOURCE)return null;
    return $actual;
}
/** Accept only symbols that match the *current* imported project source SHA. */
function nd03a_validate_report(string $projectId,string $expectedRoot,$response):array {
    if(!is_array($response) || ($response['ok']??false)!==true
       ||($response['protocol']??'')!==ND03A_PROTOCOL ||($response['analysisOnly']??false)!==true)
        throw new RuntimeException('Protocolo de análisis no verificado.');
    if(nd03a_normal_root((string)($response['root']??''))!==nd03a_normal_root($expectedRoot))
        throw new RuntimeException('El informe pertenece a otra carpeta Windows.');
    if(!is_array($response['files']??null)||count($response['files'])>ND03A_MAX_FILES)
        throw new RuntimeException('Cantidad de archivos no permitida.');
    $out=[];$skipped=0;$names=[];$total=0;
    foreach($response['files'] as $file){
        if(!is_array($file)){$skipped++;continue;}
        $rel=(string)($file['path']??'');$sha=strtolower((string)($file['sha256']??''));
        $actual=nd03a_safe_file($projectId,$rel);
        if($actual===null || isset($names[$rel]) || !preg_match('/^[a-f0-9]{64}$/D',$sha)
          ||hash_file('sha256',$actual)!==$sha){$skipped++;continue;}
        $names[$rel]=true;$symbols=[];$seenSymbols=[];
        $lineCount=substr_count((string)file_get_contents($actual),"\n")+1;
        foreach(array_slice(is_array($file['symbols']??null)?$file['symbols']:[],0,ND03A_MAX_SYMBOLS) as $tag){
            if(!is_array($tag))continue;
            $type=(string)($tag['type']??'');
            if(!in_array($type,['class','interface','trait','enum','function','method','arrow-function'],true))continue;
            $name=(string)($tag['name']??'');$line=(int)($tag['startLine']??0);$end=(int)($tag['endLine']??0);
            if(strlen($name)<1||strlen($name)>180||!preg_match('/^[\p{L}_$][\p{L}\p{N}_$]*$/uD',$name)||$line<1||$line>$lineCount||$end<$line||$end>$lineCount)continue;
            $key=$type.'|'.$name.'|'.$line;if(isset($seenSymbols[$key]))continue;$seenSymbols[$key]=true;
            $qualified=substr((string)($tag['qualifiedName']??$name),0,250);
            $container=substr((string)($tag['container']??''),0,180);
            $signature=substr(trim(preg_replace('/\s+/u',' ',(string)($tag['signature']??''))??''),0,350);
            $symbols[]=['path'=>$rel,'language'=>strtolower(pathinfo($rel,PATHINFO_EXTENSION))==='php'?'php':'js',
                'type'=>$type,'name'=>$name,'qualifiedName'=>$qualified,'container'=>$container,
                'startLine'=>$line,'endLine'=>$end,'signature'=>$signature,
                'source'=>'aider-tree-sitter','confidence'=>'structural','referenceCandidates'=>[],
                'sha256'=>$sha,'verifiedAgainstWebSha'=>true];
        }
        $total+=count($symbols);$out[$rel]=['sha256'=>$sha,'symbols'=>$symbols];
    }
    // A successful batch is not the same as full project coverage.
    $expected=0;foreach(nxp_walk($projectId) as $entry){
        if(in_array(strtolower(pathinfo($entry['path'],PATHINFO_EXTENSION)),ND03_EXTS,true)
           &&(int)$entry['size']<=ND03_MAX_SOURCE)$expected++;
    }
    return ['protocol'=>ND03A_PROTOCOL,'root'=>$expectedRoot,
       'expectedEligibleFiles'=>$expected,'completeCoverage'=>$expected>0 && count($out)===$expected,
       'filesVerified'=>count($out),
       'symbolsVerified'=>$total,'skipped'=>$skipped,'files'=>$out,
       'limitations'=>['SHA-256 proves byte equality, not that dynamic symbol references are resolved.',
         'No project files were executed or modified by the Web analyzer.']];
}
function nd03a_valid_cached(string $projectId,int $userId):array {
    $pdo=nd_db();$row=nd03a_jobs($pdo,$userId,$projectId);
    if(!$row||$row['status']!=='done')return [];
    $project=nxp_project($projectId,$userId);
    if(nd03a_normal_root((string)($project['local_root']??''))!==nd03a_normal_root((string)$row['local_root']))return [];
    $report=json_decode((string)$row['report_json'],true);
    return is_array($report)&&($report['protocol']??'')===ND03A_PROTOCOL?($report['files']??[]):[];
}
/** Keep existing Web results; add Aider tags only for verified matching source hashes. */
function nd03a_merge(string $projectId,int $userId,array $analysis):array {
    $cached=nd03a_valid_cached($projectId,$userId);$augmented=0;$matched=0;
    foreach($analysis['files'] as &$file){
        $rel=(string)$file['path'];$extra=$cached[$rel]??null;
        if(!is_array($extra)||($extra['sha256']??'')!==($file['sha256']??''))continue;
        foreach($extra['symbols'] as $sym){
            $found=false;
            foreach($file['symbols'] as &$old){
                if($old['type']===$sym['type'] && $old['name']===$sym['name']
                  && abs((int)$old['startLine']-(int)$sym['startLine'])<=2){
                    $old['sources']=array_values(array_unique(array_merge($old['sources']??[$old['source']],['aider-tree-sitter'])));
                    $old['aiderVerifiedSha256']=true;$found=true;$matched++;break;
                }
            }unset($old);
            if(!$found){$file['symbols'][]=$sym;$augmented++;}
        }
        $file['symbolCount']=count($file['symbols']);
    }unset($file);
    $analysis['aiderConnected']=($augmented+$matched)>0;
    $analysis['aiderMerge']=['matchedSymbols'=>$matched,'addedSymbols'=>$augmented,'verifiedOnly'=>true];
    return $analysis;
}
function nd03a_context(array $r):string {
    if(($r['state']['mode']??'web-isolated')!=='web-isolated')return '';
    $projectId=(string)($r['project_id']??'');$uid=(int)($r['user_id']??0);
    if($projectId===''||$uid<1)return '';
    $files=nd03a_valid_cached($projectId,$uid);if(!$files)return '';
    $text=strtolower((string)($r['request']??''));$manifest=nd_manifest((string)$r['id']);$hits=[];
    foreach($files as $path=>$entry){
        if(($manifest[$path]['sha256']??'')!==($entry['sha256']??''))continue;
        foreach($entry['symbols'] as $s){
            $name=strtolower((string)$s['name']);if(strlen($name)<4||!str_contains($text,$name))continue;
            $hits[]=['path'=>$path,'name'=>$s['qualifiedName'],'kind'=>$s['type'],'line'=>$s['startLine'],'sha256'=>$entry['sha256']];
            if(count($hits)>=8)break 2;
        }
    }
    return $hits?"\nSIMBOLOS AIDER (Tree-sitter; SHA coincide con copia de trabajo, leer antes de editar; referencias dinámicas NO resueltas): ".json_encode($hits,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE):'';
}
