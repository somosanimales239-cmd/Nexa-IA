<?php
declare(strict_types=1);
/**
 * PRIVATE, AGENT-TOKEN AUTHENTICATED Developer-only poll endpoint.
 * Does not read or claim api/agent/next.php jobs (Chat, Images, Qwen).
 * Intended for the future single consolidated Nexa Windows Aider bridge.
 * Supported POST actions: hello, next, complete.
 */
require_once dirname(__DIR__).'/api/web/project-lib.php';
require_once __DIR__.'/symbols-v03.php';
require_once __DIR__.'/aider-v03.php';
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if(($_SERVER['REQUEST_METHOD']??'')!=='POST')nexa_json(['ok'=>false,'error'=>'POST requerido'],405);
nexa_require_agent();
$body=nexa_read_json();
try{
    $pdo=nexa_db();
    $action=(string)($body['action']??'');
    $result=match($action){
        'hello'=>nd03a_worker_hello($pdo,$body),
        'next'=>nd03a_worker_poll($pdo,(string)($body['workerId']??'')),
        'complete'=>nd03a_worker_complete($pdo,(string)($body['workerId']??''),$body),
        default=>throw new RuntimeException('Operacion Aider no autorizada.')
    };
    nexa_json($result);
}catch(Throwable $e){
    nexa_json(['ok'=>false,'error'=>substr($e->getMessage(),0,400)],400);
}
