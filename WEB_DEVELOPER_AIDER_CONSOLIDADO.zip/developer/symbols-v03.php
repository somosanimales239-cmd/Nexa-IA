<?php
declare(strict_types=1);
/**
 * Developer-only, read-only Symbol Intelligence 03.
 * PHP definitions use the native PHP lexer. JS/TS definitions are conservative
 * lexical candidates; they are not presented as an AST or definitive LSP links.
 * Future Aider/Tree-sitter results can be merged by path + symbol + location.
 * Does not execute imported source, call Ollama, or touch Chat/Image Studio.
 */
const ND03_VERSION = 'web-symbols-03.1';
const ND03_MAX_SOURCE = 450000;
const ND03_EXTS = ['php','js','cjs','mjs','jsx','ts','tsx'];
function nd03_lower(string $s):string{return function_exists('mb_strtolower')?mb_strtolower($s):strtolower($s);}
function nd03_length(string $s):int{return function_exists('mb_strlen')?mb_strlen($s):strlen($s);}
function nd03_shorten(string $s,int $n):string{return function_exists('mb_substr')?mb_substr($s,0,$n):substr($s,0,$n);}
function nd03_line(string $source,int $offset):int {return substr_count($source,"\n",0,max(0,$offset))+1;}
function nd03_symbol(string $path,string $language,string $type,string $name,int $start,int $end,string $signature='',string $container='',string $qualified='',string $confidence='structural'):array {
    return ['path'=>$path,'language'=>$language,'type'=>$type,'name'=>$name,'qualifiedName'=>$qualified!==''?$qualified:($container!==''?$container.'::'.$name:$name),
      'container'=>$container,'startLine'=>max(1,$start),'endLine'=>max($start,$end),'signature'=>nd03_shorten(preg_replace('/\s+/u',' ',$signature)??$signature,350),
      'source'=>$language==='php'?'php-tokenizer':'web-js-lexer','confidence'=>$confidence,'referenceCandidates'=>[]];
}
function nd03_php_tokens(string $source):array {
    $out=[];$line=1;
    foreach(token_get_all($source) as $raw){$text=is_array($raw)?$raw[1]:$raw;$id=is_array($raw)?$raw[0]:0;
        $out[]=['id'=>$id,'text'=>$text,'line'=>$line];$line+=substr_count($text,"\n");}
    return $out;
}
function nd03_php_sig(array $t,int $i,int $direction=1):int {
    $n=count($t);
    while($i>=0&&$i<$n&&in_array($t[$i]['id'],[T_WHITESPACE,T_COMMENT,T_DOC_COMMENT],true))$i+=$direction;
    return $i;
}
function nd03_php_pairs(array $t,string $open='{',string $close='}'):array {
    $st=[];$links=[];
    foreach($t as $i=>$v){if($v['id']!==0)continue;
        if($v['text']===$open)$st[]=$i;
        elseif($v['text']===$close&&$st){$a=array_pop($st);$links[$a]=$i;}}
    return $links;
}
function nd03_php_definitions(string $source,string $path):array {
    $t=nd03_php_tokens($source);$n=count($t);$braces=nd03_php_pairs($t);$parens=nd03_php_pairs($t,'(',')');
    $symbols=[];$namespace='';$classes=[];$functions=[];$anonymous=[];
    for($i=0;$i<$n;$i++){
        $id=$t[$i]['id'];
        if($id===T_NAMESPACE){$namespace='';for($j=nd03_php_sig($t,$i+1);$j<$n;$j++){
            if(in_array($t[$j]['text'],[';','{'],true))break;
            if(!in_array($t[$j]['id'],[T_WHITESPACE,T_COMMENT,T_DOC_COMMENT],true))$namespace.=$t[$j]['text'];}
            $namespace=trim($namespace,'\\');continue;
        }
        if(in_array($id,[T_CLASS,T_INTERFACE,T_TRAIT,defined('T_ENUM')?constant('T_ENUM'):-100],true)){
            $j=nd03_php_sig($t,$i+1);
            if($j>=$n||$t[$j]['id']!==T_STRING){
                if($id===T_CLASS){for($k=$j;$k<$n&&$k<$j+200;$k++){
                    if($t[$k]['text']==='{'){if(isset($braces[$k]))$anonymous[]=[$k,$braces[$k]];break;}
                    if($t[$k]['text']===';')break;
                }}
                continue; // anonymous class, ::class
            }
            $name=$t[$j]['text'];$open=null;$inherit='';
            for($k=$j+1;$k<$n&&$k<$j+200;$k++){
                if($t[$k]['text']==='{'){$open=$k;break;}
                if($t[$k]['text']===';')break;
                $inherit.=$t[$k]['text'];
            }
            if($open===null||!isset($braces[$open]))continue;
            $type=$id===T_INTERFACE?'interface':($id===T_TRAIT?'trait':(defined('T_ENUM')&&$id===T_ENUM?'enum':'class'));
            $full=($namespace!==''?$namespace.'\\':'').$name;
            $symbols[]=nd03_symbol($path,'php',$type,$name,$t[$i]['line'],$t[$braces[$open]]['line'],trim($type.' '.$full.' '.$inherit),'',$full);
            $classes[]=['start'=>$open,'end'=>$braces[$open],'name'=>$full];continue;
        }
        if($id!==T_FUNCTION)continue;
        $j=nd03_php_sig($t,$i+1);if(($t[$j]['text']??'')==='&')$j=nd03_php_sig($t,$j+1);
        if(($t[$j]['id']??0)!==T_STRING)continue; // closure
        $insideAnonymous=false;foreach($anonymous as $range)if($i>$range[0]&&$i<$range[1]){$insideAnonymous=true;break;}
        if($insideAnonymous)continue; // Unnamed owner: do not falsely report a global function.
        $name=$t[$j]['text'];$open=nd03_php_sig($t,$j+1);
        if(($t[$open]['text']??'')!=='('||!isset($parens[$open]))continue;
        $paramEnd=$parens[$open];$head='';
        for($k=$open;$k<=$paramEnd;$k++)$head.=$t[$k]['text'];
        $bodyStart=null;$end=$paramEnd;
        for($k=$paramEnd+1;$k<$n&&$k<$paramEnd+200;$k++){
            if($t[$k]['text']==='{'){$bodyStart=$k;$end=$braces[$k]??$k;break;}
            if($t[$k]['text']===';'){$end=$k;break;}
        }
        $container='';$nearest=-1;
        foreach($classes as $c)if($i>$c['start']&&$i<$c['end']&&$c['start']>$nearest){$container=$c['name'];$nearest=$c['start'];}
        foreach($functions as $fn)if($i>$fn[0]&&$i<$fn[1]&&$fn[0]>$nearest)$container='';
        $kind=$container!==''?'method':'function';$qualified=$container!==''?$container.'::'.$name:(($namespace!==''?$namespace.'\\':'').$name);
        $symbols[]=nd03_symbol($path,'php',$kind,$name,$t[$i]['line'],$t[$end]['line'],$name.$head,$container,$qualified);
        if($bodyStart!==null)$functions[]=[$bodyStart,$end];
    }
    return $symbols;
}
/** Mask comments, strings and regexp literals, preserving source offsets/newlines. */
function nd03_js_mask(string $s):string {
    $out=$s;$n=strlen($s);$state='code';$escape=false;$last='';
    for($i=0;$i<$n;$i++){
        $ch=$s[$i];$next=$i+1<$n?$s[$i+1]:'';
        if($state==='line'){if($ch==="\n"){$state='code';}else$out[$i]=' ';continue;}
        if($state==='block'){if($ch==='*'&&$next==='/'){$out[$i]=$out[$i+1]=' ';$i++;$state='code';}elseif($ch!=="\n")$out[$i]=' ';continue;}
        if(in_array($state,['single','double','template','regex'],true)){
            if($ch==='\\'&&!$escape){$escape=true;if($ch!=="\n")$out[$i]=' ';continue;}
            $terminal=($state==='single'&&$ch==="'")||($state==='double'&&$ch==='"')||($state==='template'&&$ch==='`')||($state==='regex'&&$ch==='/');
            if($ch!=="\n")$out[$i]=' ';if($terminal&&!$escape)$state='code';$escape=false;continue;
        }
        if($ch==='/'&&$next==='/'){$out[$i]=$out[$i+1]=' ';$i++;$state='line';continue;}
        if($ch==='/'&&$next==='*'){$out[$i]=$out[$i+1]=' ';$i++;$state='block';continue;}
        if($ch==="'"||$ch==='"'||$ch==='`'){$out[$i]=' ';$state=$ch==="'"?'single':($ch==='"'?'double':'template');continue;}
        // Regex detection is conservative: division ambiguity may remain in JS.
        if($ch==='/'&&preg_match('/[=(,:!\[\{;?]/',$last)){$out[$i]=' ';$state='regex';continue;}
        if(!ctype_space($ch))$last=$ch;
    }
    return $out;
}
function nd03_js_brace_pairs(string $masked):array {
    $stack=[];$pairs=[];$depth=0;$levels=[];$n=strlen($masked);
    for($i=0;$i<$n;$i++){$c=$masked[$i];
        if($c==='{'){$levels[$i]=$depth;$stack[]=$i;$depth++;}
        elseif($c==='}'){$depth=max(0,$depth-1);if($stack){$open=array_pop($stack);$pairs[$open]=$i;}}
    }
    return [$pairs,$levels];
}
function nd03_js_definitions(string $source,string $path):array {
    $mask=nd03_js_mask($source);[$pairs,$levels]=nd03_js_brace_pairs($mask);$symbols=[];$classes=[];
    $lang=pathinfo($path,PATHINFO_EXTENSION);
    if(preg_match_all('/\bclass\s+([A-Za-z_$][\w$]*)\b([^\{;]{0,300})\{/',$mask,$m,PREG_OFFSET_CAPTURE)){
        foreach($m[0] as $i=>$hit){$at=$hit[1];$brace=$at+strlen($hit[0])-1;
            if(!isset($pairs[$brace]))continue;
            $name=$m[1][$i][0];$classes[]=['name'=>$name,'start'=>$brace,'end'=>$pairs[$brace],'level'=>$levels[$brace]??0];
            $symbols[]=nd03_symbol($path,'js','class',$name,nd03_line($source,$at),nd03_line($source,$pairs[$brace]),'class '.$name,'',$name,'lexical');}
    }
    if(preg_match_all('/\b(?:async\s+)?function\s*\*?\s+([A-Za-z_$][\w$]*)\s*\(/',$mask,$m,PREG_OFFSET_CAPTURE)){
        foreach($m[0] as $i=>$hit){$at=$hit[1];$name=$m[1][$i][0];$paren=$at+strlen($hit[0])-1;
            $body=nd03_js_body($mask,$paren,$pairs);$symbols[]=nd03_symbol($path,'js','function',$name,nd03_line($source,$at),nd03_line($source,$body),trim(substr($source,$at,min(260,strlen($hit[0])+100))),'',$name,'lexical');}
    }
    // Function expressions assigned to a stable identifier (arrow syntax).
    if(preg_match_all('/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^;{}]{0,180}\)|[A-Za-z_$][\w$]*)\s*=>/',$mask,$m,PREG_OFFSET_CAPTURE)){
        foreach($m[0] as $i=>$hit){$at=$hit[1];$name=$m[1][$i][0];$body=nd03_js_body($mask,$at+strlen($hit[0]),$pairs);
            $symbols[]=nd03_symbol($path,'js','arrow-function',$name,nd03_line($source,$at),nd03_line($source,$body),trim(substr($source,$at,min(strlen($hit[0]),260))),'',$name,'lexical');}
    }
    // Only direct members of the detected class body: not a nested function call.
    foreach($classes as $c){$body=substr($mask,$c['start']+1,$c['end']-$c['start']-1);
        if(!preg_match_all('/(?:^|[;{}\n])\s*(?:(?:public|private|protected|readonly|static|async|override|abstract|declare|get|set)\s+)*\*?\s*([A-Za-z_$][\w$]*)\s*\([^;{}]{0,300}\)\s*(?::\s*[^{};\n]{1,140})?\s*\{/m',$body,$mm,PREG_OFFSET_CAPTURE))continue;
        foreach($mm[0] as $i=>$hit){$at=$c['start']+1+$hit[1];$open=$at+strlen($hit[0])-1;
            if(($levels[$open]??-1)!==$c['level']+1||!isset($pairs[$open]))continue;
            $name=$mm[1][$i][0];$declaration=ltrim($hit[0]," \t\r\n;{}");$begin=$at+strlen($hit[0])-strlen($declaration);
            $symbols[]=nd03_symbol($path,'js','method',$name,nd03_line($source,$begin),nd03_line($source,$pairs[$open]),trim(substr($source,$begin,min(260,$open-$begin+1))),$c['name'],$c['name'].'.'.$name,'lexical');}
    }
    usort($symbols,static fn($a,$b)=>($a['startLine']<=>$b['startLine'])?:strcmp($a['qualifiedName'],$b['qualifiedName']));
    return $symbols;
}
function nd03_js_body(string $mask,int $from,array $pairs):int {
    $p=strpos($mask,'{',$from);$semi=strpos($mask,';',$from);
    if($p!==false&&($semi===false||$p<$semi)&&$p-$from<500&&isset($pairs[$p]))return $pairs[$p];
    return min(strlen($mask),$semi===false?$from:$semi);
}
/** Candidates are intentionally non-authoritative, never 'resolved' references. */
function nd03_reference_candidates(string $source,array &$symbols):void {
    if(!$symbols)return;
    $language=$symbols[0]['language'];$masked=$language==='php'?$source:nd03_js_mask($source);
    if($language==='php'){
        $t=nd03_php_tokens($source);$occ=[];
        foreach($t as $i=>$token){if($token['id']!==T_STRING)continue;$j=nd03_php_sig($t,$i+1);
            if(($t[$j]['text']??'')!=='(')continue;$before=nd03_php_sig($t,$i-1,-1);
            if(in_array($t[$before]['id']??0,[T_FUNCTION,T_NEW],true))continue;
            $kind=in_array($t[$before]['id']??0,[T_OBJECT_OPERATOR,T_NULLSAFE_OBJECT_OPERATOR,T_DOUBLE_COLON],true)?'method-call':'call';
            $occ[$token['text']][]=[$token['line'],$kind];
        }
    }else{
        $occ=[];if(preg_match_all('/\b([A-Za-z_$][\w$]*)\s*\(/',$masked,$m,PREG_OFFSET_CAPTURE))foreach($m[1] as $hit){$occ[$hit[0]][]=[nd03_line($source,$hit[1]),'call'];}
    }
    foreach($symbols as &$sym){foreach(($occ[$sym['name']]??[]) as [$line,$kind]){
            if($line===$sym['startLine'])continue;
            if(count($sym['referenceCandidates'])>=25)break;
            $sym['referenceCandidates'][]=['path'=>$sym['path'],'line'=>$line,'kind'=>$kind,'resolved'=>false];
        }
    }unset($sym);
}
function nd03_analyze_source(string $path,string $source):array {
    $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));if(!in_array($ext,ND03_EXTS,true))return ['path'=>$path,'status'=>'unsupported','symbols'=>[]];
    if(strlen($source)>ND03_MAX_SOURCE)return ['path'=>$path,'status'=>'too_large','size'=>strlen($source),'symbols'=>[]];
    $symbols=$ext==='php'?nd03_php_definitions($source,$path):nd03_js_definitions($source,$path);
    nd03_reference_candidates($source,$symbols);
    return ['path'=>$path,'status'=>'analyzed','sha256'=>hash('sha256',$source),'symbols'=>$symbols,'symbolCount'=>count($symbols),
        'limitations'=>['referenceCandidates are same-file lexical hints, NOT resolved cross-file references',
          'JS/TS analyzer is lexical; Aider Tree-sitter bridge not connected']];
}
/** Paginated, admin-authenticated caller must validate ownership before invocation. */
function nd03_project_page(string $projectId,int $offset=0,int $limit=20,string $filter=''):array {
    $rows=array_values(array_filter(nxp_walk($projectId),static function(array $x):bool {
        return in_array(strtolower(pathinfo($x['path'],PATHINFO_EXTENSION)),ND03_EXTS,true);
    }));
    $offset=max(0,min(count($rows),$offset));$limit=max(1,min(40,$limit));
    $selected=array_slice($rows,$offset,$limit);$workspace=realpath(nxp_workspace_dir($projectId));$out=[];$read=0;$symbols=0;$skipped=[];$needle=nd03_lower(trim($filter));
    foreach($selected as $entry){$path=$entry['path'];$file=nxp_path($projectId,$path);
        if(!$workspace||!is_string($real=realpath($file))||!str_starts_with($real,$workspace.DIRECTORY_SEPARATOR)||is_link($file)||!is_file($file)||$entry['size']>ND03_MAX_SOURCE){$skipped[]=$path;continue;}
        $source=file_get_contents($file);if(!is_string($source)||strlen($source)>ND03_MAX_SOURCE){$skipped[]=$path;continue;}
        $result=nd03_analyze_source($path,$source);$read++;
        if($needle!=='')$result['symbols']=array_values(array_filter($result['symbols'],static fn($s)=>str_contains(nd03_lower($s['qualifiedName']),$needle)||str_contains(nd03_lower($s['path']),$needle)));
        $symbols+=count($result['symbols']);if($result['symbols'])$out[]=$result;
    }
    return ['version'=>ND03_VERSION,'engine'=>'Nexa PHP tokenizer + JS lexical scanner','aiderConnected'=>false,'readOnly'=>true,
      'totalEligibleFiles'=>count($rows),'offset'=>$offset,'scannedFiles'=>$read,'matchedSymbols'=>$symbols,
      'nextOffset'=>$offset+count($selected)<count($rows)?$offset+count($selected):null,'files'=>$out,'skipped'=>$skipped];
}
/** Bounded, relevance-ranked definitions for Qwen. Never executes project code. */
function nd03_context(array $run):string {
    if(($run['state']['mode']??'web-isolated')!=='web-isolated')return '';
    $request=nd03_lower((string)($run['request']??''));
    $words=preg_split('/[^\p{L}\p{N}_]+/u',$request,-1,PREG_SPLIT_NO_EMPTY)?:[];
    $stop=['para','como','este','esta','agrega','agregar','hacer','debe','tiene','funcion','funciones','archivo','archivos','proyecto','sistema','quiero','necesito','detecta','clase','clases','metodo','metodos','codigo','javascript','php','with','from','the','and','que','los','las'];
    $terms=array_values(array_filter(array_unique($words),static fn($word)=>nd03_length($word)>3&&!in_array($word,$stop,true)));
    if(!$terms)return '';
    $manifest=nd_manifest((string)$run['id']);$candidates=[];$seen=0;
    foreach($manifest as $path=>$meta){
        if($seen>=30)break;
        if(!in_array(strtolower(pathinfo($path,PATHINFO_EXTENSION)),ND03_EXTS,true)||(int)$meta['size']>150000)continue;
        $seen++;try{$file=nd_file((string)$run['id'],$path,true);}catch(Throwable $e){continue;}
        $source=file_get_contents($file);if(!is_string($source))continue;
        $fileScore=0;$hasSourceTerm=false;
        foreach($terms as $term){if(str_contains(nd03_lower($path),$term))$fileScore+=3;if(stripos($source,$term)!==false)$hasSourceTerm=true;}
        if(!$hasSourceTerm&&$fileScore===0)continue;
        $result=nd03_analyze_source($path,$source);$fileMatches=0;
        foreach($result['symbols'] as $symbol){
            $name=nd03_lower($symbol['qualifiedName']);$score=0;
            foreach($terms as $term){if($name===$term)$score+=30;elseif(str_contains($name,$term))$score+=14;}
            if($score===0&&$fileScore>0&&$fileMatches<3){$score=$fileScore;$fileMatches++;}
            if($score===0)continue;
            $candidates[]=['score'=>$score,'path'=>$path,'name'=>$symbol['qualifiedName'],'type'=>$symbol['type'],'line'=>$symbol['startLine'],'confidence'=>$symbol['confidence']];
        }
    }
    if(!$candidates)return '';
    usort($candidates,static fn($a,$b)=>($b['score']<=>$a['score'])?:strcmp($a['path'],$b['path']));
    $selected=array_map(static function($row){unset($row['score']);return $row;},array_slice($candidates,0,15));
    return "\nSIMBOLOS RELACIONADOS (detector web; referencias no verificadas; leer antes de editar): ".json_encode($selected,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES);
}
