'use strict';
(() => {
 const $=id=>document.getElementById(id), esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const csrf=document.querySelector('meta[name="nexa-csrf"]').content;
 const state={config:null,run:null,eventsAfter:0,busy:false,polling:false,projects:[],lastTick:0,lastPoll:0,planEditorRevision:null,planEditorRun:null,planEditorDirty:false,limitRuns:[]};
 const chat16={threadId:'',detail:null,busy:false,probeJob:'',lastRefresh:0};
 function parseCriteria(){const raw=$('acceptanceCriteria').value.trim();if(!raw)return [];let x;try{x=JSON.parse(raw)}catch(e){throw Error('Criterios JSON inválidos: '+e.message)}if(!Array.isArray(x))throw Error('Las pruebas deben ser una lista JSON');return x}
 const api=async (method,action,data={})=>{
   const url='api.php'+(method==='GET'?'?'+new URLSearchParams({action,...data}):'');
   const res=await fetch(url,method==='GET'?{credentials:'same-origin',cache:'no-store'}:{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({...data,action})});
   const text=await res.text();let result;try{result=JSON.parse(text)}catch(_){throw Error('Respuesta inesperada del servidor (HTTP '+res.status+'): '+text.slice(0,180))}
   if(!res.ok||!result.ok)throw Error(result.error||('HTTP '+res.status));return result;
 };
 const flash=(m,bad=false)=>{const n=$('toast');n.textContent=m;n.className='toast show'+(bad?' bad':'');setTimeout(()=>{if(n.textContent===m)n.classList.remove('show')},7000)};
 const key=(o,p)=>p.split('.').reduce((v,k)=>v?.[k],o);
 const put=(o,p,value)=>{const k=p.split('.');let s=o;while(k.length>1){const v=k.shift();s[v]??={};s=s[v]}s[k[0]]=value};
 function fieldValue(el){if(el.type==='checkbox')return el.checked;if(el.type==='number')return Number(el.value);return el.value}
 function bindControls(){
   if(!state.config)return;
   $('modeStatus').textContent='Hostinger · ZIP importado';
   const opts={tools:{files:'Archivos del laboratorio web',search:'Búsqueda de código web',terminal:'Terminal de pruebas Hostinger',git:'Git en laboratorio Hostinger',gitNetwork:'Git remoto GitHub (publicar solo con aprobación manual)',browser:'Navegador de staging web',sqlite:'SQLite de ensayo Hostinger'},
   planning:{enabled:'Habilitar planificador',requireAcceptance:'Requerir criterios de aceptación'},memory:{enabled:'Guardar historial',checkpoints:'Guardar checkpoints'},
   editing:{duplicateGuard:'Prevenir duplicados',requireRead:'Leer antes de editar',rollback:'Reversión de edición inválida'},
   qa:{php:'Análisis PHP',javascript:'Node.js / JavaScript',json:'JSON',sqlite:'SQLite',browser:'Navegador',functional:'Pruebas funcionales',required:'Requerir QA'},
   repair:{rollback:'Reversión',stopRepeated:'Detener repeticiones',pauseOnFailure:'Pausar ante fallos repetidos'},
   evaluation:{requireSyntax:'Requerir sintaxis',requireEvidence:'Exigir evidencia',independent:'Evaluador independiente'},
   delivery:{onlyChanges:'ZIP solo archivos modificados',sha256:'Hashes SHA-256',includeReport:'Informe separado'},
   tracking:{autoResume:'Recuperar ejecuciones interrumpidas (no pausas manuales)',logDetails:'Registro detallado'}};
   for(const [group,items] of Object.entries(opts)){
     const node=group==='tools'?$('toolToggles'):document.querySelector('[data-toggles="'+group+'"]');if(!node)continue;
     node.innerHTML=Object.entries(items).map(([k,label])=>`<label class="toggle"><input type="checkbox" data-cfg="${group}.${k}"><span>${esc(label)}</span></label>`).join('');
   }
   document.querySelectorAll('[data-cfg]').forEach(el=>{const v=key(state.config,el.dataset.cfg);if(el.type==='checkbox')el.checked=!!v;else el.value=v??'';});
 }
 function collectConfig(){const c=structuredClone(state.config);document.querySelectorAll('[data-cfg]').forEach(el=>put(c,el.dataset.cfg,fieldValue(el)));return c}
 const statusName=s=>({running:'Trabajando',paused:'Pausado',incomplete:'Incompleto',review_required:'Revisión pendiente',analysis_ready:'Análisis listo',cancelled:'Cancelado',blocked:'Bloqueado'})[s]||s;
 async function loadProjects(){const data=await api('GET','projects');state.projects=data.projects||[];const select=$('projectSelect');const current=select.value;
   select.innerHTML='<option value="">Selecciona un proyecto…</option>'+state.projects.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${p.count} archivos</option>`).join('');
   if(state.projects.some(p=>p.id===current))select.value=current;else if(state.projects.length)select.value=state.projects[0].id;
   syncProjectFields();
   chat16SyncProjects();
 }
 function syncProjectFields(){const p=state.projects.find(x=>x.id===$('projectSelect').value);$('pcLocalRoot').value=p?.local_root||'';$('stagingUrl').value=p?.staging_url||'';if($('aider03Root'))$('aider03Root').value=p?.local_root||'';}
 const eventType=k=>k==='error'||k==='rejected'||k==='model-error'?'bad':k==='evaluate'||k==='artifact'?'good':'';
 function showRun(run,events=[]){if(!run)return;
   if($('qa12Info')){
     if(state.qa12ShownRun!==run.id){state.qa12ShownRun=run.id;$('qa12Output').textContent='Tarea seleccionada: '+run.id+'. Detecta los casos del proyecto o ejecuta la autoprueba.';}
     $('qa12Info').textContent=run.qa12Stale?'ATENCIÓN: el proyecto cambió después de QA. La evidencia SHA anterior ya no es válida; ejecuta la suite nuevamente.':
       run.qa12Result?`QA de la revisión actual: ${run.qa12Result.passed}/${run.qa12Result.total} aprobados · ${run.qa12Result.failed} fallidos · ${run.qa12Result.pending} pendientes.`:
       'Sin QA certificado de esta revisión. Una prueba de sintaxis no equivale a una prueba funcional.';
   }
   state.run=run;
   if($('repair13Info')){
     const rp=run.repair13||null;
     $('repair13Info').textContent=rp?
       `Reparación ${rp.active?'activa':'registrada'} · Intentos ${rp.attempts||0} · ${rp.lastIssues?.length||0} fallos detectados. `+
       (rp.verifiedFingerprint?'QA verificado con huella de revisión.':'El resultado de Qwen no equivale a una prueba aprobada.'):
       'Área 9: sin ciclo de reparación registrado. Crea una tarea aislada para la autoprueba.';
   }
   if($('limitActive')){
     const t=run.limits||{};
     $('limitActive').textContent=t.activeSeconds===undefined?'—':t.activeSeconds+' s';
     $('limitRemaining').textContent=t.remainingSeconds===undefined?'—':t.remainingSeconds+' s';
     $('limitSteps').textContent=t.usedSteps===undefined?'—':t.usedSteps+' / '+t.maxSteps;
     $('limitStepsLeft').textContent=t.remainingSteps===undefined?'—':t.remainingSteps;
     // The action stays clickable, so it can explain exactly why a task is ineligible;
     // backend remains authoritative and allows only paused/incomplete tasks.
     const canUpdateLimits=['paused','incomplete'].includes(run.status);
     $('limitApplyRun').disabled=false;
     const explanation=canUpdateLimits?'Puedes aplicar límites sin reanudar esta tarea.':
       'No se pueden aplicar límites a este estado. Selecciona una tarea pausada o crea una de prueba.';
     $('limitApplyRun').title=explanation;
     const selector=$('limitTaskSelect');
     if(selector && selector.querySelector('option[value="'+run.id+'"]'))selector.value=run.id;
     if($('limitTaskInfo'))$('limitTaskInfo').textContent=`Tarea ${run.id} · Estado real: ${statusName(run.status)} (${run.status}). ${explanation} `+
       `Máximo de pasos guardado: ${run.configuredLimits?.maxSteps??run.limits?.maxSteps??'—'}. `+
       (run.waitJob?'Qwen pendiente: no se ejecutará al actualizar los límites. ':'')+
       (run.toolBatch?'Lote pendiente: no se ejecutará al actualizar los límites.':'');
   }
   $('runStatus').textContent=statusName(run.status);$('runPhase').textContent=run.phase;$('runSteps').textContent=run.steps||0;$('runFiles').textContent=Object.keys(run.changes||{}).length;
   if($('toolsStatus')){
     $('toolsStatus').textContent=run.toolBatch?`Lote ${run.toolBatch.cursor}/${run.toolBatch.total} · ${statusName(run.status)}`:run.toolLastRun?`Último lote: ${run.toolLastRun.steps.length} operaciones`:'Sin lote activo';
     if(run.toolLastRun)$('toolsOutput').textContent=JSON.stringify(run.toolLastRun,null,2);
   }
   $('pauseRun').disabled=run.status!=='running';$('resumeRun').disabled=!['paused','incomplete'].includes(run.status);$('cancelRun').disabled=!['running','paused'].includes(run.status);
   $('undoLast').disabled=run.status==='running'||!(run.checkpoints||[]).some(x=>!x.used);
   const objectives=run.objectives||[];const plan=run.planProgress||{};
   const objectiveHtml=objectives.map((o,i)=>{
     const status=o.status||'pending';const evidence=(o.evidence||[]);const good=['verified','approved_manual'].includes(status);
     return `<div class="list-row"><span class="dot ${good?'good':status==='waiting_evidence'?'pending':status==='failed'?'bad':'pending'}"></span><div><strong>${esc(o.id||String(i+1))} · ${esc(o.title)}</strong><small>Fase ${esc(o.phase||'general')} · Estado ${esc(status)} · Depende de ${esc((o.dependsOn||[]).join(', ')||'ninguno')} · Intentos ${Number(o.attempts||0)}</small><small>${esc(o.acceptance||'')} · ${evidence.filter(x=>x.status==='passed').length}/${evidence.length} criterios aprobados ${o.manualAcceptance?'· ACEPTACIÓN HUMANA, NO AUTOMÁTICA':''}</small></div></div>`;
   }).join('');
   $('objectiveList').innerHTML=objectives.length?objectiveHtml:'No hay objetivos todavía.';
   $('planGoalList').innerHTML=objectives.length?objectiveHtml:'El trabajo todavía no tiene objetivos.';
   $('planPercent').textContent=String(plan.percent??0)+'%';$('planCounts').textContent=`${plan.done||0} / ${plan.total||0}`;
   $('planActive').textContent=plan.activeId||'—';$('planRevision').textContent=String(plan.revision||0);
   if(!state.planEditorDirty && (state.planEditorRun!==run.id || state.planEditorRevision!==(plan.revision??0))){
      state.planEditorRun=run.id;state.planEditorRevision=plan.revision??0;
      $('planEditor').value=JSON.stringify({summary:run.planSummary||'',objectives:objectives.map(o=>({id:o.id,title:o.title,phase:o.phase,dependsOn:o.dependsOn||[],acceptance:o.acceptance,checks:o.checks||[],notes:o.notes||''}))},null,2);
   }
   const mayEdit=run.status==='paused'&&!run.waitJob&&!run.toolBatch;
   for(const id of ['planSave','planVerify','planManualApprove'])$(id).disabled=!mayEdit;
   if($('planLockReason')){
     $('planLockReason').textContent=mayEdit?'Tarea pausada y libre: puedes guardar y verificar objetivos.':
       run.status!=='paused'?'La tarea está '+statusName(run.status)+'. Para probar sin Qwen, crea una prueba manual abajo.':
       run.waitJob?'Esta tarea sigue esperando una solicitud de Qwen. Crea la prueba manual sin Qwen; la tarea original quedará intacta.':
       run.toolBatch?'Esta tarea tiene un lote de herramientas pendiente. Usa la prueba manual sin Qwen.':
       'Prueba manual disponible.';
   }

   const audit14=run.evaluation?.independent14||null;
   if($('eval14Summary')){
     $('eval14Summary').textContent=audit14?
       `Área 10: ${audit14.status.toUpperCase()} · ${audit14.verifiedGoals}/${audit14.totalGoals} objetivos verificados · ${audit14.failed} fallos · ${audit14.pending} pendientes · SHA ${audit14.currentFingerprint?.slice(0,16)||'—'}… · Qwen no cuenta como prueba.`:
       'Área 10: sin auditoría integral todavía. Pulsa Evaluar requisitos del proyecto.';
     if(audit14 && run.id!==state.eval14ShownRun){state.eval14ShownRun=run.id;$('eval14Output').textContent='Auditoría previa: '+JSON.stringify(audit14,null,2);}
   }
   const evaluation=run.evaluation||{};const checks=evaluation.criteria||[];
   const summary=`<div class="list-row"><strong>Verificados: ${Number(evaluation.passed)||0} · Fallidos: ${Number(evaluation.failed)||0} · Pendientes: ${Number(evaluation.pending)||0}</strong></div>`;
   const content=summary+(checks.length?checks.map(k=>`<div class="list-row"><span class="dot ${k.status==='passed'?'good':k.status==='failed'?'bad':'pending'}"></span><div><strong>${esc(k.label)} · ${esc(k.status)}</strong><small>${esc(k.reason)} ${k.scope==='staging-observation'?'(solo staging)':''}</small></div></div>`).join(''):'<div class="list-row">Sin criterios instrumentales configurados.</div>');
   $('acceptanceResults').innerHTML=content;$('evaluationDetails').innerHTML=content;
   $('saveAcceptance').disabled=false;$('verifyAcceptance').disabled=false;
   const qaLink=$('downloadQaJson');qaLink.href='api.php?'+new URLSearchParams({action:'download_report',id:run.id});qaLink.classList.remove('hidden');

   const qa=run.qa;$('qaResults').innerHTML=qa?.checks?.length?qa.checks.map(t=>`<div class="list-row"><span class="dot ${t.ok===true?'good':t.ok===false?'bad':'pending'}"></span><div><strong>${esc(t.path)}</strong><small>${esc(t.kind||'verificación')} · ${esc(t.message)}</small></div></div>`).join(''):'No hay validaciones todavía.';
   $('modeStatus').textContent=run.mode==='pc-isolated'?'Ejecutando en copia aislada de Windows':'Ejecutando en copia de Hostinger';
   const changes=Object.keys(run.changes||{});$('changes').innerHTML=changes.length?changes.map(p=>`<button class="file-row" data-file="${esc(p)}">${esc(p)} <small>${esc((run.changes[p]?.sha256||'').slice(0,16))}…</small></button>`).join(''):'No hay cambios todavía.';
   document.querySelectorAll('[data-file]').forEach(el=>el.onclick=()=>showDiff(el.dataset.file));
   const link=$('downloadZip');link.classList.toggle('hidden',!run.artifact);if(run.artifact)link.href='api.php?'+new URLSearchParams({action:'download',id:run.id});
   if(events.length){const container=$('runEvents');for(const event of events){const d=document.createElement('div');d.className='event '+eventType(event.kind);d.innerHTML=`<small>${esc(event.created_at||'')} · ${esc(event.kind)}</small><div>${esc(event.message)}</div>`;container.appendChild(d);state.eventsAfter=Math.max(state.eventsAfter,Number(event.id)||0)}container.scrollTop=container.scrollHeight;}
   if(run.error&&!['running'].includes(run.status))$('saveState').textContent=run.error;
   if(run.status==='running')$('saveState').textContent=(run.pendingOp?'Windows: '+run.pendingOp:'Qwen: '+run.phase)+' · '+(run.lastFeedback||'').slice(0,90);
 }
 async function showDiff(path){if(!state.run)return;try{const d=await api('GET','diff',{id:state.run.id,path});const area=$('diffView');area.classList.remove('hidden');area.textContent=`ARCHIVO: ${d.path}\nANTES sha256: ${d.beforeSha256}\nDESPUÉS sha256: ${d.afterSha256}\n\n===== DIFF =====\n${d.diff}\n\n===== ARCHIVO PROPUESTO =====\n${d.after}`;area.scrollIntoView({block:'nearest'});}catch(e){flash(e.message,true)}}
 async function refreshRun(tick=false){if(!state.run||state.polling)return;state.polling=true;try{
   if(tick&&state.run.status==='running'){const now=Date.now();if(now-state.lastTick>1300){state.lastTick=now;const x=await api('POST','tick',{id:state.run.id});showRun(x.run);}}
   const data=await api('GET','run',{id:state.run.id,after:state.eventsAfter});showRun(data.run,data.events);
 }catch(e){flash(e.message,true)}finally{state.polling=false}}
 async function refreshHistory(){try{const rs=(await api('GET','runs')).runs||[];$('recentRuns').innerHTML=rs.length?rs.slice(0,40).map(r=>`<button class="run-row" data-run="${esc(r.id)}"><b>${esc(r.request.slice(0,80))}</b><small>${esc(statusName(r.status))} · ${esc(r.createdAt)}</small></button>`).join(''):'Sin trabajos anteriores.';
  document.querySelectorAll('[data-run]').forEach(btn=>btn.onclick=()=>openRun(btn.dataset.run));}catch(e){flash(e.message,true)}}
 async function openRun(id){try{const data=await api('GET','run',{id});state.planEditorDirty=false;state.planEditorRun=null;state.planEditorRevision=null;state.eventsAfter=0;$('runEvents').innerHTML='';$('acceptanceCriteria').value=JSON.stringify(data.run.acceptanceChecks||[],null,2);showRun(data.run,data.events);document.querySelector('[data-tab="work"]').click();}catch(e){flash(e.message,true)}}
 // Area 5 task picker: state is loaded from the real Hostinger database, never
 // inferred from whether a pause button was clicked in a previous session.
 async function refreshLimitTasks(preferredId=''){
   const select=$('limitTaskSelect');if(!select)return;
   const data=await api('GET','runs');const runs=data.runs||[];
   state.limitRuns=runs;
   const eligible=runs.filter(r=>['paused','incomplete'].includes(r.status));
   const other=runs.filter(r=>!['paused','incomplete'].includes(r.status));
   const ordered=[...eligible,...other].slice(0,100);
   select.innerHTML='<option value="">Selecciona una tarea…</option>'+ordered.map(r=>
     `<option value="${esc(r.id)}">${esc(statusName(r.status))} · ${esc((r.request||'').slice(0,54))} · ${esc(r.id.slice(-8))}</option>`).join('');
   const current=preferredId||state.run?.id||select.value;
   const found=ordered.find(r=>r.id===current);
   const chosen=found?found.id:(eligible[0]?.id||'');
   select.value=chosen;
   if(chosen && chosen!==state.run?.id){
      const d=await api('GET','run',{id:chosen});showRun(d.run);
   }else if(chosen && state.run){
      const d=await api('GET','run',{id:chosen});showRun(d.run);
   }else if(!chosen && $('limitTaskInfo')){
      $('limitTaskInfo').textContent='No hay tareas pausadas. Selecciona un proyecto en Trabajo autónomo y pulsa Crear tarea pausada de prueba (sin Qwen).';
      ['limitActive','limitRemaining','limitSteps','limitStepsLeft'].forEach(id=>$(id).textContent='—');
   }
 }
 async function fetchSaveProject(id,root=$('pcLocalRoot').value.trim()){const response=await fetch('../api/web/projects.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({action:'update_project',id,localRoot:root,stagingUrl:$('stagingUrl').value.trim()})});const d=await response.json();if(!response.ok||!d.ok)throw Error(d.error||'No se pudo guardar proyecto');return d}
 async function connectProbe(){try{const data=await api('POST','capabilities_probe');$('bridgeBadge').textContent='Consulta enviada a Windows';flash('Consulta enviada: '+data.jobId+' · espera respuesta desde tu PC.');}catch(e){flash(e.message,true)}}
 async function refreshCapabilities(){try{const d=await api('GET','capabilities');const data=d.lastProbe;
  if(!data){$('capabilitiesResult').textContent='No hay consulta enviada todavía.';return}
  const result=typeof data.result_json==='string'?JSON.parse(data.result_json||'{}'):data.result_json;
  $('capabilitiesResult').textContent=JSON.stringify({status:data.status,error:data.error_text,updated_at:data.updated_at,result},null,2);
  const ok=data.status==='done'&&result?.protocol==='nexa-developer-web-control/3.0';$('bridgeBadge').textContent=ok?'Web Control v3 conectado':data.status==='done'?'Bridge v3 no detectado':data.status==='error'?'PC devolvió error':'PC '+data.status;
  $('bridgeBadge').className='badge '+(ok?'good':data.status==='error'?'bad':'muted');
 }catch(e){$('capabilitiesResult').textContent=e.message}}
 // Developer Chat v16: one opt-in chat backed by the SAME 12-area engine and run snapshots.
 function chat16SyncProjects(){
   const select=$('chatProjectSelect');if(!select)return;
   const old=select.value||$('projectSelect').value;
   select.innerHTML='<option value="">Selecciona un proyecto…</option>'+state.projects.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${p.count} archivos</option>`).join('');
   if(state.projects.some(p=>p.id===old))select.value=old;
 }
 function chat16Phase(run){
   if(!run)return 'Todavía sin tareas.';
   const phases={plan:'Generando plan con Qwen',wait_plan:'Esperando plan de Qwen',plan_result:'Validando plan',action:'Herramientas y edición en Hostinger',wait_action:'Esperando acción de Qwen',action_result:'Verificando acción',evaluate:'Ejecutando QA y evaluador',complete:'Evaluación finalizada',wait_tool:'Esperando herramienta'};
   return phases[run.phase]||run.phase;
 }
 async function chat16LoadThreads(selectThread=''){
   const projectId=$('chatProjectSelect').value;if(!projectId){$('chatThreadSelect').innerHTML='<option value="">Primero selecciona un proyecto</option>';return;}
   const data=await api('GET','chat16_threads',{projectId});const rows=data.threads||[];
   const selector=$('chatThreadSelect');const choice=selectThread||chat16.threadId||selector.value;
   selector.innerHTML='<option value="">Nueva conversación…</option>'+rows.map(t=>`<option value="${esc(t.id)}">${esc(t.title)} · ${esc(t.updated_at)}</option>`).join('');
   chat16.threadId=rows.some(t=>t.id===choice)?choice:(rows[0]?.id||'');selector.value=chat16.threadId;
   await chat16Refresh(false);
 }
 function chat16Render(detail){
   const view=$('chat16Messages'),events=$('chat16Events'),status=$('chat16Status');
   if(!detail){view.innerHTML='<div class="devchat-empty">Selecciona un proyecto para comenzar. Tus conversaciones y trabajos se guardarán en Hostinger.</div>';status.textContent='Sin conversación activa.';events.textContent='';$('chatOpenRun').disabled=true;return;}
   const runs=detail.runs||{};const blocks=[];
   for(const message of detail.messages||[]){
     const run=runs[message.run_id]||null;
     blocks.push(`<div class="devchat-msg devchat-user"><small>Tú · ${esc(message.created_at)}</small><div>${esc(message.content)}</div></div>`);
     if(run){
       const p=run.planProgress||{},evaluation=run.evaluation||{};
       const last=run.summary||run.lastFeedback||'';
       const analysis=run.analysisReport;
       const analysisHtml=analysis?`<div class="devchat-feedback"><strong>Informe de lectura · LISTO PARA CONTINUAR</strong><div>Archivos inspeccionados: ${Number(analysis.readCount)||0} de ${Number(analysis.catalogCount)||0}</div><div>${esc((analysis.readFiles||[]).join(', '))}</div><small>${esc(analysis.limitations||'')}</small></div>`:'';
       const download=(run.artifact&&['review_required','incomplete'].includes(run.status))?
         `<a class="download" href="api.php?${new URLSearchParams({action:'download',id:run.id})}">⇩ ZIP para revisión · ${esc(run.artifact.files??'?')} archivos</a>`:'';
       blocks.push(`<div class="devchat-msg devchat-result"><small>Developer Qwen · ${esc(statusName(run.status))} · ${esc(chat16Phase(run))}</small>
         <div>Trabajo <code>${esc(run.id)}</code> · ${Number(run.steps)||0} pasos · ${Number(run.edits)||0} ediciones · Plan ${Number(p.done)||0}/${Number(p.total)||0}</div>
         ${run.error?`<div class="devchat-error">${esc(run.error)}</div>`:''}
         ${last?`<div class="devchat-feedback">${esc(last)}</div>`:''}
         ${analysisHtml}
         ${Object.keys(evaluation).length?`<div>Evaluación: ${Number(evaluation.passed)||0} aprobados · ${Number(evaluation.failed)||0} fallidos · ${Number(evaluation.pending)||0} pendientes. No equivale a aceptación de producción.</div>`:''}
         ${download}</div>`);
     }
   }
   view.innerHTML=blocks.join('')||'<div class="devchat-empty">Conversación vacía. Escribe la primera instrucción.</div>';
   const current=detail.currentRun;
   $('chatOpenRun').disabled=!current;
   const busy=current&&current.status==='running';$('chat16Send').disabled=!!busy||chat16.busy;
   const explanation=busy?'La tarea está activa. Espera, actualiza o abre Trabajo autónomo para pausarla.':
     current?.waitJob?'Hay una operación pendiente del trabajo anterior. Resuélvela en Trabajo autónomo antes de continuar.':
     'Puedes enviar otra instrucción: la nueva tarea conservará la copia anterior y generará evidencias nuevas.';
   status.textContent=current?`Proyecto: ${detail.thread.project_id} · Modelo solicitado: qwen2.5-coder:7b · ${statusName(current.status)} · ${chat16Phase(current)} · ${explanation}`:
      `Proyecto: ${detail.thread.project_id} · Conversación lista. El siguiente mensaje iniciará una tarea real.`;
   events.innerHTML=(detail.events||[]).map(e=>`<div>${esc(e.created_at)} · <b>${esc(e.kind)}</b>: ${esc(e.message)}</div>`).join('');
   events.scrollTop=events.scrollHeight;
 }
 async function chat16Refresh(tick=false){
   if(chat16.busy)return;
   if(!chat16.threadId){chat16Render(null);return;}
   chat16.busy=true;
   try{
     if(tick&&chat16.detail?.currentRun?.status==='running'){
       // Cron is primary; this path allows the user to advance work while the tab is open.
       await api('POST','tick',{id:chat16.detail.currentRun.id});
     }
     const d=await api('GET','chat16_thread',{id:chat16.threadId});
     chat16.detail=d.detail;chat16.lastRefresh=Date.now();chat16Render(chat16.detail);
   }finally{chat16.busy=false;if($('chat16Send')&&chat16.detail?.currentRun?.status!=='running')$('chat16Send').disabled=false;}
 }
 async function chat16Send(){
   const projectId=$('chatProjectSelect').value;const message=$('chat16Input').value.trim();
   if(!projectId)return flash('Selecciona un proyecto importado en Chat Developer.',true);
   if(message.length<12)return flash('Describe la tarea de programación con al menos 12 caracteres.',true);
   if(chat16.detail?.currentRun?.status==='running')return flash('La tarea anterior todavía trabaja. Espera su resultado.',true);
   const button=$('chat16Send');button.disabled=true;
   try{
     if(!chat16.threadId){const created=await api('POST','chat16_new',{projectId});chat16.threadId=created.thread.id;}
     const result=await api('POST','chat16_send',{threadId:chat16.threadId,message});
     $('chat16Input').value='';await chat16LoadThreads(result.thread.id);
     flash('Tarea Developer iniciada. Cron/Hostinger y Qwen procesarán las fases; ningún resultado se inventará.');
   }catch(e){flash('Chat Developer: '+e.message,true);}
   finally{button.disabled=!!(chat16.detail?.currentRun?.status==='running');}
 }
 async function chat16ProbeStatus(){
   if(!chat16.probeJob)return;
   try{const d=await api('GET','chat16_probe_status',{jobId:chat16.probeJob});const p=d.probe;
     $('chatProbeResult').textContent=p.verified?'Qwen REAL verificado: qwen2.5-coder:7b devolvió el JSON esperado.':
       p.status==='done'?`Qwen respondió, pero el formato/token no coincide. Respuesta: ${p.reply||'(vacía)'}`:
       p.status==='error'?`Error real del puente Qwen: ${p.error}`:`Solicitud Qwen ${p.status}. Esperando que Windows consulte esta web. Trabajo ${p.jobId}.`;
     if(['done','error','cancelled'].includes(p.status))chat16.probeJob='';
   }catch(e){$('chatProbeResult').textContent='No se pudo consultar la prueba de Qwen: '+e.message;chat16.probeJob='';}
 }
 function chat16Setup(){
   $('chatProjectSelect').onchange=async()=>{chat16.threadId='';chat16.detail=null;try{await chat16LoadThreads()}catch(e){flash(e.message,true)}};
   $('chatThreadSelect').onchange=async()=>{chat16.threadId=$('chatThreadSelect').value;chat16.detail=null;try{await chat16Refresh()}catch(e){flash(e.message,true)}};
   $('chatNew').onclick=async()=>{const projectId=$('chatProjectSelect').value;if(!projectId)return flash('Selecciona un proyecto primero.',true);
     try{const d=await api('POST','chat16_new',{projectId});chat16.threadId=d.thread.id;await chat16LoadThreads(d.thread.id);flash('Conversación Developer creada.');}catch(e){flash(e.message,true)};
   };
   $('chat16Send').onclick=chat16Send;
   $('chatRefresh').onclick=async()=>{try{await chat16Refresh(true);await chat16ProbeStatus();flash('Estado real actualizado.');}catch(e){flash(e.message,true)}};
   $('chatProbeQwen').onclick=async()=>{if(chat16.probeJob)return flash('Hay una prueba Qwen pendiente.',true);
     try{const d=await api('POST','chat16_probe');chat16.probeJob=d.jobId;$('chatProbeResult').textContent='Orden real enviada a qwen2.5-coder:7b. Esperando respuesta desde Windows…';flash('Prueba de conexión Qwen iniciada.');}
     catch(e){flash('No se pudo consultar Qwen: '+e.message,true)};
   };
   $('chatOpenRun').onclick=()=>{const id=chat16.detail?.currentRun?.id;if(!id)return flash('No hay tarea que abrir.',true);openRun(id);};
 }
 function setup(){
  chat16Setup();
  document.querySelectorAll('#devTabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#devTabs button').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.panel').forEach(x=>x.classList.toggle('visible',x.dataset.panel===b.dataset.tab));$('panelTitle').textContent=b.textContent.trim();if(b.dataset.tab==='limits')refreshLimitTasks($('limitTaskSelect').value).catch(e=>flash('No se pudo consultar historial: '+e.message,true));});
  $('limitTaskSelect').onchange=async()=>{
    const id=$('limitTaskSelect').value;if(!id){$('limitTaskInfo').textContent='Selecciona una tarea.';return;}
    try{const d=await api('GET','run',{id});showRun(d.run);$('limitDiagnostic').textContent=`Tarea cargada: ${d.run.id} · ${statusName(d.run.status)}`;}
    catch(e){flash(e.message,true)}
  };
  $('limitRefreshTasks').onclick=async()=>{try{await refreshLimitTasks($('limitTaskSelect').value);flash('Historial y estado real actualizados.')}catch(e){flash(e.message,true)}};
  $('limitCreateManualTest').onclick=async()=>{
    const projectId=$('projectSelect').value;
    if(!projectId)return flash('Primero selecciona un proyecto importado en Trabajo autónomo.',true);
    if(!confirm('Crear una tarea NUEVA pausada para probar límites, sobre una COPIA web, SIN Qwen y sin alterar tareas anteriores?'))return;
    try{const d=await api('POST','limits_create_test',{projectId});showRun(d.run);await refreshLimitTasks(d.id);
      $('limitDiagnostic').textContent=`Tarea de prueba creada: ${d.id}. Estado: ${d.run.status}. Pasos consumidos: ${d.run.limits.usedSteps}.`;
      flash('Tarea pausada de prueba creada y seleccionada. Ya puedes aplicar límites.');}
    catch(e){flash(e.message,true)}
  };
  $('limitSelfTest').onclick=async()=>{try{const d=await api('POST','limits_selftest');$('limitDiagnostic').textContent=JSON.stringify(d.result,null,2);flash('Autoprueba Área 5: '+d.result.passed+'/'+d.result.total+' comprobaciones.');}catch(e){flash(e.message,true)}};
  $('limitApplyRun').onclick=async()=>{
    const chosen=$('limitTaskSelect').value;
    if(!chosen || !state.run || state.run.id!==chosen)return flash('Selecciona una tarea del historial de Tiempo y límites. Si no hay ninguna pausada, crea una prueba sin Qwen.',true);
    if(!['paused','incomplete'].includes(state.run.status))return flash('Tarea '+state.run.id+' en estado '+statusName(state.run.status)+'. Debes seleccionar una pausada o crear la tarea de prueba.',true);
    if(!confirm('Actualizar solo límites de esta tarea pausada, sin reiniciar su presupuesto consumido?'))return;
    try{const c=collectConfig(),d=await api('POST','limits_update_run',{id:state.run.id,limits:c.limits});showRun(d.run);$('limitDiagnostic').textContent=JSON.stringify(d.run.limits,null,2);flash('Límites aplicados a la tarea pausada.');}catch(e){flash(e.message,true)}};
  $('saveSettings').onclick=async()=>{try{const result=await api('POST','save_settings',{config:collectConfig()});state.config=result.config;bindControls();flash('Configuración guardada en Hostinger.');$('saveState').textContent='Guardado';}catch(e){flash(e.message,true)}};
  $('createProject').onclick=async()=>{try{const d=await api('POST','create_project',{name:$('newProject').value});await loadProjects();$('projectSelect').value=d.id;flash('Proyecto creado. Importa un ZIP para comenzar.');}catch(e){flash(e.message,true)}};
  $('projectSelect').onchange=()=>{syncProjectFields();void aider03Refresh();};
  // Symbol Intelligence 03: only Developer panel, never Chat or Image Studio.
  const symbols03={offset:0,projectId:'',query:'',busy:false};
  async function symbols03Load(reset=false){
    const projectId=$('projectSelect').value,query=$('symbols03Query').value.trim();
    if(!projectId)return flash('Selecciona un proyecto antes de analizar símbolos.',true);
    if(symbols03.busy)return;
    if(reset||projectId!==symbols03.projectId||query!==symbols03.query){
      $('symbols03RefsPanel').hidden=true;symbols03RefsCloseIfPresent();
      symbols03.offset=0;symbols03.projectId=projectId;symbols03.query=query;$('symbols03Results').innerHTML='';
    }
    symbols03.busy=true;$('symbols03Scan').disabled=true;$('symbols03More').disabled=true;
    $('symbols03Status').textContent='Inspeccionando código del proyecto (solo lectura)…';
    try{
      const data=await api('GET','symbols03',{projectId,offset:String(symbols03.offset),limit:'20',query});
      if(projectId!==$('projectSelect').value||query!==$('symbols03Query').value.trim())return;
      const d=data.analysis;symbols03.offset=d.nextOffset??d.totalEligibleFiles;
      const output=d.files.flatMap(file=>file.symbols.map(item=>`<div class="list-row"><div><strong>${esc(item.type)} · ${esc(item.qualifiedName)}</strong><small>${esc(item.path)}:${item.startLine}–${item.endLine} · ${esc(item.source)} · ${esc(item.confidence)}</small>${item.signature?`<small>${esc(item.signature)}</small>`:''}${item.referenceCandidates.length?`<small>Referencias candidatas en este archivo: ${item.referenceCandidates.map(x=>x.line).join(', ')} (sin resolver)</small>`:''}<button type="button" class="secondary" data-symbol03ref="1" data-path="${esc(item.path)}" data-name="${esc(item.qualifiedName)}" data-type="${esc(item.type)}" data-line="${Number(item.startLine)}" data-sha="${esc(file.sha256)}">Buscar usos en el proyecto</button></div></div>`)).join('');
      $('symbols03Results').insertAdjacentHTML('beforeend',output||'<div class="muted">Sin símbolos coincidentes en este lote.</div>');
      $('symbols03Status').textContent=`Analizados ${Math.min(symbols03.offset,d.totalEligibleFiles)} de ${d.totalEligibleFiles} archivos elegibles · ${d.matchedSymbols} símbolos Web en este lote · ${d.skipped.length} omitidos. `+(d.aiderConnected?`Aider fusionado: ${d.aiderMerge.matchedSymbols} coincidencias, ${d.aiderMerge.addedSymbols} símbolos añadidos (SHA coincidente).`:'Aider aún sin resultados compatibles para estos archivos; detector Web activo.');
      $('symbols03More').disabled=d.nextOffset===null;
    }catch(error){$('symbols03Status').textContent='Error: '+error.message;flash(error.message,true);}
    finally{symbols03.busy=false;$('symbols03Scan').disabled=false;}
  }
  $('symbols03Scan').onclick=()=>symbols03Load(true);
  $('symbols03More').onclick=()=>symbols03Load(false);

  // Phase 2: request read-only reference lookup in bounded pages; never execute project code.
  function symbols03RefsCloseIfPresent(){symbols03Refs.generation++;symbols03Refs.target=null;}
  const symbols03Refs={target:null,offset:0,busy:false,projectId:'',generation:0};
  async function symbols03RefsLoad(reset=false){
    if(!symbols03Refs.target||symbols03Refs.busy)return;
    const projectId=$('projectSelect').value;
    if(!projectId||projectId!==symbols03Refs.projectId)return;
    const generation=symbols03Refs.generation;
    if(reset){symbols03Refs.offset=0;$('symbols03RefsResults').textContent='';}
    symbols03Refs.busy=true;$('symbols03RefsMore').disabled=true;
    $('symbols03RefsStatus').textContent='Buscando referencias léxicas en una copia importada…';
    try{
      const data=await api('GET','symbols03refs',{
        projectId,path:symbols03Refs.target.path,name:symbols03Refs.target.name,
        type:symbols03Refs.target.type,line:String(symbols03Refs.target.line),sha256:symbols03Refs.target.sha256,
        offset:String(symbols03Refs.offset),limit:'15'
      });
      if(projectId!==$('projectSelect').value||generation!==symbols03Refs.generation)return;
      const r=data.references;symbols03Refs.offset=r.nextOffset??r.totalEligibleFiles;
      const html=r.hits.map(hit=>`<div class="list-row"><div><strong>${esc(hit.path)}:${Number(hit.line)}</strong><small>${esc(hit.kind)} · ${esc(hit.confidence)} · ${esc(hit.evidence)}</small></div></div>`).join('');
      $('symbols03RefsResults').insertAdjacentHTML('beforeend',html||'<div class="muted">Sin referencias en este lote.</div>');
      $('symbols03RefsStatus').textContent=`${r.target.name} · revisados ${Math.min(symbols03Refs.offset,r.totalEligibleFiles)}/${r.totalEligibleFiles} archivos · ${r.hitsThisPage} coincidencias en este lote. Referencias de análisis léxico, NO certificadas por Aider/LSP.`;
      $('symbols03RefsMore').disabled=r.nextOffset===null;
    }catch(error){if(generation===symbols03Refs.generation){$('symbols03RefsStatus').textContent='No se pudieron buscar referencias: '+error.message;flash(error.message,true);}}
    finally{symbols03Refs.busy=false;}
  }
  $('symbols03Results').addEventListener('click',ev=>{
    const button=ev.target.closest('button[data-symbol03ref]');if(!button||!$('symbols03Results').contains(button))return;
    if(symbols03Refs.busy)return flash('Espera a que termine la búsqueda actual.',true);
    symbols03Refs.generation++;symbols03Refs.target={path:button.dataset.path,name:button.dataset.name,type:button.dataset.type,
      line:Number(button.dataset.line),sha256:button.dataset.sha};
    symbols03Refs.projectId=$('projectSelect').value;
    $('symbols03RefsPanel').hidden=false;symbols03RefsLoad(true);
  });
  $('symbols03RefsMore').onclick=()=>symbols03RefsLoad(false);
  $('symbols03RefsClose').onclick=()=>{symbols03Refs.generation++;$('symbols03RefsPanel').hidden=true;symbols03Refs.target=null;};
  $('saveProjectLocal').onclick=async()=>{const id=$('projectSelect').value;if(!id)return flash('Selecciona un proyecto.',true);try{await fetchSaveProject(id);await loadProjects();$('projectSelect').value=id;syncProjectFields();flash('URL de staging guardada en Hostinger.');}catch(e){flash(e.message,true)}};
  $('importZip').onclick=()=>{if(!$('projectSelect').value)return flash('Selecciona un proyecto primero.',true);$('projectZip').click()};
  $('projectZip').onchange=async e=>{const file=e.target.files[0],id=$('projectSelect').value;if(!file||!id)return;if(!confirm('Importar ZIP al Workspace Web de este proyecto? Se creará un snapshot del Workspace anterior.'))return;
    const form=new FormData();form.append('id',id);form.append('mode','replace');form.append('file',file);
    try{flash('Importando ZIP…');const resp=await fetch('../api/web/project-upload.php',{method:'POST',headers:{'X-CSRF-Token':csrf},body:form,credentials:'same-origin'});
      const data=await resp.json();if(!resp.ok||!data.ok)throw Error(data.error||'No se pudo importar');await loadProjects();$('projectSelect').value=id;flash('ZIP importado: '+data.files+' archivos');}
    catch(err){flash(err.message,true)}finally{e.target.value=''};
  };
  // Area 7: one-click real web-isolated test. No Qwen, no Windows edits.
  const edit11Show=(message)=>{if($('edit11Output'))$('edit11Output').textContent=typeof message==='string'?message:JSON.stringify(message,null,2);};
  if($('edit11Create'))$('edit11Create').onclick=async()=>{
    const projectId=$('projectSelect').value;if(!projectId)return flash('Selecciona primero PRUEBA AREA 2 en Trabajo autónomo.',true);
    if(!confirm('Crear una NUEVA COPIA aislada del proyecto para probar Área 7? No se alteran los originales ni trabajos existentes.'))return;
    try{const d=await api('POST','edit11_create_test',{projectId});state.eventsAfter=0;state.planEditorDirty=false;state.planEditorRun=null;showRun(d.run);
       edit11Show('Tarea aislada creada: '+d.run.id+' · PAUSADA. Pulsa Ejecutar prueba real del Área 7.');$('edit11Info').textContent='Tarea de prueba aislada seleccionada. No requiere Qwen.';
       await refreshHistory();flash('Área 7: tarea aislada lista.');}catch(e){edit11Show(e.message);flash(e.message,true)}
  };
  if($('edit11Test'))$('edit11Test').onclick=async()=>{
    if(!state.run)return flash('Crea primero la tarea aislada con el botón anterior.',true);
    if(!confirm('Ejecutar creación, parches, mover, borrar, errores intencionales y reversión sobre la COPIA de esta tarea?'))return;
    try{const d=await api('POST','edit11_test',{id:state.run.id});showRun(d.run);edit11Show(d.result);
      flash('Autoprueba Área 7: '+d.result.passed+'/'+d.result.total+' comprobaciones aprobadas.',d.result.passed!==d.result.total);}
    catch(e){edit11Show(e.message);flash(e.message,true)}
  };
  if($('edit11Undo'))$('edit11Undo').onclick=async()=>{
    if(!state.run)return flash('Selecciona una tarea pausada.',true);
    if(!confirm('Revertir el último lote de archivos (TODOS sus archivos) en la copia de Hostinger?'))return;
    try{const d=await api('POST','edit11_undo',{id:state.run.id});showRun(d.run);edit11Show(d.result);flash('Último lote revertido íntegramente.');}
    catch(e){edit11Show(e.message);flash(e.message,true)}
  };
  const putExample=(actions)=>{const el=$('toolSteps');if(el)el.value=JSON.stringify(actions,null,2);};
  if($('toolExampleGit'))$('toolExampleGit').onclick=()=>putExample([
    {action:'git_web',operation:'init'}, {action:'git_web',operation:'add',paths:[]},
    {action:'git_web',operation:'commit',message:'Nexa: checkpoint de laboratorio'},
    {action:'git_web',operation:'status'}]);
  if($('toolExampleSqlite'))$('toolExampleSqlite').onclick=()=>putExample([
    {action:'sqlite_local',operation:'init'},
    {action:'sqlite_local',operation:'migrate',sql:'CREATE TABLE IF NOT EXISTS ejemplo (id INTEGER PRIMARY KEY, nota TEXT NOT NULL)'},
    {action:'sqlite_local',operation:'schema'}, {action:'sqlite_local',operation:'integrity'}]);
  if($('toolExampleTerminal'))$('toolExampleTerminal').onclick=()=>putExample([
    {action:'terminal_web',operation:'version',program:'php'},
    {action:'terminal_web',operation:'version',program:'node'}]);
  if($('toolExampleFiles'))$('toolExampleFiles').onclick=()=>putExample([{action:'files_web',operation:'list'},{action:'files_web',operation:'hash',path:'README.md'}]);
  if($('toolExampleBrowser'))$('toolExampleBrowser').onclick=()=>putExample([{action:'browser_web',operation:'assert_status',status:200}]);
  if($('sqliteLabDownload'))$('sqliteLabDownload').onclick=e=>{
    if(!state.run){e.preventDefault();return flash('Abre una tarea primero.',true);}
    e.currentTarget.href='api.php?'+new URLSearchParams({action:'sqlite_download',id:state.run.id});
  };
  if($('sqliteLabAttach'))$('sqliteLabAttach').onclick=async()=>{
    if(!state.run||state.run.status!=='paused')return flash('Primero abre y pausa una tarea del laboratorio web.',true);
    const file=$('sqliteLabFile')?.files?.[0];if(!file)return flash('Selecciona una base SQLite.',true);
    if(file.size>8*1024*1024)return flash('Máximo 8MB.',true);
    if(!confirm('Importar la base al laboratorio aislado? No se modifica tu base original.'))return;
    try{const arr=new Uint8Array(await file.arrayBuffer());let encoded='';for(let i=0;i<arr.length;i+=16384)encoded+=btoa(String.fromCharCode(...arr.slice(i,i+16384)));
      const data=await api('POST','sqlite_attach',{id:state.run.id,base64:encoded});flash('SQLite de prueba importada, SHA '+data.database.sha256.slice(0,16)+'…');
    }catch(e){flash(e.message,true)}
  };
  $('startRun').onclick=async()=>{try{state.planEditorDirty=false;state.planEditorRun=null;state.planEditorRevision=null;const id=$('projectSelect').value;if(!id)return flash('Selecciona un proyecto.',true);
   const saved=await api('POST','save_settings',{config:collectConfig()});state.config=saved.config;bindControls();

   const request=$('request').value.trim();const criteria=parseCriteria();const x=await api('POST','create_run',{projectId:id,request,criteria});state.eventsAfter=0;$('runEvents').innerHTML='';showRun(x.run);await refreshRun(true);await refreshHistory();flash('Tarea creada en laboratorio aislado.');}catch(e){flash(e.message,true)}};
  for(const action of ['pause','resume','cancel'])$(action+'Run').onclick=async()=>{if(!state.run)return;try{const x=await api('POST',action,{id:state.run.id});showRun(x.run);flash('Estado: '+statusName(x.run.status));}catch(e){flash(e.message,true)}};
  $('refreshRun').onclick=()=>refreshRun(false);
  $('undoLast').onclick=async()=>{if(!state.run)return;if(!confirm('Revertir la última modificación aceptada en la COPIA de trabajo (no en el proyecto original)?'))return;try{const d=await api('POST','rollback_last',{id:state.run.id});showRun(d.run);flash('Reversión iniciada/completada sobre la copia.');}catch(e){flash(e.message,true)}};
  // Área 4: client-side editor never changes data until explicit, CSRF-protected API write.
  $('planEditor').addEventListener('input',()=>{state.planEditorDirty=true});
  $('planCreateManual').onclick=async()=>{
    const projectId=$('projectSelect').value;
    if(!projectId)return flash('Selecciona el proyecto PRUEBA AREA 2 en Trabajo autónomo.',true);
    let plan;
    try{plan=JSON.parse($('planEditor').value);}catch(e){return flash('Primero pega un plan JSON válido: '+e.message,true)}
    if(!plan||!Array.isArray(plan.objectives))return flash('El plan debe contener objectives en una lista JSON.',true);
    if(!confirm('Crear una NUEVA tarea de prueba ya pausada con una COPIA del proyecto de Hostinger, sin llamar a Qwen? La tarea actual no cambia.'))return;
    try{
      const d=await api('POST','plan_create_manual_test',{projectId,plan});
      state.eventsAfter=0;$('runEvents').innerHTML='';
      state.planEditorDirty=false;state.planEditorRun=null;state.planEditorRevision=null;
      showRun(d.run);
      $('planOutput').textContent='Prueba manual creada en Hostinger sin Qwen. Objetivo activo: '+(d.run.planProgress?.activeId||'—')+'. Pulsa Verificar objetivo activo. ID: '+d.run.id;
      await refreshHistory();
      flash('Prueba manual lista y pausada. Puedes verificar objetivos sin Qwen.');
    }catch(e){$('planOutput').textContent=e.message;flash('No se pudo crear la prueba manual: '+e.message,true)}
  };
  const parsePlan=()=>{let plan;try{plan=JSON.parse($('planEditor').value)}catch(e){throw Error('JSON del plan inválido: '+e.message)}
    if(!plan||typeof plan!=='object'||Array.isArray(plan))throw Error('El plan necesita un objeto con objectives.');return plan;};
  $('planLoad').onclick=()=>{if(!state.run)return flash('Selecciona primero una tarea.',true);
    const r=state.run,p=r.planProgress||{};
    $('planEditor').value=JSON.stringify({summary:r.planSummary||'',objectives:(r.objectives||[]).map(o=>({id:o.id,title:o.title,phase:o.phase,dependsOn:o.dependsOn||[],acceptance:o.acceptance,checks:o.checks||[],notes:o.notes||''}))},null,2);
    state.planEditorDirty=false;state.planEditorRun=r.id;state.planEditorRevision=p.revision??0;flash('Plan actual cargado para editar.');};
  $('planPreview').onclick=async()=>{if(!state.run)return flash('Selecciona primero una tarea.',true);
    try{const d=await api('POST','plan_preview',{id:state.run.id,plan:parsePlan()});$('planOutput').textContent=JSON.stringify({message:d.message,objectives:d.objectives},null,2);flash('Plan válido: dependencias sin ciclos, criterios correctos.');}
    catch(e){$('planOutput').textContent=e.message;flash(e.message,true)}};
  $('feature17Selftest').onclick=async()=>{try{const d=await api('POST','feature17_selftest');$('feature17Output').textContent=JSON.stringify(d.result,null,2);flash('Autoprueba de contrato: '+d.result.passed+'/'+d.result.total+' · formularios incompletos rechazados.');}catch(e){$('feature17Output').textContent=e.message;flash(e.message,true)}};
  $('planSave').onclick=async()=>{if(!state.run||state.run.status!=='paused')return flash('Primero pausa la tarea.',true);
    try{const plan=parsePlan();if(!confirm('Guardar nueva revisión del plan en esta tarea? Las evidencias de objetivos cambiados se reiniciarán.'))return;
      const d=await api('POST','plan_save',{id:state.run.id,plan,expectedRevision:state.planEditorRevision??0});
      state.planEditorDirty=false;state.planEditorRevision=null;showRun(d.run);$('planOutput').textContent='Revisión guardada. Revisa los objetivos y dependencias.';flash('Plan guardado y ordenado por dependencias.');}
    catch(e){$('planOutput').textContent=e.message;flash(e.message,true)}};
  $('planVerify').onclick=async()=>{if(!state.run||state.run.status!=='paused')return flash('Primero pausa la tarea.',true);
    try{const d=await api('POST','plan_verify',{id:state.run.id});showRun(d.run);$('planOutput').textContent=JSON.stringify(d.verification,null,2);flash('Criterios comprobados; no se aceptan declaraciones de Qwen como evidencia.');}
    catch(e){$('planOutput').textContent=e.message;flash(e.message,true)}};
  $('planManualApprove').onclick=async()=>{if(!state.run||state.run.status!=='paused')return flash('Pausa la tarea primero.',true);
    const id=state.run.planProgress?.activeId,reason=$('planManualReason').value.trim();
    if(!id)return flash('No hay un objetivo activo.',true);
    if(reason.length<20)return flash('Describe la comprobación manual (mínimo 20 caracteres).',true);
    if(!confirm(`Confirmas que tú revisaste el objetivo ${id}? Se registrará como aprobación HUMANA, NO como prueba automática.`))return;
    try{const d=await api('POST','plan_approve_manual',{id:state.run.id,objectiveId:id,reason,acknowledge:true});showRun(d.run);$('planManualReason').value='';$('planOutput').textContent='Aceptación humana auditada de '+id+'; no cuenta como prueba automatizada.';flash('Aprobación humana registrada.');}
    catch(e){$('planOutput').textContent=e.message;flash(e.message,true)}};
  $('saveAcceptance').onclick=async()=>{if(!state.run)return flash('Selecciona un trabajo.',true);try{const d=await api('POST','save_criteria',{id:state.run.id,criteria:parseCriteria()});showRun(d.run);flash('Criterios guardados en la tarea.');}catch(e){flash(e.message,true)}};
  const verify=async()=>{if(!state.run)return flash('Selecciona un trabajo.',true);try{const d=await api('POST','verify_acceptance',{id:state.run.id});showRun(d.run);flash('Pruebas independientes evaluadas; consulta el detalle.');}catch(e){flash(e.message,true)}};
  $('verifyAcceptance').onclick=verify;$('verifyAcceptancePanel').onclick=verify;
  $('eval14Create').onclick=async()=>{const projectId=$('projectSelect').value;
    if(!projectId)return flash('Selecciona el proyecto de pruebas en Trabajo autónomo.',true);
    try{const d=await api('POST','evaluator14_create_test',{projectId});showRun(d.run);$('eval14Output').textContent='Tarea aislada creada: '+d.run.id;flash('Área 10: laboratorio aislado creado sin Qwen.');await refreshHistory();}
    catch(e){$('eval14Output').textContent=e.message;flash(e.message,true)};
  };
  $('eval14Test').onclick=async()=>{
    if(!state.run)return flash('Crea primero una tarea aislada del Área 10.',true);
    try{const d=await api('POST','evaluator14_selftest',{id:state.run.id});showRun(d.run);
      $('eval14Output').textContent=JSON.stringify(d.result,null,2);flash(`Área 10: ${d.result.passed}/${d.result.total} comprobaciones.`);}
    catch(e){$('eval14Output').textContent=JSON.stringify({error:e.message},null,2);flash(e.message,true)};
  };
  $('eval14Suggest').onclick=()=>{
    if(!state.run)return flash('Selecciona la tarea con objetivos y casos de QA.',true);
    const goals=state.run.objectives||[],suite=state.run.qa12Suite||[],links={};
    for(const goal of goals){const paths=(goal.checks||[]).map(x=>x.path).filter(Boolean);
      links[goal.id]=suite.filter(x=>x.path&&paths.includes(x.path)&&['php_test','sqlite_query'].includes(x.type)).map(x=>x.name);
    }
    $('eval14Links').value=JSON.stringify(links,null,2);flash('Asociaciones propuestas. Verifica que las pruebas demuestren los requisitos.');
  };
  $('eval14SaveLinks').onclick=async()=>{
    if(!state.run)return flash('Selecciona una tarea pausada.',true);
    try{const links=JSON.parse($('eval14Links').value);const d=await api('POST','evaluator14_links',{id:state.run.id,links});showRun(d.run);flash('Asociaciones guardadas: evaluaciones antiguas invalidadas.');}
    catch(e){flash('No se pudieron guardar asociaciones: '+e.message,true)};
  };
  $('downloadReport').onclick=async()=>{if(!state.run)return flash('No hay tarea activa.',true);try{const d=await api('GET','report',{id:state.run.id});const area=$('diffView');area.classList.remove('hidden');area.textContent=JSON.stringify(d.report,null,2);area.scrollIntoView({block:'nearest'});}catch(e){flash(e.message,true)}};
  $('toolsCatalog').onclick=async()=>{if(!state.run)return flash('Selecciona una tarea primero.',true);try{
    const d=await api('POST','tools_catalog',{id:state.run.id});$('toolsCatalogResult').textContent=JSON.stringify(d.catalog,null,2);
  }catch(e){flash(e.message,true)}};
  $('toolsExecute').onclick=async()=>{if(!state.run)return flash('Selecciona una tarea primero.',true);
    if(state.run.status!=='paused')return flash('Pausa primero la tarea para ejecutar un lote manual.',true);
    let steps;try{steps=JSON.parse($('toolSteps').value)}catch(e){return flash('JSON de herramientas inválido: '+e.message,true)}
    if(steps.some(x=>x?.action==='git_web'&&x?.operation==='push')&&!confirm('¿Confirmas PUBLICAR cambios del laboratorio en el GitHub remoto configurado?'))return;
    try{const d=await api('POST','tools_execute',{id:state.run.id,steps});showRun(d.run);$('toolsStatus').textContent='Lote iniciado. Usa Actualizar hasta que vuelva a pausado.';flash('Lote enviado a la cola web.');}
    catch(e){flash(e.message,true)}
  };
  // Area 8: functional QA on a cloned web workspace. Every action returns real evidence.
  const qa12Output=o=>{$('qa12Output').textContent=JSON.stringify(o,null,2)};
  $('qa12Create').onclick=async()=>{const projectId=$('projectSelect').value;
    if(!projectId)return flash('Selecciona primero el proyecto importado en Trabajo autónomo.',true);
    try{const d=await api('POST','qa12_create_test',{projectId});showRun(d.run);qa12Output({message:'Tarea QA creada sin Qwen, pausada y aislada.',id:d.run.id});flash('Laboratorio QA aislado preparado.');await refreshHistory();}
    catch(e){qa12Output({error:e.message});flash(e.message,true)};
  };
  $('qa12Selftest').onclick=async()=>{if(!state.run)return flash('Selecciona primero una tarea QA.',true);
    try{const d=await api('POST','qa12_selftest',{id:state.run.id});qa12Output(d.result);flash('Autoprueba completada: '+d.result.passed+'/'+d.result.total+' pruebas correctas.');}
    catch(e){qa12Output({error:e.message});flash(e.message,true)};
  };
  $('qa12Discover').onclick=async()=>{if(!state.run)return flash('Crea o selecciona una tarea.',true);
    try{const d=await api('POST','qa12_autodiscover',{id:state.run.id});$('qa12Suite').value=JSON.stringify(d.suite,null,2);qa12Output({detected:d.suite.length,suite:d.suite});flash('Casos detectados. Revisa las expectativas antes de ejecutarlos.');}
    catch(e){qa12Output({error:e.message});flash(e.message,true)};
  };
  const qa12ReadSuite=()=>{let x;try{x=JSON.parse($('qa12Suite').value)}catch(e){throw Error('QA JSON inválido: '+e.message)}if(!Array.isArray(x)||!x.length)throw Error('QA necesita al menos un caso.');return x;};
  $('qa12Save').onclick=async()=>{if(!state.run)return flash('Selecciona una tarea.',true);
    try{const d=await api('POST','qa12_save',{id:state.run.id,suite:qa12ReadSuite()});showRun(d.run);qa12Output({saved:d.suite.length});flash('Suite QA guardada, sin ejecutar.');}
    catch(e){qa12Output({error:e.message});flash(e.message,true)};
  };
  $('qa12Run').onclick=async()=>{if(!state.run)return flash('Selecciona una tarea.',true);
    try{const suite=qa12ReadSuite();if(suite.some(x=>x.type==='php_test')&&!confirm('Se ejecutarán archivos PHP del proyecto dentro de una COPIA temporal Hostinger. PHP no es un aislamiento OS. ¿Confías en este código?'))return;
      const d=await api('POST','qa12_run',{id:state.run.id,suite});showRun(d.run);qa12Output(d.result);flash(`QA: ${d.result.passed} aprobados, ${d.result.failed} fallidos, ${d.result.pending} pendientes.`);}
    catch(e){qa12Output({error:e.message});flash(e.message,true)};
  };
  $('qa12PhpExample').onclick=()=>{let suite=[];try{suite=JSON.parse($('qa12Suite').value)||[]}catch(e){}
    if(!Array.isArray(suite))suite=[];let path=suite.find(x=>x.type==='php_syntax')?.path||'hello.php';
    suite.push({name:'Ejecución PHP: '+path,type:'php_test',path,expect:path==='hello.php'?'NEXA_AREA2_PHP_OK':''});
    $('qa12Suite').value=JSON.stringify(suite,null,2);flash('Caso PHP añadido. Haz Ejecutar QA del proyecto.');
  };
  // Area 9: no manual JSON or code editing. Create a fresh paused web clone.
  if($('repair13Create'))$('repair13Create').onclick=async()=>{
    const projectId=$('projectSelect').value;
    if(!projectId)return flash('Selecciona primero el proyecto de prueba.',true);
    try{const d=await api('POST','repair13_create_test',{projectId});showRun(d.run);
      $('repair13Output').textContent=JSON.stringify({message:'Tarea de reparación aislada y pausada, sin Qwen.',id:d.run.id},null,2);
      $('repair13Info').textContent='Laboratorio web preparado. Ejecuta la autoprueba; no necesitas pegar código.';
      await refreshHistory();flash('Área 9: tarea de prueba lista.');
    }catch(e){$('repair13Output').textContent=e.message;flash(e.message,true);}
  };
  if($('repair13Test'))$('repair13Test').onclick=async()=>{
    if(!state.run)return flash('Crea primero la tarea de reparación.',true);
    if(!confirm('Se ejecutará PHP del proyecto de prueba y archivos controlados en una copia temporal. Usa proyectos confiables. ¿Continuar?'))return;
    try{const d=await api('POST','repair13_selftest',{id:state.run.id});showRun(d.run);
      $('repair13Output').textContent=JSON.stringify(d.result,null,2);
      flash('Reparación: '+d.result.passed+'/'+d.result.total+' comprobaciones aprobadas.');
    }catch(e){$('repair13Output').textContent=JSON.stringify({error:e.message},null,2);flash(e.message,true);}
  };
  // Area 12: cron activity is not assumed from the UI; test actual SQLite state.
  $('track15Health').onclick=async()=>{try{const d=await api('GET','tracking15_health');
    $('track15HealthOutput').textContent=JSON.stringify(d.health,null,2);
    flash(d.health.cronObserved?'Última ejecución cron registrada.':'No existe ejecución cron registrada; configúralo en Hostinger.');
  }catch(e){$('track15HealthOutput').textContent=JSON.stringify({error:e.message});flash(e.message,true);}};
  $('track15Create').onclick=async()=>{const projectId=$('projectSelect').value;
    if(!projectId)return flash('Selecciona primero un proyecto en Trabajo autónomo.',true);
    try{const d=await api('POST','tracking15_create_test',{projectId});showRun(d.run);await refreshHistory();
      $('track15Output').textContent=JSON.stringify({message:'Laboratorio aislado preparado sin Qwen.',id:d.run.id},null,2);
      flash('Área 12: tarea de seguimiento lista.');
    }catch(e){$('track15Output').textContent=JSON.stringify({error:e.message});flash(e.message,true);}};
  $('track15Test').onclick=async()=>{if(!state.run)return flash('Primero crea la tarea de seguimiento aislada.',true);
    try{const d=await api('POST','tracking15_selftest',{id:state.run.id});showRun(d.run);
      $('track15Output').textContent=JSON.stringify(d.result,null,2);
      $('track15HealthOutput').textContent=JSON.stringify(d.health,null,2);
      flash(`Área 12: ${d.result.passed}/${d.result.total} pruebas realizadas.`);
    }catch(e){$('track15Output').textContent=JSON.stringify({error:e.message});flash(e.message,true);}};

 // Read-only Aider protocol; never use pc_terminal or an arbitrary executable.
 let aider03Poll=null;
 async function aider03Refresh(){
   const projectId=$('projectSelect').value;
   if(!projectId){$('aider03Status').textContent='Selecciona un proyecto.';$('aider03Analyze').disabled=true;return;}
   try{
     const d=await api('GET','aider03_status',{projectId});
     const ready=d.capability?.ready===true;
     $('aider03Analyze').disabled=!ready||!d.project?.configured||['queued','running'].includes(d.aider?.status);
     $('aider03Status').textContent=d.capability?.message||'Puente no disponible.';
     const info={protocol:d.capability?.protocol,workerReady:ready,projectPathConfigured:d.project?.configured,
       analysis:d.aider,webFallback:'El detector PHP/JS Web permanece activo'};
     $('aider03Output').textContent=JSON.stringify(info,null,2);
     if(['queued','running'].includes(d.aider?.status)){
       if(!aider03Poll)aider03Poll=setInterval(aider03Refresh,5000);
     }else if(aider03Poll){clearInterval(aider03Poll);aider03Poll=null;}
     if(d.aider?.status==='done'){
       // Display verified, merged results on the existing symbol panel.
       if($('symbols03Results')?.children.length && typeof symbols03Load==='function')await symbols03Load(true);
     }
   }catch(e){if(aider03Poll){clearInterval(aider03Poll);aider03Poll=null;} $('aider03Status').textContent='Error de comprobación: '+e.message;$('aider03Analyze').disabled=true;}
 }
 if($('aider03Health'))$('aider03Health').onclick=aider03Refresh;
 if($('aider03SaveRoot'))$('aider03SaveRoot').onclick=async()=>{
   const id=$('projectSelect').value;if(!id)return flash('Selecciona un proyecto.',true);
   const root=$('aider03Root').value.trim();
   if(root && !/^[A-Za-z]:[\\/](?:[^\\/:*?"<>|\r\n]+[\\/])+[^\\/:*?"<>|\r\n]+$/.test(root))
     return flash('Usa una carpeta concreta, por ejemplo D:\\Projects\\MiProyecto.',true);
   try{await fetchSaveProject(id,root);await loadProjects();$('projectSelect').value=id;syncProjectFields();
       flash('Ruta del proyecto guardada; no se ejecutó Aider.');await aider03Refresh();}
   catch(e){flash(e.message,true);}
 };
 if($('aider03Analyze'))$('aider03Analyze').onclick=async()=>{
   const projectId=$('projectSelect').value;if(!projectId)return flash('Selecciona un proyecto.',true);
   if(!confirm('Solicitar SOLO análisis estructural a Aider de la carpeta Windows indicada. No editar código ni permitir comandos de terminal. ¿Continuar?'))return;
   try{$('aider03Analyze').disabled=true;const d=await api('POST','aider03_analyze',{projectId});
       $('aider03Status').textContent='Análisis solicitado: '+d.aider.status;await aider03Refresh();}
   catch(e){flash(e.message,true);await aider03Refresh();}
 };
  $('probePc').onclick=connectProbe;
  $('probeTools').onclick=async()=>{try{const d=await api('GET','tools_web_health');$('capabilitiesResult').textContent=JSON.stringify(d.health,null,2);flash('Diagnóstico real de Hostinger recibido.');}catch(e){flash(e.message,true)}};
  $('workspaceKind').addEventListener('change',()=>{$('modeStatus').textContent=$('workspaceKind').value==='pc-isolated'?'Windows · copia local (se guardará al iniciar)':'Hostinger · ZIP importado';});
  $('downloadZip').onclick=e=>{if(!state.run?.artifact)return e.preventDefault();if(!confirm('Este ZIP es provisional: requiere revisión funcional antes de instalarlo. ¿Descargar?'))e.preventDefault()};
  setInterval(async()=>{
     const now=Date.now(),ms=Math.max(2000,Math.min(60000,Number(state.config?.tracking?.pollSeconds||4)*1000));
     if(now-state.lastPoll<ms)return;state.lastPoll=now;
     if(state.run?.status==='running')await refreshRun(true);await refreshCapabilities();
   },1000);
  setInterval(refreshHistory,25000);
  setInterval(async()=>{
    if(!document.querySelector('[data-tab="chat"]')?.classList.contains('active'))return;
    if(chat16.busy)return;
    try{await chat16Refresh(true);await chat16ProbeStatus();}catch(e){$('chat16Status').textContent='Error de actualización: '+e.message;}
  },5000);
 }
 async function init(){setup();try{const data=await api('GET','settings');state.config=data.config;bindControls();await loadProjects();await chat16LoadThreads();await refreshHistory();await refreshLimitTasks();await refreshCapabilities();flash('Centro de control web cargado.');}catch(e){flash('Error de carga: '+e.message,true)}}
 init();
})();
